import streamlit as st
import sys
import os
import pandas as pd
import numpy as np
import time
from datetime import datetime, timedelta
import plotly.graph_objects as go
import plotly.express as px
import requests
from web3 import Web3
import random

# Add the current directory to path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

# Import project modules
import crypto_data
import real_flash_swap
import arbitrage
import quantum_market_mapper
import ai_trader
import quantum_trader
import utils
import auth
import secure_wallet_ui
import metamask_component
from trading_dashboard import dashboard_ui as display_trading_dashboard
from mev_predator import MEVPredator, mev_predator_ui
import ethereum_connector #Added import for ethereum connection


# Set page configuration
st.set_page_config(
    page_title="Crypto Arbitrage & DeFi Optimizer",
    page_icon="📈",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Define the arbitrage scanner page
def arbitrage_scanner_page():
    st.title("🔍 Arbitrage Scanner")

    st.markdown("""
    This advanced scanner identifies price differences across exchanges and DEXes 
    to find profitable trading opportunities in real-time.
    """)

    # Exchange selection
    with st.expander("Scan Settings", expanded=True):
        col1, col2 = st.columns(2)

        with col1:
            exchanges = ["Binance", "Coinbase", "Kraken", "Huobi", "KuCoin", "Bitfinex"]
            selected_exchanges = st.multiselect(
                "Select Exchanges",
                options=exchanges,
                default=exchanges[:3]
            )

            min_profit = st.slider(
                "Minimum Profit Percentage",
                min_value=0.1,
                max_value=5.0,
                value=0.5,
                step=0.1,
                help="Minimum price difference required to consider as an opportunity"
            )

        with col2:
            cryptos = ["BTC", "ETH", "BNB", "XRP", "ADA", "SOL", "DOT", "DOGE", "AVAX", "LINK"]
            selected_cryptos = st.multiselect(
                "Select Cryptocurrencies",
                options=cryptos,
                default=cryptos[:5]
            )

            fee_percentage = st.slider(
                "Trading Fee Percentage",
                min_value=0.0,
                max_value=1.0,
                value=0.1,
                step=0.05,
                help="Trading fee percentage to use in profit calculation"
            )

    # Scan button
    if st.button("Scan for Arbitrage Opportunities", type="primary"):
        if not selected_exchanges or not selected_cryptos:
            st.warning("Please select at least one exchange and one cryptocurrency")
        else:
            with st.spinner("Scanning for arbitrage opportunities..."):
                # Get real price data from exchanges
                price_data = []

                for crypto in selected_cryptos:
                    for exchange in selected_exchanges:
                        try:
                            # Get real price from CoinGecko API for this crypto/exchange pair
                            price = crypto_data.get_current_price(crypto, exchange)

                            # Skip this crypto/exchange pair if we couldn't get a real price
                            if price is None:
                                continue

                            price_data.append({
                                'crypto': crypto,
                                'exchange': exchange,
                                'price': price
                            })
                        except Exception as e:
                            st.error(f"Error fetching price for {crypto} on {exchange}: {str(e)}")

                # Convert to DataFrame
                df = pd.DataFrame(price_data)

                if len(df) > 0:
                    # Find opportunities
                    opportunities = arbitrage.find_arbitrage_opportunities(df, min_profit_pct=min_profit)

                    # Calculate profits with fees
                    profit_df = arbitrage.calculate_arbitrage_profit(df, trade_amount=1000, fee_percentage=fee_percentage)

                    # Display price table
                    st.subheader("Current Prices")

                    # Pivot data for better visualization
                    pivot_df = df.pivot(index='crypto', columns='exchange', values='price')
                    st.dataframe(pivot_df.style.format("${:.2f}"), use_container_width=True)

                    # Visualize price differences
                    st.subheader("Price Difference Heatmap")
                    price_diff_fig = arbitrage.visualize_price_differences(df)
                    st.plotly_chart(price_diff_fig, use_container_width=True)

                    # Show opportunities
                    if opportunities:
                        st.subheader(f"Found {len(opportunities)} Arbitrage Opportunities")

                        # Create opportunities table
                        opp_data = []
                        for opp in opportunities:
                            opp_data.append({
                                'Cryptocurrency': opp['crypto'],
                                'Buy Exchange': opp['buy_exchange'],
                                'Buy Price': f"${opp['buy_price']:.2f}",
                                'Sell Exchange': opp['sell_exchange'],
                                'Sell Price': f"${opp['sell_price']:.2f}",
                                'Profit %': f"{opp['profit_percentage']:.2f}%",
                                'Profit Amount': f"${opp['profit_amount']:.2f}"
                            })

                        st.table(pd.DataFrame(opp_data))

                        # Visualize opportunities
                        st.subheader("Arbitrage Opportunities by Profit")
                        opp_fig = arbitrage.visualize_arbitrage_opportunities(opportunities)
                        st.plotly_chart(opp_fig, use_container_width=True)

                        # Calculate net profit after fees
                        profitable_after_fees = profit_df[profit_df['net_profit'] > 0]

                        if not profitable_after_fees.empty:
                            st.subheader("Profitable Opportunities After Fees")

                            # Create formatted table for display
                            profit_data = []
                            for _, row in profitable_after_fees.iterrows():
                                profit_data.append({
                                    'Cryptocurrency': row['crypto'],
                                    'Buy Exchange': row['buy_exchange'],
                                    'Sell Exchange': row['sell_exchange'],
                                    'Net Profit': f"${row['net_profit']:.2f}",
                                    'Net Profit %': f"{row['net_profit_pct']:.2f}%",
                                    'Buy Price': f"${row['buy_price']:.2f}",
                                    'Sell Price': f"${row['sell_price']:.2f}"
                                })

                            st.table(pd.DataFrame(profit_data))

                            # Add execute button for real trades
                            st.subheader("Execute Trades")

                            selected_trade = st.selectbox(
                                "Select trade to execute",
                                options=[f"{row['crypto']}: {row['buy_exchange']} → {row['sell_exchange']} (${row['net_profit']:.2f})" 
                                         for _, row in profitable_after_fees.iterrows()]
                            )

                            if st.button("Execute Selected Trade"):
                                st.info("Connecting to exchanges...")
                                time.sleep(1)
                                st.warning("This feature requires exchange API keys. Please add your exchange API keys in Settings.")
                        else:
                            st.warning("No opportunities are profitable after considering trading fees.")
                    else:
                        st.info("No arbitrage opportunities found matching your criteria.")
                else:
                    st.error("Could not fetch price data. Please try again.")

# Define a basic DeFi optimizer page
def defi_optimizer_page():
    st.title("💰 DeFi Yield Optimizer")

    st.markdown("""
    Maximize your DeFi returns with our AI-powered yield optimizer.
    Find the best yield farming, staking, and lending opportunities across multiple chains.
    """)

    st.info("This feature is being implemented. Check back soon!")



# Define a basic quantum trading page
def quantum_trading_page():
    st.title("⚛️ Quantum Trading Engine")

    st.markdown("""
    This advanced trading engine uses quantum-inspired algorithms to identify and exploit market opportunities,
    with built-in MEV protection and aggressive optimization.
    """)

    # Tabs for different components
    tab1, tab2, tab3, tab4 = st.tabs(["Quantum Market Mapper", "Portfolio Optimizer", "MEV Optimizer", "Trade Executor"])

    with tab1:
        # Show quantum market mapper UI
        market_mapper_page()

    with tab2:
        # Show portfolio optimizer UI
        quantum_trader.quantum_portfolio_optimizer_ui()

    with tab3:
        # MEV Optimizer Interface
        st.subheader("🦈 Quantum MEV Optimization")

        st.markdown("""
        This component combines quantum principles with aggressive MEV strategies to maximize returns
        in any market condition while protecting your transactions from predatory MEV.
        """)

        # MEV Aggression level
        col1, col2 = st.columns(2)

        with col1:
            # Initialize MEV predator if not exists
            if 'quantum_mev_predator' not in st.session_state:
                w3 = ethereum_connector.initialize_ethereum_connection() #Using the new function
                st.session_state.quantum_mev_predator = MEVPredator(w3, aggression_level=8)

            # Control panel
            aggression = st.slider("MEV Aggression Level", 1, 10, 8, 
                                 help="Higher levels = more aggressive strategies")

        with col2:
            capital_risk = st.slider("Capital at Risk (%)", 10, 100, 50,
                                   help="Maximum percentage of capital to risk")

            use_flashbots = st.checkbox("Use Flashbots Protection", value=True,
                                      help="Use Flashbots for MEV protection")

        # Update settings button
        if st.button("Update MEV Settings"):
            st.session_state.quantum_mev_predator.aggression_level = aggression
            st.session_state.quantum_mev_predator.max_capital_at_risk = capital_risk / 100
            st.session_state.quantum_mev_predator.use_flashbots = use_flashbots

            st.success("MEV settings updated successfully!")

    with tab4:
        # Trade Executor Interface
        st.subheader("🤖 Quantum Trade Executor")

        st.markdown("""
        Execute automated trades using our quantum-inspired algorithms that adapt to market conditions
        for optimal entry and exit points.
        """)

        # Trading parameter inputs
        col1, col2 = st.columns(2)

        with col1:
            trading_pair = st.selectbox(
                "Trading Pair",
                options=["BTC/USDT", "ETH/USDT", "XRP/USDT", "SOL/USDT", "LINK/USDT"]
            )

            position_size = st.number_input(
                "Position Size (USDT)",
                min_value=10.0,
                max_value=100000.0,
                value=1000.0,
                step=100.0
            )

        with col2:
            strategy = st.selectbox(
                "Trading Strategy",
                options=["Quantum Momentum", "Reversal Detection", "Range Breakout", "Volume Analysis"]
            )

            time_frame = st.select_slider(
                "Time Frame",
                options=["1m", "5m", "15m", "1h", "4h", "1d"]
            )

        # Trade button
        if st.button("Execute Quantum Trade", type="primary"):
            with st.spinner("Analyzing market conditions with quantum algorithms..."):
                # Simulate processing
                time.sleep(2)

                # Simulated trade result
                success = random.random() < 0.8  # 80% success rate

                if success:
                    st.success(f"Trade executed successfully on {trading_pair} using {strategy} strategy!")

                    # Show trade details
                    st.json({
                        "pair": trading_pair,
                        "strategy": strategy,
                        "position_size": position_size,
                        "time_frame": time_frame,
                        "execution_time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                        "entry_price": 50000 if "BTC" in trading_pair else 3000,
                        "target_price": 51000 if "BTC" in trading_pair else 3060,
                        "stop_loss": 49500 if "BTC" in trading_pair else 2970
                    })
                else:
                    st.error("Trade execution failed. Market conditions unfavorable or insufficient liquidity.")

# Define a simple settings page
def settings_page():
    st.title("⚙️ Settings")

    st.markdown("""
    Configure your trading environment, API keys, and preferences.
    """)

    # Tabs for different settings
    tab1, tab2, tab3 = st.tabs(["API Keys", "Trading Preferences", "UI Settings"])

    with tab1:
        st.subheader("Exchange API Keys")

        # Binance API
        st.text_input("Binance API Key", type="password")
        st.text_input("Binance API Secret", type="password")

        # Coinbase API
        st.text_input("Coinbase API Key", type="password")
        st.text_input("Coinbase API Secret", type="password")

        # Save button
        if st.button("Save API Keys"):
            st.success("API keys saved successfully!")

    with tab2:
        st.subheader("Trading Preferences")

        # Risk settings
        st.slider("Default Risk Level", 1, 10, 5, help="1 = Low risk, 10 = High risk")

        # Default trading size
        st.number_input("Default Position Size (USDT)", min_value=10.0, value=1000.0)

        # Auto-trading settings
        st.checkbox("Enable Auto-Trading", value=False)
        st.slider("Maximum Trades Per Day", 0, 50, 10)

        # Save button
        if st.button("Save Trading Preferences"):
            st.success("Trading preferences saved successfully!")

    with tab3:
        st.subheader("UI Settings")

        # Color theme
        st.selectbox("Color Theme", options=["Light", "Dark", "System"])

        # Dashboard layout
        st.selectbox("Default Dashboard Layout", options=["Standard", "Compact", "Expanded"])

        # Save button
        if st.button("Save UI Settings"):
            st.success("UI settings saved successfully!")

# Define the market mapper page function
def market_mapper_page():
    """Quantum Market Mapper Page"""
    st.title("Quantum Market Mapper")

    st.markdown("""
    The Quantum Market Mapper provides a real-time view of price differences across
    decentralized exchanges (DEXs), helping you identify arbitrage opportunities.
    """)

    # Initialize tabs
    tab1, tab2, tab3 = st.tabs(["Market Scanner", "Arbitrage Finder", "Cross-Chain View"])

    # Market Scanner Tab
    with tab1:
        st.subheader("Market Scanner")

        col1, col2 = st.columns(2)

        with col1:
            # Select DEXes
            available_dexes = quantum_market_mapper.get_available_dexes()
            dex_display_names = quantum_market_mapper.get_dex_display_names()
            selected_dexes = st.multiselect(
                "Select DEXes",
                options=available_dexes,
                default=available_dexes[:4],
                format_func=lambda x: dex_display_names.get(x, x)
            )

            # Select trading pairs
            available_tokens = quantum_market_mapper.get_available_tokens()
            base_currencies = st.multiselect(
                "Base Currencies",
                options=["USDT", "USDC", "DAI", "WETH", "WBTC"],
                default=["USDT"]
            )

            # Generate pairs
            selected_tokens = st.multiselect(
                "Select Tokens",
                options=available_tokens,
                default=["WETH", "WBTC", "LINK", "UNI", "AAVE"]
            )

            trading_pairs = []
            for token in selected_tokens:
                for base in base_currencies:
                    if token != base:
                        trading_pairs.append(f"{token}/{base}")

        with col2:
            timeframe = st.selectbox(
                "Timeframe",
                options=["Real-time", "Last Hour", "Last Day", "Last Week", "Last Month"],
                index=0
            )

            # Button to fetch market data
            if st.button("Fetch Market Data", type="primary"):
                with st.spinner("Fetching market data from DEXes..."):
                    # Initialize Ethereum connection if needed
                    ethereum_connector.initialize_ethereum_connection()

                    try:
                        market_data = quantum_market_mapper.fetch_market_data(
                            selected_dexes, 
                            trading_pairs, 
                            timeframe
                        )
                        #Further processing or display of market_data would go here.  Example:
                        st.write(market_data)
                    except Exception as e:
                        st.error(f"Error fetching market data: {e}")


# Exchange Management page
def exchange_management_page():
    # Check if module is available, otherwise show message
    try:
        import exchange_management_ui
        exchange_management_ui.render_exchange_management_ui()
    except ImportError:
        st.error("Exchange Management module is not available")
        st.info("This module allows you to create and manage exchange accounts, API keys, and track profits across all major exchanges.")

# Sidebar navigation
def create_sidebar():
    """Create the sidebar navigation"""
    st.sidebar.title("Navigation")

    # User authentication section
    if "username" in st.session_state:
        st.sidebar.success(f"Logged in as {st.session_state.username}")
        if st.sidebar.button("Logout"):
            # Clear all session state
            for key in list(st.session_state.keys()):
                del st.session_state[key]
            # Rerun the app to show the login page
            st.rerun()
    else:
        st.sidebar.warning("Not logged in")

    # Page selection
    page_options = {
        "Home": "home_page",
        "Trading Dashboard": "trading_dashboard_page",
        "Exchange Management": "exchange_management_page",
        "DEX Trading": "dex_trading_page",
        "Flash Swap Analyzer": "flash_swap_page",
        "Quantum Market Mapper": "market_mapper_page",
        "AI Predictions": "ai_predictions_page",
        "MEV Predator": "mev_predator_page",
        "DeFi Optimizer": "defi_optimizer_page",
        "Wallet Manager": "wallet_manager_page",
        "Ethereum Connect": "ethereum_connect_page"
    }

    # If user is not logged in, limit options
    if "username" not in st.session_state:
        page_options = {"Home": "home_page"}

    selected_page = st.sidebar.radio("Go to", options=list(page_options.keys()))

    # Add system status indicator
    st.sidebar.markdown("---")
    st.sidebar.markdown("### System Status")

    system_status = "✅ All Systems Operational"
    status_color = "green"

    st.sidebar.markdown(f":{status_color}[{system_status}]")

    # Show wallet status if connected
    if "wallet_address" in st.session_state:
        address = st.session_state.wallet_address
        st.sidebar.markdown("### Connected Wallet")
        st.sidebar.markdown(f"`{address[:6]}...{address[-4:]}`")

        try:
            # Show quick profit stats
            import secure_wallet
            wallet = secure_wallet.SecureWallet()
            profits = wallet.get_user_profits(address)

            if profits and profits.get('total_profit', 0) > 0:
                st.sidebar.metric(
                    "Trading Profit",
                    f"${profits.get('total_profit', 0):.2f}",
                    f"{profits.get('trades_count', 0)} trades"
                )
        except:
            pass

    return page_options[selected_page]

# Define missing page functions
def home_page():
    st.title("🚀 Crypto Arbitrage & DeFi Optimizer")
    
    st.markdown("""
    Welcome to the most advanced crypto trading platform, integrating arbitrage detection, 
    DeFi yield optimization, and quantum trading algorithms.
    """)
    
    # Dashboard sections
    col1, col2 = st.columns(2)
    
    with col1:
        st.subheader("Platform Features")
        st.markdown("""
        - 🔍 **Arbitrage Scanner**: Find price differences across exchanges
        - 💰 **DeFi Yield Optimizer**: Maximize your yield farming returns
        - ⚛️ **Quantum Trading**: Advanced algorithms for optimal trades
        - 🛡️ **MEV Protection**: Shield your transactions from frontrunning
        - 🔄 **Flash Swap Analysis**: Zero-capital arbitrage opportunities
        """)
        
    with col2:
        st.subheader("Market Overview")
        # Display some basic market data
        st.metric("Bitcoin (BTC)", "$50,123.45", "2.5%")
        st.metric("Ethereum (ETH)", "$3,046.78", "-0.8%")
        st.metric("DeFi TVL", "$45.7B", "1.2%")
    
    # Featured tools
    st.subheader("Featured Tools")
    
    tool_col1, tool_col2, tool_col3 = st.columns(3)
    
    with tool_col1:
        st.markdown("### 🔍 Arbitrage Scanner")
        st.markdown("Scan for price differences across exchanges to find risk-free profits.")
        if st.button("Launch Scanner", key="launch_scanner"):
            st.session_state.page = "arbitrage_scanner_page"
            st.rerun()
    
    with tool_col2:
        st.markdown("### 💰 DeFi Optimizer")
        st.markdown("Find the best yield farming and liquidity mining opportunities.")
        if st.button("Launch Optimizer", key="launch_optimizer"):
            st.session_state.page = "defi_optimizer_page"
            st.rerun()
            
    with tool_col3:
        st.markdown("### ⚛️ Quantum Trading")
        st.markdown("Use advanced quantum-inspired algorithms for optimal trades.")
        if st.button("Launch Quantum Trader", key="launch_quantum"):
            st.session_state.page = "quantum_trading_page"
            st.rerun()

def trading_dashboard_page():
    st.title("📊 Trading Dashboard")
    
    st.markdown("""
    Monitor your trading performance, open positions, and market data in real-time.
    """)
    
    # Use the imported dashboard UI function
    display_trading_dashboard()

def dex_trading_page():
    st.title("🔄 DEX Trading Interface")
    
    st.markdown("""
    Trade directly on decentralized exchanges with optimized execution and MEV protection.
    """)
    
    st.info("This feature is being implemented. Check back soon!")

def flash_swap_page():
    st.title("⚡ Flash Swap Analyzer")
    
    st.markdown("""
    Analyze and execute flash swap arbitrage opportunities with zero upfront capital.
    """)
    
    # Try to import flash loan UI
    try:
        import advanced_defi
        advanced_defi.flash_loan_ui()
    except (ImportError, AttributeError) as e:
        st.error(f"Error loading Flash Swap UI: {str(e)}")
        st.info("This feature is being implemented. Check back soon!")

def ai_predictions_page():
    st.title("🧠 AI Market Predictions")
    
    st.markdown("""
    Get AI-powered price predictions and trading signals for major cryptocurrencies.
    """)
    
    # Try to use AI trader
    try:
        ai_trader.render_ai_predictions_ui()
    except (NameError, AttributeError) as e:
        st.error(f"Error loading AI Predictions UI: {str(e)}")
        st.info("This feature is being implemented. Check back soon!")

def mev_predator_page():
    st.title("🦈 MEV Predator")
    
    st.markdown("""
    Advanced MEV protection and optimization for your transactions.
    """)
    
    # Use the imported MEV predator UI
    mev_predator_ui()

def wallet_manager_page():
    st.title("👛 Wallet Manager")
    
    st.markdown("""
    Securely manage your crypto wallets and track your portfolio.
    """)
    
    # Try to use secure wallet UI
    try:
        secure_wallet_ui.render_wallet_ui()
    except (NameError, AttributeError) as e:
        st.error(f"Error loading Wallet Manager UI: {str(e)}")
        st.info("This feature is being implemented. Check back soon!")

def ethereum_connect_page():
    st.title("🔗 Ethereum Connection")
    
    st.markdown("""
    Connect to Ethereum networks and interact with smart contracts.
    """)
    
    # Try to use ethereum connector
    try:
        w3 = ethereum_connector.initialize_ethereum_connection()
        
        if w3:
            st.success("Connected to Ethereum network")
            
            # Display network info
            network_id = w3.eth.chain_id
            network_name = ethereum_connector.get_network_name(network_id)
            
            st.write(f"**Network:** {network_name}")
            st.write(f"**Chain ID:** {network_id}")
            
            # Latest block info
            latest_block = w3.eth.get_block('latest')
            st.write(f"**Latest Block:** {latest_block.number}")
            st.write(f"**Gas Limit:** {latest_block.gasLimit}")
            st.write(f"**Gas Used:** {latest_block.gasUsed}")
        else:
            st.error("Failed to connect to Ethereum network")
    except Exception as e:
        st.error(f"Error connecting to Ethereum: {str(e)}")
        st.info("Please check your API keys in Settings")

# Map page names to functions
pages = {
    "home_page": home_page,
    "trading_dashboard_page": trading_dashboard_page,
    "exchange_management_page": exchange_management_page,
    "dex_trading_page": dex_trading_page,
    "flash_swap_page": flash_swap_page,
    "market_mapper_page": market_mapper_page,
    "ai_predictions_page": ai_predictions_page,
    "mev_predator_page": mev_predator_page,
    "defi_optimizer_page": defi_optimizer_page,
    "wallet_manager_page": wallet_manager_page,
    "ethereum_connect_page": ethereum_connect_page
}

# Select page
page = create_sidebar()
selected_page = pages[page]
selected_page()