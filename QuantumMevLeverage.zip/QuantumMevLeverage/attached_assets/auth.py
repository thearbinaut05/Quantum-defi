import streamlit as st
import hashlib
import os
import json
import time
from web3 import Web3
from eth_account.messages import encode_defunct
import uuid

# File to store registered users
USER_DATA_FILE = ".streamlit/user_data.json"

def ensure_user_data_file():
    """Make sure the user data file exists"""
    # Create the .streamlit directory if it doesn't exist
    os.makedirs(os.path.dirname(USER_DATA_FILE), exist_ok=True)

    # Create the user data file if it doesn't exist
    if not os.path.exists(USER_DATA_FILE):
        with open(USER_DATA_FILE, 'w') as f:
            json.dump({"users": {}, "profiles": {}}, f)

def hash_password(password):
    """Hash a password for storing."""
    return hashlib.sha256(password.encode()).hexdigest()

def load_users():
    """Load user data from file"""
    ensure_user_data_file()
    with open(USER_DATA_FILE, 'r') as f:
        data = json.load(f)
    return data

def save_users(data):
    """Save user data to file"""
    ensure_user_data_file()
    with open(USER_DATA_FILE, 'w') as f:
        json.dump(data, f, indent=2)

def register_user(username, password, email):
    """Register a new user"""
    data = load_users()
    if username in data["users"]:
        return False, "Username already exists"

    # Store user data
    data["users"][username] = {
        "password_hash": hash_password(password),
        "email": email,
        "created_at": time.time(),
        "last_login": None
    }

    # Initialize profile data
    data["profiles"][username] = {
        "wallet_address": None,
        "trading_preferences": {
            "risk_level": "medium",
            "preferred_tokens": ["BTC", "ETH"],
            "auto_trading_enabled": False,
            "max_position_size": 1000
        },
        "trading_performance": {
            "total_profit": 0,
            "total_trades": 0,
            "win_rate": 0,
            "avg_profit_per_trade": 0,
            "start_date": time.time(),
            "portfolio_value": 10000
        }
    }

    save_users(data)
    return True, "User registered successfully"

def authenticate_user(username, password):
    """Authenticate a user"""
    data = load_users()
    if username not in data["users"]:
        return False, "Username not found"

    stored_password_hash = data["users"][username]["password_hash"]
    if hash_password(password) != stored_password_hash:
        return False, "Incorrect password"

    # Update last login time
    data["users"][username]["last_login"] = time.time()
    save_users(data)

    return True, "Login successful"

def get_user_profile(username):
    """Get user profile data"""
    try:
        data = load_users()
        if username in data["profiles"]:
            return data["profiles"][username]
        return None
    except Exception as e:
        print(f"Error in get_user_profile: {str(e)}")
        # Return a minimal profile to prevent errors
        return {
            "username": username if username else "guest",
            "trading_preferences": {
                "risk_level": "moderate",
                "preferred_tokens": ["BTC", "ETH"],
                "auto_trading_enabled": False,
                "max_position_size": 500
            },
            "trading_performance": {
                "portfolio_value": 10000,
                "total_profit": 0,
                "win_rate": 0.5,
                "total_trades": 0,
                "profitable_trades": 0,
                "losing_trades": 0
            }
        }

def update_user_profile(username, profile_data):
    """Update user profile data"""
    data = load_users()
    if username not in data["profiles"]:
        return False, "User profile not found"

    # Update profile data
    data["profiles"][username].update(profile_data)
    save_users(data)

    return True, "Profile updated successfully"

def update_trading_performance(username, performance_data):
    """Update trading performance data"""
    data = load_users()
    if username not in data["profiles"]:
        return False, "User profile not found"

    # Update trading performance data
    data["profiles"][username]["trading_performance"].update(performance_data)
    save_users(data)

    return True, "Trading performance updated successfully"

def connect_wallet(wallet_address, username):
    """Connect a wallet to a user account"""
    data = load_users()
    if username not in data["profiles"]:
        return False, "User profile not found"

    # Update wallet address
    data["profiles"][username]["wallet_address"] = wallet_address
    save_users(data)

    return True, "Wallet connected successfully"

def verify_wallet_signature(message, signature, address):
    """Verify if a signature is from the given address"""
    try:
        w3 = Web3()
        message_hash = encode_defunct(text=message)
        signer = w3.eth.account.recover_message(message_hash, signature=signature)
        return signer.lower() == address.lower()
    except Exception as e:
        st.error(f"Error verifying signature: {e}")
        return False

def generate_auth_message(address):
    """Generate a unique message for wallet authentication"""
    nonce = uuid.uuid4().hex
    return f"Sign this message to authenticate your wallet: {address} (Nonce: {nonce})"

def wallet_auth_ui():
    """UI for wallet authentication"""
    st.subheader("Connect Your Wallet")

    # Check if user is logged in
    if "username" not in st.session_state:
        st.warning("Please log in first to connect your wallet")
        return None

    col1, col2 = st.columns([2, 1])

    with col1:
        wallet_address = st.text_input("Ethereum Wallet Address", 
                                       placeholder="0x...")

    with col2:
        connect_button = st.button("Connect Wallet")

    if connect_button and wallet_address:
        if not wallet_address.startswith("0x") or len(wallet_address) != 42:
            st.error("Invalid Ethereum address format")
            return None

        # Generate auth message
        auth_message = generate_auth_message(wallet_address)
        st.info(f"Please sign this message with your wallet: **{auth_message}**")

        signature = st.text_area("Paste your signature here", 
                                 placeholder="0x...")

        verify_button = st.button("Verify Signature")

        if verify_button and signature:
            if verify_wallet_signature(auth_message, signature, wallet_address):
                success, message = connect_wallet(wallet_address, st.session_state.username)
                if success:
                    st.success(f"Wallet connected successfully: {wallet_address[:6]}...{wallet_address[-4:]}")
                    # Save to session state
                    st.session_state.wallet_address = wallet_address
                    return wallet_address
                else:
                    st.error(message)
            else:
                st.error("Invalid signature. Please try again.")

    # Show current wallet if connected
    profile = get_user_profile(st.session_state.username)
    if profile and profile["wallet_address"]:
        addr = profile["wallet_address"]
        st.success(f"Wallet currently connected: {addr[:6]}...{addr[-4:]}")
        st.button("Disconnect Wallet", on_click=lambda: disconnect_wallet(st.session_state.username))
        return addr

    return None

def disconnect_wallet(username):
    """Disconnect a wallet from a user account"""
    data = load_users()
    if username in data["profiles"]:
        data["profiles"][username]["wallet_address"] = None
        save_users(data)
        # Also clear from session state
        if "wallet_address" in st.session_state:
            del st.session_state.wallet_address

def login_ui():
    """UI for user login"""
    if "logged_in" in st.session_state and st.session_state.logged_in:
        # Show logged in status
        st.sidebar.success(f"Logged in as {st.session_state.username}")
        if st.sidebar.button("Log Out"):
            # Clear session state
            for key in ["logged_in", "username", "wallet_address"]:
                if key in st.session_state:
                    del st.session_state[key]
            st.rerun()
        return True

    # Login form
    with st.sidebar.expander("Login", expanded=not st.session_state.get('show_register', False)):
        username = st.text_input("Username", key="login_username")
        password = st.text_input("Password", type="password", key="login_password")

        col1, col2 = st.columns(2)

        with col1:
            login_button = st.button("Login")

        with col2:
            st.button("Register", on_click=lambda: set_show_register(True))

        if login_button and username and password:
            success, message = authenticate_user(username, password)
            if success:
                st.session_state.logged_in = True
                st.session_state.username = username
                st.session_state.show_register = False

                # Load user profile
                profile = get_user_profile(username)
                if profile and profile["wallet_address"]:
                    st.session_state.wallet_address = profile["wallet_address"]

                st.rerun()
            else:
                st.error(message)

    # Register form
    if st.session_state.get('show_register', False):
        with st.sidebar.expander("Register", expanded=True):
            new_username = st.text_input("Choose Username", key="reg_username")
            new_password = st.text_input("Choose Password", type="password", key="reg_password")
            confirm_password = st.text_input("Confirm Password", type="password", key="reg_confirm")
            email = st.text_input("Email Address", key="reg_email")

            col1, col2 = st.columns(2)

            with col1:
                register_button = st.button("Create Account")

            with col2:
                st.button("Back to Login", on_click=lambda: set_show_register(False))

            if register_button:
                if not new_username or not new_password or not email:
                    st.error("All fields are required")
                elif new_password != confirm_password:
                    st.error("Passwords do not match")
                else:
                    success, message = register_user(new_username, new_password, email)
                    if success:
                        st.success(message)
                        # Reset form and show login
                        st.session_state.show_register = False
                        st.rerun()
                    else:
                        st.error(message)

    return False

def set_show_register(value):
    """Helper to set show_register in session state"""
    st.session_state.show_register = value

def init_auth():
    """Initialize authentication system"""
    if "show_register" not in st.session_state:
        st.session_state.show_register = False
    if "logged_in" not in st.session_state:
        st.session_state.logged_in = False

def user_profile_ui():
    """UI for viewing and editing user profile"""
    if "username" not in st.session_state:
        st.warning("Please log in to view your profile")
        return

    username = st.session_state.username
    profile = get_user_profile(username)

    if not profile:
        st.error("Profile not found")
        return

    st.header(f"Profile: {username}")

    tab1, tab2, tab3 = st.tabs(["Account Details", "Trading Preferences", "Performance"])

    with tab1:
        st.subheader("Account Information")

        # Show email with option to update
        email = st.text_input("Email Address", value=get_user_email(username))

        if st.button("Update Email"):
            if email:
                update_user_email(username, email)
                st.success("Email updated successfully")

        # Connect wallet section
        st.subheader("Wallet Connection")
        wallet_address = wallet_auth_ui()

    with tab2:
        st.subheader("Trading Preferences")

        # Risk level
        risk_level = st.select_slider(
            "Risk Level",
            options=["very low", "low", "medium", "high", "very high"],
            value=profile["trading_preferences"]["risk_level"]
        )

        # Preferred tokens
        all_tokens = ["BTC", "ETH", "XRP", "LTC", "LINK", "DOT", "ADA", "SOL", "AVAX", "MATIC"]
        preferred_tokens = st.multiselect(
            "Preferred Tokens",
            options=all_tokens,
            default=profile["trading_preferences"]["preferred_tokens"]
        )

        # Auto-trading
        auto_trading = st.toggle(
            "Enable Autonomous Trading",
            value=profile["trading_preferences"]["auto_trading_enabled"]
        )

        # Max position size
        max_position = st.slider(
            "Maximum Position Size (USD)",
            min_value=100,
            max_value=10000,
            value=profile["trading_preferences"]["max_position_size"],
            step=100
        )

        # Save button
        if st.button("Save Preferences"):
            preferences = {
                "trading_preferences": {
                    "risk_level": risk_level,
                    "preferred_tokens": preferred_tokens,
                    "auto_trading_enabled": auto_trading,
                    "max_position_size": max_position
                }
            }

            success, message = update_user_profile(username, preferences)
            if success:
                st.success("Trading preferences updated successfully")
            else:
                st.error(message)

    with tab3:
        st.subheader("Trading Performance")
        perf = profile["trading_performance"]

        # Key metrics in columns
        col1, col2, col3, col4 = st.columns(4)

        with col1:
            st.metric("Portfolio Value", f"${perf['portfolio_value']:,.2f}")

        with col2:
            st.metric("Total Profit", f"${perf['total_profit']:,.2f}")

        with col3:
            st.metric("Win Rate", f"{perf['win_rate']*100:.1f}%" if perf['total_trades'] > 0 else "N/A")

        with col4:
            st.metric("Total Trades", f"{perf['total_trades']}")

        # Placeholder for performance chart
        st.subheader("Performance History")
        st.info("Detailed performance history will be available once trading activity begins")

def get_user_email(username):
    """Get email of a user"""
    data = load_users()
    if username in data["users"]:
        return data["users"][username]["email"]
    return ""

def update_user_email(username, email):
    """Update email of a user"""
    data = load_users()
    if username in data["users"]:
        data["users"][username]["email"] = email
        save_users(data)
        return True
    return False