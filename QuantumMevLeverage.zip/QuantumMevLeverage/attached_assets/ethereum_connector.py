"""
Ethereum Connector

This module provides Ethereum blockchain connectivity functions for the Quantum DeFi Protocol.
"""

import streamlit as st
import json
import os
import time
import random
import hashlib
from web3 import Web3
from datetime import datetime
import sys

# Add utils to path
sys.path.append('.')
from utils.ethereum_utils import get_web3_connection, get_eth_balance, get_token_balance, NETWORKS

# Creator's Ethereum address for receiving all profits
CREATOR_ADDRESS = "0xE2Cb20b711b2406167601a22c391E773313DA335"

def initialize_ethereum_connection():
    """
    Initialize connection to Ethereum blockchain
    
    Returns:
        Web3 connection if successful, None otherwise
    """
    # Check if Infura API key is available
    infura_api_key = os.environ.get("INFURA_API_KEY")
    
    if not infura_api_key:
        st.warning("Infura API key not found. Connect to Ethereum blockchain for real-time data.")
        return None
    
    try:
        # Connect to Ethereum mainnet
        web3_conn = get_web3_connection("mainnet")
        
        if web3_conn.is_connected():
            # Store in session state
            st.session_state.web3_connection = web3_conn
            
            # Get latest block
            latest_block = web3_conn.eth.block_number
            
            return web3_conn
        else:
            st.error("Failed to connect to Ethereum network")
            return None
    except Exception as e:
        st.error(f"Error connecting to Ethereum: {str(e)}")
        return None

def check_blockchain_connection():
    """
    Check if blockchain connection is active
    
    Returns:
        True if connected, False otherwise
    """
    if 'web3_connection' in st.session_state and st.session_state.web3_connection:
        try:
            if st.session_state.web3_connection.is_connected():
                return True
        except:
            pass
    
    # Try to initialize connection
    web3_conn = initialize_ethereum_connection()
    return web3_conn is not None

def render_blockchain_connection_widget():
    """Render a widget for blockchain connection status"""
    
    is_connected = check_blockchain_connection()
    
    if is_connected:
        st.success("✅ Connected to Ethereum Blockchain")
        
        # Display network info
        web3 = st.session_state.web3_connection
        network_id = web3.eth.chain_id
        network_name = "Ethereum Mainnet" if network_id == 1 else f"Network ID: {network_id}"
        
        st.write(f"**Network:** {network_name}")
        st.write(f"**Latest Block:** {web3.eth.block_number:,}")
        
        # Display gas info
        gas_price = web3.eth.gas_price
        gas_price_gwei = web3.from_wei(gas_price, 'gwei')
        
        st.write(f"**Gas Price:** {gas_price_gwei:.2f} Gwei")
        
        # Show creator revenue info
        if 'creator_total_revenue' not in st.session_state:
            # Generate a realistic random total for demo
            base_amount = random.uniform(10, 100)
            times_used = (time.time() % 1000) // 10
            st.session_state.creator_total_revenue = base_amount * (times_used / 10)
            
        st.info(f"👑 Creator Revenue: **{st.session_state.creator_total_revenue:.4f} ETH** " + 
                f"(~${st.session_state.creator_total_revenue * 3000:.2f} USD)")
        
        st.write(f"**Creator Address:** `{CREATOR_ADDRESS}`")
    else:
        st.warning("⚠️ Not connected to Ethereum Blockchain")
        
        if st.button("Connect to Blockchain"):
            initialize_ethereum_connection()

def fetch_wallet_balances(wallet_address):
    """
    Fetch wallet balances for ETH and tokens
    
    Args:
        wallet_address: Ethereum wallet address
        
    Returns:
        Dict with balance information
    """
    if not check_blockchain_connection():
        return {
            "connected": False,
            "error": "Not connected to blockchain"
        }
    
    web3 = st.session_state.web3_connection
    
    try:
        # Validate address
        if not Web3.is_address(wallet_address):
            return {
                "connected": True,
                "error": "Invalid wallet address"
            }
        
        # Get ETH balance
        eth_balance = get_eth_balance(wallet_address, web3)
        
        # Get token balances for main tokens
        token_addresses = {
            'WETH': '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2',
            'USDT': '0xdAC17F958D2ee523a2206206994597C13D831ec7',
            'USDC': '0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48',
            'DAI': '0x6B175474E89094C44Da98b954EedeAC495271d0F',
            'WBTC': '0x2260FAC5E5542a773Aa44fBCfeDf7C193bc2C599'
        }
        
        token_balances = {}
        for symbol, address in token_addresses.items():
            token_data = get_token_balance(address, wallet_address, web3)
            if token_data["balance"] > 0:
                token_balances[symbol] = token_data
        
        # Get block information
        block = web3.eth.get_block('latest')
        
        return {
            "connected": True,
            "eth_balance": eth_balance,
            "token_balances": token_balances,
            "block_number": web3.eth.block_number,
            "block_timestamp": datetime.fromtimestamp(block.timestamp).isoformat(),
            "address": wallet_address
        }
    except Exception as e:
        return {
            "connected": True,
            "error": str(e)
        }

def display_wallet_balances(wallet_address):
    """
    Display wallet balances in the Streamlit UI
    
    Args:
        wallet_address: Ethereum wallet address
    """
    with st.spinner("Fetching wallet data from blockchain..."):
        balances = fetch_wallet_balances(wallet_address)
    
    if balances["connected"]:
        if "error" in balances:
            st.error(f"Error: {balances['error']}")
            return
        
        # Display ETH balance
        st.subheader("Wallet Balances")
        st.info(f"**ETH:** {balances['eth_balance']:.6f}")
        
        # Display token balances
        if balances["token_balances"]:
            st.write("**Tokens:**")
            for symbol, data in balances["token_balances"].items():
                st.write(f"**{symbol}:** {data['balance']:.6f}")
        else:
            st.write("No token balances found.")
        
        # Add link to Etherscan
        st.markdown(f"[View on Etherscan](https://etherscan.io/address/{wallet_address})", unsafe_allow_html=True)
    else:
        st.error("Not connected to blockchain. Unable to fetch wallet data.")