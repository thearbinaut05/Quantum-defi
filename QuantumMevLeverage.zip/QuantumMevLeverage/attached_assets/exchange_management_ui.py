
"""
Exchange Management UI

This module provides the Streamlit UI for:
1. Creating and managing exchange accounts
2. Adding and managing API keys
3. Viewing exchange balances
4. Tracking trading history and profits
"""

import streamlit as st
import time
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime, timedelta

from exchange_manager import ExchangeManager, SUPPORTED_EXCHANGES
import secure_wallet

def render_exchange_management_ui():
    """Main UI for exchange management"""
    st.title("🏛️ Exchange Management")
    
    # Check if user is logged in
    if "username" not in st.session_state:
        st.warning("Please log in to manage your exchange accounts")
        return
    
    username = st.session_state.username
    
    # Initialize managers
    exchange_manager = ExchangeManager()
    wallet_manager = secure_wallet.SecureWallet()
    
    # Get wallet info for current user
    user_wallet = None
    if "wallet_address" in st.session_state:
        user_wallet = st.session_state.wallet_address
    
    # Set up tabs
    tab1, tab2, tab3, tab4 = st.tabs([
        "Exchange Accounts", 
        "API Keys", 
        "Balances & Trading",
        "Profit Analytics"
    ])
    
    # Tab 1: Exchange Accounts
    with tab1:
        render_exchange_accounts_tab(username, exchange_manager)
    
    # Tab 2: API Keys
    with tab2:
        render_api_keys_tab(username, exchange_manager)
    
    # Tab 3: Balances & Trading
    with tab3:
        render_balances_trading_tab(username, exchange_manager, user_wallet)
    
    # Tab 4: Profit Analytics
    with tab4:
        render_profit_analytics_tab(username, exchange_manager, wallet_manager, user_wallet)

def render_exchange_accounts_tab(username, exchange_manager):
    """Render exchange accounts tab"""
    st.header("Exchange Accounts")
    
    # Get existing accounts
    existing_accounts = exchange_manager.get_exchange_accounts(username)
    
    # Display existing accounts if any
    if existing_accounts:
        st.subheader("Your Exchange Accounts")
        
        for exchange_id, account_data in existing_accounts.items():
            exchange_info = SUPPORTED_EXCHANGES.get(exchange_id, {})
            exchange_name = exchange_info.get("name", exchange_id)
            
            # Create expander for each exchange
            with st.expander(f"{exchange_name} Account", expanded=False):
                col1, col2 = st.columns(2)
                
                with col1:
                    st.write(f"**Email:** {account_data.get('email', 'N/A')}")
                    st.write(f"**Status:** {account_data.get('status', 'unknown')}")
                    st.write(f"**Registered:** {format_timestamp(account_data.get('registered_at', 0))}")
                
                with col2:
                    # Display logo if available
                    if "logo" in exchange_info:
                        st.image(exchange_info["logo"], width=100)
                    
                    # Add verification button if needed
                    if not account_data.get("verified", False):
                        if st.button(f"Confirm Verification", key=f"verify_{exchange_id}"):
                            success = exchange_manager.update_exchange_account_status(
                                username, exchange_id, "verified", True
                            )
                            if success:
                                st.success(f"Your {exchange_name} account is now verified!")
                                st.rerun()
    
    # Form to add new exchange account
    st.subheader("Add New Exchange Account")
    
    # Display available exchanges that the user doesn't have yet
    available_exchanges = [
        ex_id for ex_id in SUPPORTED_EXCHANGES.keys() 
        if ex_id not in existing_accounts
    ]
    
    if not available_exchanges:
        st.info("You've already added all supported exchanges!")
    else:
        # Exchange selection
        selected_exchange = st.selectbox(
            "Select Exchange",
            options=available_exchanges,
            format_func=lambda x: SUPPORTED_EXCHANGES.get(x, {}).get("name", x)
        )
        
        # Show exchange info
        if selected_exchange:
            exchange_info = SUPPORTED_EXCHANGES.get(selected_exchange, {})
            
            col1, col2 = st.columns([1, 2])
            
            with col1:
                # Display logo if available
                if "logo" in exchange_info:
                    st.image(exchange_info["logo"], width=150)
            
            with col2:
                st.markdown(f"### {exchange_info.get('name', selected_exchange)}")
                st.write(f"**Registration URL:** [Sign Up]({exchange_info.get('url', '')})")
                st.write(f"**API Documentation:** [View Docs]({exchange_info.get('api_docs', '')})")
                
                # Display supported networks
                networks = exchange_info.get("networks", [])
                if networks:
                    st.write("**Supported Networks:**", ", ".join(networks))
        
        # Registration form
        with st.form("exchange_registration_form"):
            email = st.text_input("Email for Exchange Registration")
            agree = st.checkbox("I confirm I will register with this email on the exchange website")
            
            submitted = st.form_submit_button("Record Exchange Registration")
            
            if submitted and email and agree:
                success, message = exchange_manager.create_exchange_account(
                    username, selected_exchange, email
                )
                
                if success:
                    st.success(message)
                    st.rerun()
                else:
                    st.error(message)

def render_api_keys_tab(username, exchange_manager):
    """Render API keys tab"""
    st.header("API Keys")
    
    # Get existing API keys
    existing_keys = exchange_manager.get_api_keys(username)
    
    # Display existing API keys if any
    if existing_keys:
        st.subheader("Your API Keys")
        
        for exchange_id, key_data in existing_keys.items():
            exchange_info = SUPPORTED_EXCHANGES.get(exchange_id, {})
            exchange_name = exchange_info.get("name", exchange_id)
            
            # Create expander for each exchange
            with st.expander(f"{exchange_name} API Key", expanded=False):
                col1, col2 = st.columns(2)
                
                with col1:
                    st.write(f"**Status:** {'✅ Active' if key_data.get('has_key', False) else '❌ Inactive'}")
                    st.write(f"**Added:** {format_timestamp(key_data.get('added_at', 0))}")
                
                with col2:
                    # Display logo if available
                    if "logo" in exchange_info:
                        st.image(exchange_info["logo"], width=100)
                    
                    # Add test connection button
                    if st.button(f"Test Connection", key=f"test_{exchange_id}"):
                        success, message = exchange_manager.test_api_connection(
                            username, exchange_id
                        )
                        if success:
                            st.success(message)
                        else:
                            st.error(message)
                    
                    # Add remove button
                    if st.button(f"Remove Key", key=f"remove_{exchange_id}"):
                        success = exchange_manager.remove_api_key(
                            username, exchange_id
                        )
                        if success:
                            st.success(f"Removed API key for {exchange_name}")
                            st.rerun()
                        else:
                            st.error(f"Failed to remove API key")
    
    # Form to add new API key
    st.subheader("Add New API Key")
    
    # Get existing exchange accounts
    existing_accounts = exchange_manager.get_exchange_accounts(username)
    
    if not existing_accounts:
        st.info("Please add an exchange account first")
    else:
        # Build a list of exchanges that have accounts but no API keys
        available_exchanges = [
            ex_id for ex_id in existing_accounts.keys() 
            if ex_id not in existing_keys or not existing_keys[ex_id].get('has_key', False)
        ]
        
        if not available_exchanges:
            st.info("You've already added API keys for all your exchange accounts!")
        else:
            # Exchange selection
            selected_exchange = st.selectbox(
                "Select Exchange",
                options=available_exchanges,
                format_func=lambda x: SUPPORTED_EXCHANGES.get(x, {}).get("name", x)
            )
            
            # API key form
            with st.form("api_key_form"):
                api_key = st.text_input("API Key")
                api_secret = st.text_input("API Secret", type="password")
                
                # Some exchanges require additional auth (like passphrase)
                additional_auth = st.text_input(
                    "Additional Passphrase (if required)",
                    help="Some exchanges like Coinbase Pro require an additional passphrase",
                    type="password"
                )
                
                # Instructions
                exchange_info = SUPPORTED_EXCHANGES.get(selected_exchange, {})
                st.markdown(f"**API Documentation:** [View Docs]({exchange_info.get('api_docs', '')})")
                
                submitted = st.form_submit_button("Add API Key")
                
                if submitted and api_key and api_secret:
                    success = exchange_manager.add_api_key(
                        username, 
                        selected_exchange, 
                        api_key, 
                        api_secret,
                        additional_auth if additional_auth else None
                    )
                    
                    if success:
                        st.success(f"Added API key for {exchange_info.get('name', selected_exchange)}")
                        
                        # Test connection
                        test_success, test_message = exchange_manager.test_api_connection(
                            username, selected_exchange
                        )
                        if test_success:
                            st.success(test_message)
                        else:
                            st.warning(f"Key added but connection test failed: {test_message}")
                            
                        st.rerun()
                    else:
                        st.error("Failed to add API key")

def render_balances_trading_tab(username, exchange_manager, wallet_address):
    """Render balances and trading tab"""
    st.header("Exchange Balances & Trading")
    
    # Get existing API keys
    existing_keys = exchange_manager.get_api_keys(username)
    
    if not existing_keys:
        st.info("Please add API keys first to view your exchange balances")
    else:
        # Exchange selection
        exchange_options = list(existing_keys.keys())
        selected_exchange = st.selectbox(
            "Select Exchange",
            options=exchange_options,
            format_func=lambda x: SUPPORTED_EXCHANGES.get(x, {}).get("name", x)
        )
        
        if selected_exchange:
            # Get exchange information
            exchange_info = SUPPORTED_EXCHANGES.get(selected_exchange, {})
            
            # Fetch balances
            with st.spinner("Fetching balances..."):
                balances = exchange_manager.get_exchange_balances(username, selected_exchange)
            
            if not balances:
                st.warning("No balances found or unable to connect to exchange")
            else:
                # Display balances
                st.subheader(f"{exchange_info.get('name', selected_exchange)} Balances")
                
                # Convert to dataframe for display
                balance_data = []
                for currency, data in balances.items():
                    balance_data.append({
                        "Currency": currency,
                        "Free": data.get("free", 0),
                        "Used": data.get("used", 0),
                        "Total": data.get("total", 0)
                    })
                
                if balance_data:
                    # Sort by total value
                    balance_df = pd.DataFrame(balance_data)
                    balance_df = balance_df.sort_values("Total", ascending=False)
                    
                    # Display as table
                    st.dataframe(balance_df)
                    
                    # Create a pie chart of allocations
                    if len(balance_df) > 0:
                        fig = px.pie(
                            balance_df, 
                            values='Total', 
                            names='Currency',
                            title='Portfolio Allocation'
                        )
                        st.plotly_chart(fig)
                else:
                    st.info("No currencies with non-zero balance found")
                
                # Trading history
                st.subheader("Trading History")
                
                # Fetch trading history for this exchange
                trading_history = exchange_manager.get_trading_history(username, selected_exchange)
                
                if trading_history:
                    # Convert to dataframe for display
                    history_data = []
                    for trade in trading_history:
                        history_data.append({
                            "Date": format_timestamp(trade.get("timestamp", 0)),
                            "Pair": trade.get("pair", "Unknown"),
                            "Type": trade.get("type", "Unknown"),
                            "Amount": trade.get("amount", 0),
                            "Price": trade.get("price", 0),
                            "Cost": trade.get("cost", 0),
                            "Profit USD": trade.get("profit_usd", 0)
                        })
                    
                    if history_data:
                        history_df = pd.DataFrame(history_data)
                        st.dataframe(history_df)
                    else:
                        st.info("No trading history found")
                else:
                    st.info("No trading history found")

def render_profit_analytics_tab(username, exchange_manager, wallet_manager, wallet_address):
    """Render profit analytics tab"""
    st.header("Profit Analytics")
    
    # Check if wallet is available
    if not wallet_address:
        st.warning("Please connect your wallet to view profit analytics")
        return
    
    # Get profit metrics
    with st.spinner("Loading profit data..."):
        profit_metrics = wallet_manager.get_profit_metrics(wallet_address)
        exchange_profits = exchange_manager.calculate_profit_stats(username)
    
    if not profit_metrics or profit_metrics.get("total_profit", 0) == 0:
        st.info("No profit data available yet. Start trading to see analytics!")
        return
    
    # Summary metrics
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.metric(
            "Total Profit", 
            f"${profit_metrics.get('total_profit', 0):.2f}"
        )
    
    with col2:
        st.metric(
            "Your Share", 
            f"${profit_metrics.get('user_share', 0):.2f}"
        )
    
    with col3:
        st.metric(
            "Completed Trades", 
            f"{profit_metrics.get('trades_count', 0)}"
        )
    
    with col4:
        win_rate = 0
        if exchange_profits.get("total_trades", 0) > 0:
            win_rate = (exchange_profits.get("profitable_trades", 0) / 
                       exchange_profits.get("total_trades", 0) * 100)
        st.metric(
            "Win Rate", 
            f"{win_rate:.1f}%"
        )
    
    # Time-based profit charts
    st.subheader("Profit Over Time")
    
    # Daily profit chart
    daily_profits = profit_metrics.get("metrics", {}).get("daily", [])
    if daily_profits:
        daily_df = pd.DataFrame(daily_profits)
        
        # Convert date strings to datetime for proper sorting
        daily_df["date"] = pd.to_datetime(daily_df["date"])
        daily_df = daily_df.sort_values("date")
        
        # Calculate cumulative profits
        daily_df["cumulative_profit"] = daily_df["profit"].cumsum()
        
        # Create figure with secondary y-axis
        fig = go.Figure()
        
        # Add daily profit bars
        fig.add_trace(
            go.Bar(
                x=daily_df["date"],
                y=daily_df["profit"],
                name="Daily Profit",
                marker_color="lightgreen"
            )
        )
        
        # Add cumulative profit line
        fig.add_trace(
            go.Scatter(
                x=daily_df["date"],
                y=daily_df["cumulative_profit"],
                name="Cumulative Profit",
                mode="lines+markers",
                marker=dict(color="blue"),
                line=dict(width=3)
            )
        )
        
        # Update layout
        fig.update_layout(
            title="Daily and Cumulative Profits",
            xaxis_title="Date",
            yaxis_title="Profit (USD)",
            hovermode="x unified",
            legend=dict(
                orientation="h",
                yanchor="bottom",
                y=1.02,
                xanchor="right",
                x=1
            )
        )
        
        st.plotly_chart(fig, use_container_width=True)
    else:
        st.info("Not enough daily profit data available yet")
    
    # Profit by source
    st.subheader("Profit by Source")
    
    source_profits = profit_metrics.get("metrics", {}).get("by_source", [])
    if source_profits:
        source_df = pd.DataFrame(source_profits)
        
        # Create pie chart
        fig = px.pie(
            source_df,
            values="profit",
            names="source",
            title="Profit Distribution by Source",
            hole=0.4
        )
        
        # Update layout
        fig.update_layout(
            legend=dict(
                orientation="h",
                yanchor="bottom",
                y=-0.1,
                xanchor="center",
                x=0.5
            )
        )
        
        st.plotly_chart(fig, use_container_width=True)
    else:
        st.info("Not enough source profit data available yet")
    
    # Side-by-side network and token insights
    col1, col2 = st.columns(2)
    
    with col1:
        st.subheader("Profit by Network")
        
        network_profits = profit_metrics.get("metrics", {}).get("by_network", [])
        if network_profits:
            network_df = pd.DataFrame(network_profits)
            
            # Create bar chart
            fig = px.bar(
                network_df,
                x="network",
                y="profit",
                title="Profit by Blockchain Network",
                color="profit",
                color_continuous_scale="Viridis"
            )
            
            # Update layout
            fig.update_layout(
                xaxis_title="Network",
                yaxis_title="Profit (USD)",
                coloraxis_showscale=False
            )
            
            st.plotly_chart(fig, use_container_width=True)
        else:
            st.info("Not enough network profit data available yet")
    
    with col2:
        st.subheader("Profit by Token")
        
        token_profits = profit_metrics.get("metrics", {}).get("by_token", [])
        if token_profits:
            token_df = pd.DataFrame(token_profits)
            
            # Sort by profit
            token_df = token_df.sort_values("profit", ascending=False)
            
            # Create bar chart
            fig = px.bar(
                token_df.head(10),  # Show top 10 tokens
                x="token",
                y="profit",
                title="Top 10 Tokens by Profit",
                color="profit",
                color_continuous_scale="Viridis"
            )
            
            # Update layout
            fig.update_layout(
                xaxis_title="Token",
                yaxis_title="Profit (USD)",
                coloraxis_showscale=False
            )
            
            st.plotly_chart(fig, use_container_width=True)
        else:
            st.info("Not enough token profit data available yet")

def format_timestamp(timestamp):
    """Format timestamp to readable date/time"""
    if not timestamp:
        return "N/A"
    
    try:
        dt = datetime.fromtimestamp(timestamp)
        return dt.strftime("%Y-%m-%d %H:%M:%S")
    except:
        return "Invalid timestamp"
