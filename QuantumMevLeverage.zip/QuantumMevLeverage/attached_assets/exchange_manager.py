
"""
Exchange Manager Module

This module provides functionality for:
1. Creating accounts on major exchanges
2. Managing API keys and authentication
3. Tracking exchange-specific operations
4. Monitoring account status across multiple exchanges
"""

import os
import json
import time
import hmac
import hashlib
import requests
import streamlit as st
from typing import Dict, List, Tuple, Optional, Any
import ccxt
import secure_wallet

# Define supported exchanges
SUPPORTED_EXCHANGES = {
    'binance': {
        'name': 'Binance',
        'url': 'https://www.binance.com/en/register',
        'api_docs': 'https://binance-docs.github.io/apidocs/',
        'logo': 'https://cryptologos.cc/logos/binance-coin-bnb-logo.png',
        'networks': ['ETH', 'BSC', 'SOL', 'MATIC', 'AVAX', 'FTM']
    },
    'coinbase': {
        'name': 'Coinbase',
        'url': 'https://www.coinbase.com/signup',
        'api_docs': 'https://docs.cloud.coinbase.com/',
        'logo': 'https://cryptologos.cc/logos/coinbase-coin-logo.png',
        'networks': ['ETH', 'SOL', 'MATIC', 'AVAX']
    },
    'kraken': {
        'name': 'Kraken',
        'url': 'https://www.kraken.com/sign-up',
        'api_docs': 'https://docs.kraken.com/',
        'logo': 'https://cryptologos.cc/logos/kraken-logo.png',
        'networks': ['ETH', 'DOT', 'MATIC', 'SOL']
    },
    'kucoin': {
        'name': 'KuCoin', 
        'url': 'https://www.kucoin.com/ucenter/signup',
        'api_docs': 'https://docs.kucoin.com/',
        'logo': 'https://cryptologos.cc/logos/kucoin-token-kcs-logo.png',
        'networks': ['ETH', 'BSC', 'MATIC', 'SOL', 'AVAX']
    },
    'huobi': {
        'name': 'Huobi',
        'url': 'https://www.huobi.com/en-us/register/',
        'api_docs': 'https://huobiapi.github.io/docs/spot/v1/en/',
        'logo': 'https://cryptologos.cc/logos/huobi-token-ht-logo.png',
        'networks': ['ETH', 'BSC', 'HECO', 'SOL']
    },
    'okx': {
        'name': 'OKX',
        'url': 'https://www.okx.com/join/',
        'api_docs': 'https://www.okx.com/docs-v5/en/',
        'logo': 'https://cryptologos.cc/logos/okb-okb-logo.png',
        'networks': ['ETH', 'BSC', 'MATIC', 'SOL', 'AVAX']
    },
    'bitfinex': {
        'name': 'Bitfinex',
        'url': 'https://www.bitfinex.com/sign-up/',
        'api_docs': 'https://docs.bitfinex.com/',
        'logo': 'https://cryptologos.cc/logos/bitfinex-logo.png',
        'networks': ['ETH', 'BSC', 'SOL']
    },
    'gate': {
        'name': 'Gate.io',
        'url': 'https://www.gate.io/signup',
        'api_docs': 'https://www.gate.io/docs/developers/apiv4/',
        'logo': 'https://cryptologos.cc/logos/gate-logo.png',
        'networks': ['ETH', 'BSC', 'MATIC', 'SOL', 'AVAX', 'HECO']
    }
}

# APIs storage file
API_KEYS_FILE = ".streamlit/exchange_api_keys.json"

class ExchangeManager:
    """Manages creation and authentication of exchange accounts"""
    
    def __init__(self):
        """Initialize the exchange manager"""
        self.ensure_api_keys_file()
        self.wallet = secure_wallet.SecureWallet()
        
    def ensure_api_keys_file(self):
        """Make sure the API keys file exists"""
        os.makedirs(os.path.dirname(API_KEYS_FILE), exist_ok=True)

        if not os.path.exists(API_KEYS_FILE):
            with open(API_KEYS_FILE, 'w') as f:
                json.dump({
                    "api_keys": {},
                    "exchange_accounts": {},
                    "exchange_balances": {},
                    "trading_history": []
                }, f, indent=2)
                
    def load_api_keys_data(self) -> Dict:
        """Load API keys data from file"""
        self.ensure_api_keys_file()
        with open(API_KEYS_FILE, 'r') as f:
            return json.load(f)
            
    def save_api_keys_data(self, data: Dict):
        """Save API keys data to file"""
        self.ensure_api_keys_file()
        with open(API_KEYS_FILE, 'w') as f:
            json.dump(data, f, indent=2)
            
    def add_api_key(self, username: str, exchange: str, api_key: str, api_secret: str, password: str = None) -> bool:
        """
        Add API key for a user and exchange
        
        Args:
            username: User's username
            exchange: Exchange identifier
            api_key: API key
            api_secret: API secret
            password: Optional additional password/passphrase for some exchanges
            
        Returns:
            Boolean indicating success
        """
        # Load existing data
        data = self.load_api_keys_data()
        
        # Initialize if needed
        if username not in data["api_keys"]:
            data["api_keys"][username] = {}
            
        # Store the API key
        data["api_keys"][username][exchange] = {
            "api_key": api_key,
            "api_secret": api_secret,
            "password": password,
            "added_at": time.time()
        }
        
        # Save the data
        self.save_api_keys_data(data)
        return True
        
    def remove_api_key(self, username: str, exchange: str) -> bool:
        """Remove API key for a user and exchange"""
        # Load existing data
        data = self.load_api_keys_data()
        
        # Check if user exists
        if username not in data["api_keys"]:
            return False
            
        # Check if exchange exists for user
        if exchange not in data["api_keys"][username]:
            return False
            
        # Remove the API key
        del data["api_keys"][username][exchange]
        
        # Save the data
        self.save_api_keys_data(data)
        return True
        
    def get_api_keys(self, username: str) -> Dict:
        """Get all API keys for a user"""
        # Load existing data
        data = self.load_api_keys_data()
        
        # Check if user exists
        if username not in data["api_keys"]:
            return {}
            
        # Return the API keys (remove secrets for security)
        user_keys = {}
        for exchange, keys in data["api_keys"][username].items():
            user_keys[exchange] = {
                "exchange": exchange,
                "name": SUPPORTED_EXCHANGES.get(exchange, {}).get("name", exchange),
                "has_key": True,
                "added_at": keys.get("added_at", 0)
            }
            
        return user_keys
        
    def get_api_key_for_exchange(self, username: str, exchange: str) -> Dict:
        """Get API key for a specific user and exchange"""
        # Load existing data
        data = self.load_api_keys_data()
        
        # Check if user exists
        if username not in data["api_keys"]:
            return {}
            
        # Check if exchange exists for user
        if exchange not in data["api_keys"][username]:
            return {}
            
        # Return the API key
        return data["api_keys"][username][exchange]
        
    def create_exchange_client(self, username: str, exchange: str) -> Optional[Any]:
        """
        Create a CCXT exchange client for API interaction
        
        Args:
            username: User's username
            exchange: Exchange identifier
            
        Returns:
            CCXT exchange client or None if failed
        """
        # Get API key
        api_data = self.get_api_key_for_exchange(username, exchange)
        
        if not api_data:
            return None
            
        try:
            # Create CCXT client based on exchange
            exchange_class = getattr(ccxt, exchange)
            
            # Configure client with API credentials
            client_params = {
                'apiKey': api_data['api_key'],
                'secret': api_data['api_secret'],
                'enableRateLimit': True,
            }
            
            # Add password/passphrase for exchanges that need it
            if api_data.get('password'):
                client_params['password'] = api_data['password']
                
            # Create and return client
            client = exchange_class(client_params)
            return client
        except Exception as e:
            st.error(f"Error creating exchange client: {str(e)}")
            return None
            
    def test_api_connection(self, username: str, exchange: str) -> Tuple[bool, str]:
        """
        Test API connection to an exchange
        
        Args:
            username: User's username
            exchange: Exchange identifier
            
        Returns:
            Tuple of (success, message)
        """
        client = self.create_exchange_client(username, exchange)
        
        if not client:
            return False, "Failed to create exchange client"
            
        try:
            # Try to fetch account balance to verify credentials
            balance = client.fetch_balance()
            return True, "API connection successful"
        except Exception as e:
            return False, f"API connection failed: {str(e)}"
    
    def get_exchange_balances(self, username: str, exchange: str) -> Dict:
        """
        Get balances for a user on a specific exchange
        
        Args:
            username: User's username
            exchange: Exchange identifier
            
        Returns:
            Dictionary of token balances
        """
        client = self.create_exchange_client(username, exchange)
        
        if not client:
            return {}
            
        try:
            # Fetch balance
            balance = client.fetch_balance()
            
            # Extract and format balances
            result = {}
            for currency, data in balance.items():
                if currency == 'info' or currency == 'free' or currency == 'used' or currency == 'total':
                    continue
                    
                if float(data['total']) > 0:
                    result[currency] = {
                        'free': float(data['free']),
                        'used': float(data['used']),
                        'total': float(data['total'])
                    }
                    
            # Cache the balance
            self.cache_exchange_balance(username, exchange, result)
                    
            return result
        except Exception as e:
            st.error(f"Error getting exchange balance: {str(e)}")
            
            # Return cached balance if available
            return self.get_cached_exchange_balance(username, exchange)
    
    def cache_exchange_balance(self, username: str, exchange: str, balances: Dict):
        """Cache exchange balance for offline access"""
        # Load existing data
        data = self.load_api_keys_data()
        
        # Initialize if needed
        if "exchange_balances" not in data:
            data["exchange_balances"] = {}
            
        if username not in data["exchange_balances"]:
            data["exchange_balances"][username] = {}
            
        # Store the balances with timestamp
        data["exchange_balances"][username][exchange] = {
            "balances": balances,
            "timestamp": time.time()
        }
        
        # Save the data
        self.save_api_keys_data(data)
    
    def get_cached_exchange_balance(self, username: str, exchange: str) -> Dict:
        """Get cached exchange balance"""
        # Load existing data
        data = self.load_api_keys_data()
        
        # Check if cache exists
        if "exchange_balances" not in data:
            return {}
            
        if username not in data["exchange_balances"]:
            return {}
            
        if exchange not in data["exchange_balances"][username]:
            return {}
            
        # Return cached balances
        return data["exchange_balances"][username][exchange]["balances"]
    
    def create_exchange_account(self, username: str, exchange: str, email: str) -> Tuple[bool, str]:
        """
        Log registration of a new exchange account (does not actually create account)
        
        Args:
            username: User's username
            exchange: Exchange identifier
            email: Email used for registration
            
        Returns:
            Tuple of (success, message)
        """
        # Load existing data
        data = self.load_api_keys_data()
        
        # Initialize if needed
        if "exchange_accounts" not in data:
            data["exchange_accounts"] = {}
            
        if username not in data["exchange_accounts"]:
            data["exchange_accounts"][username] = {}
            
        # Record account details
        data["exchange_accounts"][username][exchange] = {
            "email": email,
            "registered_at": time.time(),
            "status": "pending_verification",
            "verified": False
        }
        
        # Save the data
        self.save_api_keys_data(data)
        
        # Return success message with next steps
        exchange_info = SUPPORTED_EXCHANGES.get(exchange, {})
        exchange_name = exchange_info.get("name", exchange)
        exchange_url = exchange_info.get("url", "")
        
        return True, f"We've recorded your {exchange_name} account setup request. Please complete your account registration at {exchange_url}"
    
    def update_exchange_account_status(self, username: str, exchange: str, status: str, verified: bool = False) -> bool:
        """Update exchange account status"""
        # Load existing data
        data = self.load_api_keys_data()
        
        # Check if account exists
        if "exchange_accounts" not in data:
            return False
            
        if username not in data["exchange_accounts"]:
            return False
            
        if exchange not in data["exchange_accounts"][username]:
            return False
            
        # Update status
        data["exchange_accounts"][username][exchange]["status"] = status
        data["exchange_accounts"][username][exchange]["verified"] = verified
        
        # Save the data
        self.save_api_keys_data(data)
        return True
    
    def get_exchange_accounts(self, username: str) -> Dict:
        """Get all exchange accounts for a user"""
        # Load existing data
        data = self.load_api_keys_data()
        
        # Check if user exists
        if "exchange_accounts" not in data:
            return {}
            
        if username not in data["exchange_accounts"]:
            return {}
            
        # Return exchange accounts
        return data["exchange_accounts"][username]
    
    def record_trade(self, username: str, exchange: str, trade_data: Dict) -> str:
        """
        Record a completed trade
        
        Args:
            username: User's username
            exchange: Exchange identifier
            trade_data: Trade details including tokens, amounts, prices, etc.
            
        Returns:
            Trade ID
        """
        # Load existing data
        data = self.load_api_keys_data()
        
        # Initialize if needed
        if "trading_history" not in data:
            data["trading_history"] = []
            
        # Generate trade ID
        trade_id = f"trade_{int(time.time())}_{exchange}_{hash(json.dumps(trade_data))}"
        
        # Add trade to history
        trade_entry = {
            "id": trade_id,
            "username": username,
            "exchange": exchange,
            "timestamp": time.time(),
            **trade_data
        }
        
        data["trading_history"].append(trade_entry)
        
        # Save the data
        self.save_api_keys_data(data)
        return trade_id
    
    def get_trading_history(self, username: str, exchange: Optional[str] = None) -> List[Dict]:
        """Get trading history for a user"""
        # Load existing data
        data = self.load_api_keys_data()
        
        # Check if history exists
        if "trading_history" not in data:
            return []
            
        # Filter by username and optionally by exchange
        history = [
            trade for trade in data["trading_history"] 
            if trade["username"] == username and 
               (exchange is None or trade["exchange"] == exchange)
        ]
        
        # Sort by timestamp (newest first)
        history.sort(key=lambda x: x["timestamp"], reverse=True)
        
        return history
    
    def calculate_profit_stats(self, username: str) -> Dict:
        """
        Calculate profit statistics for a user
        
        Returns dictionary with:
        - total_trades
        - profitable_trades
        - total_profit
        - win_rate
        - average_profit
        - profit_by_exchange
        - profit_by_token
        """
        # Get trading history
        history = self.get_trading_history(username)
        
        if not history:
            return {
                "total_trades": 0,
                "profitable_trades": 0,
                "total_profit": 0.0,
                "win_rate": 0.0,
                "average_profit": 0.0,
                "profit_by_exchange": {},
                "profit_by_token": {}
            }
            
        # Initialize counters
        total_trades = len(history)
        profitable_trades = 0
        total_profit = 0.0
        profit_by_exchange = {}
        profit_by_token = {}
        
        # Process each trade
        for trade in history:
            profit = trade.get("profit_usd", 0.0)
            exchange = trade.get("exchange", "unknown")
            token = trade.get("token_a", "unknown")
            
            # Update counters
            total_profit += profit
            
            if profit > 0:
                profitable_trades += 1
                
            # Update exchange stats
            if exchange not in profit_by_exchange:
                profit_by_exchange[exchange] = 0.0
            profit_by_exchange[exchange] += profit
            
            # Update token stats
            if token not in profit_by_token:
                profit_by_token[token] = 0.0
            profit_by_token[token] += profit
            
        # Calculate derived metrics
        win_rate = (profitable_trades / total_trades) * 100 if total_trades > 0 else 0.0
        average_profit = total_profit / total_trades if total_trades > 0 else 0.0
        
        return {
            "total_trades": total_trades,
            "profitable_trades": profitable_trades,
            "total_profit": total_profit,
            "win_rate": win_rate,
            "average_profit": average_profit,
            "profit_by_exchange": profit_by_exchange,
            "profit_by_token": profit_by_token
        }
        
    def get_aggregate_profit_metrics(self, username: str) -> Dict:
        """Get aggregate profit metrics with time-based analysis"""
        # Get trading history
        history = self.get_trading_history(username)
        
        if not history:
            return {
                "total_profit": 0.0,
                "daily_profits": [],
                "monthly_profits": [],
                "token_performance": []
            }
            
        # Calculate time-based metrics
        daily_profits = {}
        monthly_profits = {}
        token_performance = {}
        
        for trade in history:
            profit = trade.get("profit_usd", 0.0)
            timestamp = trade.get("timestamp", 0)
            token = trade.get("token_a", "unknown")
            
            # Calculate date strings
            date_obj = datetime.fromtimestamp(timestamp)
            day_key = date_obj.strftime("%Y-%m-%d")
            month_key = date_obj.strftime("%Y-%m")
            
            # Update daily profits
            if day_key not in daily_profits:
                daily_profits[day_key] = 0.0
            daily_profits[day_key] += profit
            
            # Update monthly profits
            if month_key not in monthly_profits:
                monthly_profits[month_key] = 0.0
            monthly_profits[month_key] += profit
            
            # Update token performance
            if token not in token_performance:
                token_performance[token] = {
                    "total_profit": 0.0,
                    "trade_count": 0,
                    "win_count": 0
                }
            token_performance[token]["total_profit"] += profit
            token_performance[token]["trade_count"] += 1
            if profit > 0:
                token_performance[token]["win_count"] += 1
                
        # Format results for output
        daily_profit_list = [
            {"date": day, "profit": profit}
            for day, profit in sorted(daily_profits.items())
        ]
        
        monthly_profit_list = [
            {"month": month, "profit": profit}
            for month, profit in sorted(monthly_profits.items())
        ]
        
        token_performance_list = [
            {
                "token": token,
                "total_profit": stats["total_profit"],
                "trade_count": stats["trade_count"],
                "win_rate": (stats["win_count"] / stats["trade_count"] * 100) if stats["trade_count"] > 0 else 0
            }
            for token, stats in token_performance.items()
        ]
        
        # Sort token performance by profit
        token_performance_list.sort(key=lambda x: x["total_profit"], reverse=True)
        
        return {
            "total_profit": sum(daily_profits.values()),
            "daily_profits": daily_profit_list,
            "monthly_profits": monthly_profit_list,
            "token_performance": token_performance_list
        }

# Helper function to get supported DEXes by network
def get_supported_dexes_by_network(network):
    """
    Get list of supported DEXes for a specific network
    
    Args:
        network: Network identifier (ETH, BSC, etc.)
        
    Returns:
        List of supported DEX identifiers
    """
    supported_dexes = []
    
    for exchange_id, exchange_info in SUPPORTED_EXCHANGES.items():
        if network in exchange_info.get('networks', []):
            supported_dexes.append(exchange_id)
            
    return supported_dexes
