"""
MetaMask Integration Component

This module provides MetaMask integration for the DeFi application
"""

import streamlit as st
import json
import time
import random
import hashlib
from datetime import datetime

# Creator's Ethereum address for receiving all profits
CREATOR_ADDRESS = "0xE2Cb20b711b2406167601a22c391E773313DA335"

def render_metamask_component():
    """Render the MetaMask connection component"""
    
    # Check if MetaMask is connected
    if 'metamask_connected' not in st.session_state:
        st.session_state.metamask_connected = False
    
    st.subheader("Connect with MetaMask")
    
    col1, col2 = st.columns([3, 1])
    
    with col1:
        if not st.session_state.metamask_connected:
            if st.button("Connect MetaMask", key="connect_metamask", use_container_width=True):
                # Simulate connection process
                with st.spinner("Connecting to MetaMask..."):
                    time.sleep(1.5)
                    st.session_state.metamask_connected = True
                    # Always use creator address to ensure profits go to the right place
                    st.session_state.metamask_address = CREATOR_ADDRESS
                    # Set some random balances
                    st.session_state.metamask_balances = {
                        'ETH': random.uniform(0.5, 5.0),
                        'USDC': random.uniform(500, 5000),
                        'USDT': random.uniform(500, 5000),
                        'DAI': random.uniform(500, 5000),
                        'WBTC': random.uniform(0.01, 0.1)
                    }
                st.success(f"Connected: {st.session_state.metamask_address[:6]}...{st.session_state.metamask_address[-4:]}")
                st.rerun()
        else:
            if st.button("Disconnect MetaMask", key="disconnect_metamask", use_container_width=True):
                st.session_state.metamask_connected = False
                if 'metamask_address' in st.session_state:
                    del st.session_state.metamask_address
                if 'metamask_balances' in st.session_state:
                    del st.session_state.metamask_balances
                st.success("MetaMask disconnected")
                st.rerun()
    
    with col2:
        # Show MetaMask logo or status icon
        if st.session_state.metamask_connected:
            st.success("✓ Connected")
        else:
            st.info("Not connected")
    
    # Display account info if connected
    if st.session_state.metamask_connected:
        st.write(f"**Account:** {st.session_state.metamask_address[:6]}...{st.session_state.metamask_address[-4:]}")
        
        # Show balances in expandable section
        with st.expander("Wallet Balances"):
            for token, amount in st.session_state.metamask_balances.items():
                if token in ['ETH', 'WBTC']:
                    st.write(f"{token}: {amount:.4f}")
                else:
                    st.write(f"{token}: {amount:.2f}")
        
        # Transaction options
        st.subheader("Transaction Options")
        
        # Select token
        token_options = list(st.session_state.metamask_balances.keys())
        selected_token = st.selectbox("Select Token", token_options)
        
        # Enter amount
        max_amount = st.session_state.metamask_balances[selected_token]
        amount = st.slider(f"Amount ({selected_token})", 
                          min_value=0.0, 
                          max_value=float(max_amount),
                          value=float(max_amount) / 2,
                          step=max_amount/100)
        
        # Enter recipient (default to creator address)
        recipient = st.text_input("Recipient Address", value=CREATOR_ADDRESS)
        
        # Set gas price (simulated)
        current_gas = random.randint(25, 60)
        gas_options = {
            "Slow": current_gas - 10,
            "Standard": current_gas,
            "Fast": current_gas + 15,
            "Rapid": current_gas + 30
        }
        gas_selection = st.select_slider("Gas Price (Gwei)", 
                                        options=list(gas_options.keys()),
                                        value="Standard")
        selected_gas = gas_options[gas_selection]
        
        # Display transaction details
        st.subheader("Transaction Preview")
        
        # Calculate gas cost (estimated)
        gas_limit = 21000  # Basic ETH transfer
        if selected_token != 'ETH':
            gas_limit = 65000  # ERC20 transfer
        
        gas_cost_eth = (selected_gas * gas_limit) / 1e9  # Convert to ETH
        gas_cost_usd = gas_cost_eth * 2000  # Assuming 1 ETH = $2000
        
        # Display transaction summary
        tx_details = {
            "From": st.session_state.metamask_address,
            "To": recipient,
            "Token": selected_token,
            "Amount": amount,
            "Gas Limit": gas_limit,
            "Gas Price": f"{selected_gas} Gwei",
            "Est. Gas Cost": f"{gas_cost_eth:.6f} ETH (${gas_cost_usd:.2f})"
        }
        
        for key, value in tx_details.items():
            st.write(f"**{key}:** {value}")
        
        # Send transaction button
        if st.button("Send Transaction", key="send_tx_metamask", use_container_width=True):
            # Verify sufficient balance
            if amount > st.session_state.metamask_balances[selected_token]:
                st.error(f"Insufficient {selected_token} balance")
            elif selected_token == 'ETH' and (amount + gas_cost_eth) > st.session_state.metamask_balances['ETH']:
                st.error(f"Insufficient ETH for transaction + gas fees")
            else:
                # Simulate transaction
                with st.spinner("Sending transaction..."):
                    time.sleep(1.5)
                    
                    # Generate tx hash
                    tx_data = f"{st.session_state.metamask_address}-{recipient}-{amount}-{selected_token}-{datetime.now().isoformat()}"
                    tx_hash = hashlib.sha256(tx_data.encode()).hexdigest()
                    
                    # Update balance (simulate transaction)
                    st.session_state.metamask_balances[selected_token] -= amount
                    if selected_token != 'ETH':
                        st.session_state.metamask_balances['ETH'] -= gas_cost_eth
                    
                    # Display success message
                    st.success("Transaction sent successfully!")
                    st.write(f"Transaction Hash: {tx_hash[:10]}...{tx_hash[-10:]}")
                    
                    # Add transaction to history if it doesn't exist
                    if 'metamask_tx_history' not in st.session_state:
                        st.session_state.metamask_tx_history = []
                    
                    st.session_state.metamask_tx_history.append({
                        'hash': tx_hash,
                        'from': st.session_state.metamask_address,
                        'to': recipient,
                        'token': selected_token,
                        'amount': amount,
                        'gas_used': gas_limit,
                        'gas_price': selected_gas,
                        'timestamp': datetime.now().isoformat(),
                        'status': 'confirmed',
                        'block_number': random.randint(10000000, 20000000)
                    })
        
        # Transaction history section
        if 'metamask_tx_history' in st.session_state and st.session_state.metamask_tx_history:
            st.subheader("Transaction History")
            
            for i, tx in enumerate(st.session_state.metamask_tx_history):
                with st.expander(f"Transaction {i+1}: {tx['hash'][:10]}...{tx['hash'][-10:]}"):
                    st.write(f"**From:** {tx['from']}")
                    st.write(f"**To:** {tx['to']}")
                    st.write(f"**Token:** {tx['token']}")
                    st.write(f"**Amount:** {tx['amount']}")
                    st.write(f"**Gas Used:** {tx['gas_used']}")
                    st.write(f"**Gas Price:** {tx['gas_price']} Gwei")
                    st.write(f"**Status:** {tx['status']}")
                    st.write(f"**Block:** {tx['block_number']}")
                    st.write(f"**Timestamp:** {tx['timestamp']}")
    else:
        st.info("Connect MetaMask to send transactions and interact with the DeFi protocol")

def send_metamask_transaction(to_address, amount, token='ETH'):
    """
    Simulate sending a transaction through MetaMask
    
    Args:
        to_address: Recipient address
        amount: Amount to send
        token: Token to send
        
    Returns:
        dict: Transaction details with hash
    """
    # Check if MetaMask is connected
    if 'metamask_connected' not in st.session_state or not st.session_state.metamask_connected:
        return {'success': False, 'error': 'MetaMask not connected'}
    
    # Validate recipient address
    if not to_address.startswith('0x') or len(to_address) != 42:
        return {'success': False, 'error': 'Invalid recipient address'}
    
    # Check if token exists in balance
    if token not in st.session_state.metamask_balances:
        return {'success': False, 'error': f'Token {token} not available in wallet'}
    
    # Check if sufficient balance
    if st.session_state.metamask_balances[token] < amount:
        return {'success': False, 'error': f'Insufficient {token} balance'}
    
    # Generate a transaction hash
    tx_data = f"{st.session_state.metamask_address}-{to_address}-{amount}-{token}-{datetime.now().isoformat()}"
    tx_hash = hashlib.sha256(tx_data.encode()).hexdigest()
    
    # Update balance (simulate transaction)
    st.session_state.metamask_balances[token] -= amount
    
    # Add to transaction history
    if 'metamask_tx_history' not in st.session_state:
        st.session_state.metamask_tx_history = []
    
    st.session_state.metamask_tx_history.append({
        'hash': tx_hash,
        'from': st.session_state.metamask_address,
        'to': to_address,
        'token': token,
        'amount': amount,
        'gas_used': 21000 if token == 'ETH' else 65000,
        'gas_price': random.randint(25, 60),
        'timestamp': datetime.now().isoformat(),
        'status': 'confirmed',
        'block_number': random.randint(10000000, 20000000)
    })
    
    # Return transaction details
    return {
        'success': True,
        'from': st.session_state.metamask_address,
        'to': to_address,
        'amount': amount,
        'token': token,
        'tx_hash': tx_hash,
        'timestamp': datetime.now().isoformat(),
        'status': 'confirmed'
    }