import streamlit as st
import pandas as pd
import numpy as np
import plotly.graph_objects as go
import plotly.express as px
import time
from datetime import datetime, timedelta
import json
import requests
from web3 import Web3
import os

# Import project modules
import ethereum_connector
import real_flash_swap

class MEVPredator:
    """
    Class for detecting and executing MEV opportunities
    """
    def __init__(self, w3, aggression_level=5):
        self.w3 = w3
        self.aggression_level = min(10, max(1, aggression_level))
        self.active_strategies = []
        self.min_profit = 0.001  # ETH
        self.target_builders = ["flashbots"]
        self.last_block_checked = 0
        self.opportunities = []
        self.active_bundles = []

        # Initialize stats tracking
        self.stats = {
            'total_profit': 0.0,
            'total_txs': 0,
            'successful_txs': 0,
            'failed_txs': 0,
            'highest_profit': 0.0,
            'last_executed': None,
            'start_time': datetime.now(),
            'strategies_used': {}
        }
        self.history = []

    def set_aggression_level(self, level):
        """Set the aggression level for MEV strategies"""
        self.aggression_level = min(10, max(1, level))

    def set_active_strategies(self, strategies):
        """Set active MEV strategies"""
        self.active_strategies = strategies

    def set_min_profit(self, min_profit):
        """Set minimum profit threshold in ETH"""
        self.min_profit = min_profit

    def set_target_builders(self, builders):
        """Set target block builders"""
        self.target_builders = builders

    def scan_mempool(self):
        """Scan the mempool for MEV opportunities"""
        if not self.w3 or not self.w3.is_connected():
            return []

        try:
            # Get latest block
            latest_block = self.w3.eth.block_number

            # Skip if we've already checked this block
            if latest_block <= self.last_block_checked:
                return []

            self.last_block_checked = latest_block

            # Get pending transactions
            pending_txs = self.w3.eth.get_block('pending', full_transactions=True)['transactions']

            opportunities = []

            # Look for sandwich opportunities
            if "Sandwich Attack" in self.active_strategies:
                sandwich_opps = self._find_sandwich_opportunities(pending_txs)
                opportunities.extend(sandwich_opps)

            # Look for backrunning opportunities
            if "Backrunning" in self.active_strategies:
                backrun_opps = self._find_backrun_opportunities(pending_txs)
                opportunities.extend(backrun_opps)

            # Add other MEV strategies here

            # Filter by minimum profit
            opportunities = [opp for opp in opportunities if opp['estimated_profit'] >= self.min_profit]

            # Sort by profit (highest first)
            opportunities.sort(key=lambda x: x['estimated_profit'], reverse=True)

            self.opportunities = opportunities
            return opportunities

        except Exception as e:
            print(f"Error scanning mempool: {str(e)}")
            return []

    def _find_sandwich_opportunities(self, pending_txs):
        """Find sandwich attack opportunities in pending transactions"""
        # This would analyze DEX swaps in the mempool to find sandwich opportunities
        # Implementation would require deep analysis of pending transactions,
        # identifying large swaps on AMMs, and calculating price impact
        # Placeholder for demonstration - using original code's simulation
        # Simulate some sandwich opportunities
        num_sandwich_opps = random.randint(0, 5)  # Simulate 0-5 sandwich opportunities
        sandwich_opps = []
        for _ in range(num_sandwich_opps):
            estimated_profit = random.uniform(0.001, 0.05)
            target_tx = '0x' + ''.join(random.choices('0123456789abcdef', k=64))
            sandwich_opps.append({'type': 'Sandwich Attack', 'estimated_profit': estimated_profit, 'target_tx': target_tx})
        return sandwich_opps

    def _find_backrun_opportunities(self, pending_txs):
        """Find backrunning opportunities in pending transactions"""
        # This would identify transactions that will cause price changes
        # or arbitrage opportunities when they're executed
        # Placeholder for demonstration - using original code's simulation
        num_backrun_opps = random.randint(0, 3)  # Simulate 0-3 backrunning opportunities
        backrun_opps = []
        for _ in range(num_backrun_opps):
            estimated_profit = random.uniform(0.001, 0.03)
            target_tx = '0x' + ''.join(random.choices('0123456789abcdef', k=64))
            backrun_opps.append({'type': 'Backrunning', 'estimated_profit': estimated_profit, 'target_tx': target_tx})
        return backrun_opps



    def execute_opportunity(self, opportunity):
        """Execute an MEV opportunity"""
        # This would build and submit a transaction bundle to MEV-Boost or Flashbots

        # Build the transaction bundle
        bundle = self._build_transaction_bundle(opportunity)

        # Submit the bundle to builders
        success, tx_hash = self._submit_bundle(bundle)

        return {
            'success': success,
            'tx_hash': tx_hash,
            'opportunity': opportunity
        }

    def _build_transaction_bundle(self, opportunity):
        """Build a transaction bundle for an MEV opportunity"""
        # Implementation would build the necessary transactions for the opportunity type

        # Placeholder
        return {}

    def _submit_bundle(self, bundle):
        """Submit a bundle to block builders"""
        # Implementation would submit to flashbots or other builders

        # Placeholder
        return False, None

    def get_stats(self):
        """Get MEV predator statistics"""
        return {
            'aggression_level': self.aggression_level,
            'active_strategies': self.active_strategies,
            'opportunities_found': len(self.opportunities),
            'active_bundles': len(self.active_bundles),
            'min_profit': self.min_profit,
            'target_builders': self.target_builders
        }

    def get_performance_stats(self):
        """Get performance statistics"""
        # Calculate uptime
        start_time = self.stats['start_time']
        uptime_seconds = (datetime.now() - start_time).total_seconds()
        uptime_hours = uptime_seconds / 3600

        # Calculate profit per hour
        hourly_profit = self.stats['total_profit'] / uptime_hours if uptime_hours > 0 else 0

        # Calculate success rate
        success_rate = self.stats['successful_txs'] / self.stats['total_txs'] if self.stats['total_txs'] > 0 else 0

        # Calculate strategy distribution
        strategy_counts = self.stats['strategies_used']
        total_strategies = sum(strategy_counts.values()) if strategy_counts else 0
        strategy_distribution = {
            k: v / total_strategies for k, v in strategy_counts.items()
        } if total_strategies > 0 else {}

        return {
            'total_profit_eth': self.stats['total_profit'],
            'total_transactions': self.stats['total_txs'],
            'successful_transactions': self.stats['successful_txs'],
            'failed_transactions': self.stats['failed_txs'],
            'success_rate': success_rate,
            'highest_profit_eth': self.stats['highest_profit'],
            'last_executed': self.stats['last_executed'],
            'uptime_hours': uptime_hours,
            'hourly_profit_eth': hourly_profit,
            'strategy_distribution': strategy_distribution,
            'aggression_level': self.aggression_level
        }

    def update_stats(self, result):
        if result['success']:
            profit = result['opportunity']['estimated_profit']
            self.stats['total_profit'] += profit
            self.stats['total_txs'] += 1
            self.stats['successful_txs'] += 1
            self.stats['highest_profit'] = max(self.stats['highest_profit'], profit)
            self.stats['last_executed'] = datetime.now()
            strategy_name = result['opportunity']['type']
            self.stats['strategies_used'][strategy_name] = self.stats['strategies_used'].get(strategy_name, 0) + 1
            self.history.append({
                'strategy': strategy_name,
                'timestamp': datetime.now(),
                'profit': profit,
                'success': True,
                'tx_hash': result['tx_hash']
            })
        else:
            self.stats['total_txs'] += 1
            self.stats['failed_txs'] += 1
            strategy_name = result['opportunity'].get('type', 'unknown')
            self.history.append({
                'strategy': strategy_name,
                'timestamp': datetime.now(),
                'profit': 0,
                'success': False,
                'reason': result.get('reason', 'Unknown error')
            })



def mev_predator_ui():
    """UI for MEV predator"""
    st.title("MEV Predator")

    st.markdown("""
    This tool allows you to detect and execute Maximal Extractable Value (MEV) opportunities
    including sandwich attacks, frontrunning, backrunning, and arbitrage.
    """)

    # Initialize Ethereum connection
    w3 = ethereum_connector.initialize_ethereum_connection()

    # Initialize MEV predator if not exists
    if 'mev_predator' not in st.session_state:
        st.session_state.mev_predator = MEVPredator(w3, aggression_level=5)

    # Create tabs for different MEV functionalities
    tab1, tab2, tab3, tab4 = st.tabs(["Dashboard", "Strategies", "Execution", "Analytics"])

    # Dashboard Tab
    with tab1:
        st.subheader("MEV Opportunities Dashboard")

        # Status indicators
        col1, col2, col3 = st.columns(3)

        with col1:
            st.metric("Network", "Ethereum Mainnet")

        with col2:
            if w3 and w3.is_connected():
                try:
                    gas_price = w3.eth.gas_price / 1e9
                    st.metric("Gas Price", f"{gas_price:.1f} Gwei")
                except:
                    st.metric("Gas Price", "Unknown")
            else:
                st.metric("Gas Price", "Unknown")

        with col3:
            if w3 and w3.is_connected():
                try:
                    block = w3.eth.block_number
                    st.metric("Latest Block", f"{block}")
                except:
                    st.metric("Latest Block", "Unknown")
            else:
                st.metric("Latest Block", "Unknown")

        # MEV Scanner
        st.subheader("MEV Scanner")

        col1, col2 = st.columns(2)

        with col1:
            if st.button("Scan for MEV Opportunities", type="primary"):
                with st.spinner("Scanning mempool for MEV opportunities..."):
                    if not w3 or not w3.is_connected():
                        st.error("Not connected to Ethereum network")
                    else:
                        # Scan mempool
                        opportunities = st.session_state.mev_predator.scan_mempool()

                        if opportunities:
                            st.success(f"Found {len(opportunities)} MEV opportunities")
                        else:
                            st.info("No MEV opportunities found in current mempool")

        with col2:
            auto_scan = st.checkbox("Enable Auto-Scanning", value=False)
            if auto_scan:
                st.info("Auto-scanning enabled. The system will continuously monitor for MEV opportunities.")

        # Show opportunities if available
        if hasattr(st.session_state.mev_predator, 'opportunities') and st.session_state.mev_predator.opportunities:
            st.subheader("Available MEV Opportunities")

            # Convert opportunities to DataFrame
            opps = pd.DataFrame(st.session_state.mev_predator.opportunities)

            # Display opportunities
            st.dataframe(opps)

            # Option to execute
            selected_opp = st.selectbox("Select opportunity to execute", range(len(opps)),
                                       format_func=lambda i: f"{opps.iloc[i]['type']} - Est. Profit: {opps.iloc[i]['estimated_profit']:.5f} ETH")

            if st.button("Execute Selected Opportunity"):
                with st.spinner("Executing MEV strategy..."):
                    # Execute the opportunity
                    result = st.session_state.mev_predator.execute_opportunity(
                        st.session_state.mev_predator.opportunities[selected_opp]
                    )
                    st.session_state.mev_predator.update_stats(result)
                    if result['success']:
                        st.success(f"MEV transaction executed successfully! Tx hash: {result['tx_hash']}")
                    else:
                        st.error("Failed to execute MEV transaction")
        else:
            st.info("No MEV opportunities currently available")

            # Show a placeholder visualization
            st.subheader("MEV Activity (Last 24 Hours)")

            # Generate timestamps for the last 24 hours (hourly)
            now = datetime.now()
            timestamps = [now - timedelta(hours=i) for i in range(24, 0, -1)]

            # Generate placeholder MEV data
            mev_data = {
                'timestamp': timestamps,
                'sandwich_count': np.random.randint(5, 20, size=24),
                'backrun_count': np.random.randint(10, 30, size=24),
                'frontrun_count': np.random.randint(1, 10, size=24),
                'arbitrage_count': np.random.randint(15, 40, size=24)
            }

            mev_df = pd.DataFrame(mev_data)

            # Plot MEV activity
            fig = px.line(mev_df, x='timestamp', y=['sandwich_count', 'backrun_count', 'frontrun_count', 'arbitrage_count'],
                         labels={'value': 'Count', 'variable': 'MEV Type', 'timestamp': 'Time'},
                         title='MEV Activity by Type')

            st.plotly_chart(fig)

    # Strategies Tab
    with tab2:
        st.subheader("MEV Strategies Configuration")

        # Aggression slider
        aggression = st.slider(
            "MEV Aggression Level",
            min_value=1,
            max_value=10,
            value=st.session_state.mev_predator.aggression_level,
            help="Higher values = more aggressive MEV extraction"
        )

        st.session_state.mev_predator.set_aggression_level(aggression)

        # Strategy selection
        strategies = ["Sandwich Attack", "Backrunning", "Frontrunning", "JIT Liquidity", 
                     "Flash Swap Arbitrage", "Multi-DEX Arbitrage", "Liquidation Targeting"]

        active_strategies = st.multiselect(
            "Active MEV Strategies",
            options=strategies,
            default=st.session_state.mev_predator.active_strategies if st.session_state.mev_predator.active_strategies else strategies[:3],
            help="Select which MEV strategies to use"
        )

        st.session_state.mev_predator.set_active_strategies(active_strategies)

        # Profit threshold
        min_profit = st.number_input(
            "Minimum Profit Threshold (ETH)",
            min_value=0.001,
            max_value=1.0,
            value=st.session_state.mev_predator.min_profit,
            step=0.001,
            help="Minimum profit required to execute an MEV strategy"
        )

        st.session_state.mev_predator.set_min_profit(min_profit)

        # Builder selection
        builders = ["flashbots", "eden", "builder0x69", "beaverbuild", "rsync", "manifold"]

        target_builders = st.multiselect(
            "Target Block Builders",
            options=builders,
            default=st.session_state.mev_predator.target_builders,
            help="Select which block builders to use for MEV bundles"
        )

        st.session_state.mev_predator.set_target_builders(target_builders)

        # Strategy details
        st.subheader("Strategy Details")

        selected_strategy = st.selectbox("Select Strategy for Details", active_strategies)

        if selected_strategy == "Sandwich Attack":
            st.markdown("""
            **Sandwich Attack Strategy**

            This strategy identifies large pending swaps on AMMs, then executes a trade before and after
            the target transaction to profit from the price impact.

            **How it works:**
            1. Monitor mempool for large swap transactions
            2. Calculate potential price impact
            3. Execute buy transaction before target tx
            4. Wait for target tx to execute
            5. Execute sell transaction after target tx

            **Risk Level: High**
            """)
        elif selected_strategy == "Backrunning":
            st.markdown("""
            **Backrunning Strategy**

            This strategy executes trades after certain transactions that create price discrepancies or arbitrage opportunities.

            **How it works:**
            1. Monitor mempool for transactions that will impact prices
            2. Calculate potential profit from trading after these transactions
            3. Submit bundle that executes immediately after target transaction

            **Risk Level: Medium**
            """)
        elif selected_strategy == "Flash Swap Arbitrage":
            st.markdown("""
            **Flash Swap Arbitrage Strategy**

            This strategy uses flash swaps or flash loans to execute arbitrage between different markets without requiring capital.

            **How it works:**
            1. Monitor prices across multiple DEXes
            2. Identify price discrepancies that exceed gas costs and fees
            3. Execute flash swap to borrow tokens
            4. Perform arbitrage trade
            5. Return borrowed tokens plus fee in the same transaction

            **Risk Level: Low-Medium**
            """)

    # Execution Tab
    with tab3:
        st.subheader("MEV Execution Settings")

        # Gas settings
        st.slider("Max Base Fee (Gwei)", 10, 500, 100, 5)
        st.slider("Priority Fee (Gwei)", 1, 50, 5, 1)

        # Execution settings
        col1, col2 = st.columns(2)

        with col1:
            st.checkbox("Bundle Transactions", value=True)
            st.checkbox("Use Flashbots Protect", value=True)
            st.checkbox("Use Time-Preference", value=False)

        with col2:
            st.checkbox("Auto-adjust Gas", value=True)
            st.checkbox("Private Transactions", value=True)
            st.checkbox("Revert on Failure", value=True)

        # Bundle builder UI placeholder
        st.subheader("Transaction Bundle Builder")

        st.markdown("""
        The bundle builder allows you to manually create transaction bundles for MEV opportunities.
        Currently, this is a placeholder for future implementation.
        """)

        st.info("Manual bundle builder will be implemented in a future update.")

    # Analytics Tab
    with tab4:
        st.subheader("MEV Analytics")

        st.markdown("""
        This section will show analytics on your MEV activity and the overall MEV landscape. 
        Currently, it's a placeholder with sample data.
        """)

        # Sample data - would be real in production
        mev_stats = {
            'opportunities_found': 248,
            'opportunities_executed': 32,
            'success_rate': 87.5,
            'total_profit': 1.24,
            'average_profit': 0.0388,
            'gas_spent': 0.35,
            'net_profit': 0.89
        }

        # Show overall stats
        col1, col2, col3, col4 = st.columns(4)

        with col1:
            st.metric("Opportunities Found", mev_stats['opportunities_found'])
            st.metric("Success Rate", f"{mev_stats['success_rate']}%")

        with col2:
            st.metric("Executed", mev_stats['opportunities_executed'])
            st.metric("Average Profit", f"{mev_stats['average_profit']:.4f} ETH")

        with col3:
            st.metric("Total Profit", f"{mev_stats['total_profit']:.4f} ETH")
            st.metric("Gas Spent", f"{mev_stats['gas_spent']:.4f} ETH")

        with col4:
            st.metric("Net Profit", f"{mev_stats['net_profit']:.4f} ETH")
            profit_usd = mev_stats['net_profit'] * 3000  # Assuming ETH price
            st.metric("Net Profit (USD)", f"${profit_usd:,.2f}")

        # MEV by strategy
        st.subheader("MEV by Strategy")

        strategy_data = pd.DataFrame({
            'strategy': ['Sandwich', 'Backrunning', 'Arbitrage', 'Frontrunning', 'JIT Liquidity'],
            'executed': [12, 8, 7, 3, 2],
            'profit': [0.45, 0.28, 0.31, 0.12, 0.08]
        })

        fig = px.bar(strategy_data, x='strategy', y='profit',
                    text_auto='.3f',
                    title='Profit by MEV Strategy (ETH)')
        fig.update_traces(texttemplate='%{text} ETH', textposition='outside')

        st.plotly_chart(fig)

import random