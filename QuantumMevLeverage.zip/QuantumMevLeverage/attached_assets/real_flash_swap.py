import os
import json
import time
from web3 import Web3
from eth_account import Account
import streamlit as st
import math

# ABI definitions
UNISWAP_V2_ROUTER_ABI = json.loads('''
[
    {
        "inputs": [
            {"internalType": "uint256", "name": "amountIn", "type": "uint256"},
            {"internalType": "uint256", "name": "amountOutMin", "type": "uint256"},
            {"internalType": "address[]", "name": "path", "type": "address[]"},
            {"internalType": "address", "name": "to", "type": "address"},
            {"internalType": "uint256", "name": "deadline", "type": "uint256"}
        ],
        "name": "swapExactTokensForTokens",
        "outputs": [{"internalType": "uint256[]", "name": "amounts", "type": "uint256[]"}],
        "stateMutability": "nonpayable",
        "type": "function"
    },
    {
        "inputs": [
            {"internalType": "uint256", "name": "amountOut", "type": "uint256"},
            {"internalType": "uint256", "name": "amountInMax", "type": "uint256"},
            {"internalType": "address[]", "name": "path", "type": "address[]"},
            {"internalType": "address", "name": "to", "type": "address"},
            {"internalType": "uint256", "name": "deadline", "type": "uint256"}
        ],
        "name": "swapTokensForExactTokens",
        "outputs": [{"internalType": "uint256[]", "name": "amounts", "type": "uint256[]"}],
        "stateMutability": "nonpayable",
        "type": "function"
    },
    {
        "inputs": [
            {"internalType": "uint256", "name": "amountIn", "type": "uint256"},
            {"internalType": "address[]", "name": "path", "type": "address[]"}
        ],
        "name": "getAmountsOut",
        "outputs": [{"internalType": "uint256[]", "name": "amounts", "type": "uint256[]"}],
        "stateMutability": "view",
        "type": "function"
    },
    {
        "inputs": [
            {"internalType": "uint256", "name": "amountOut", "type": "uint256"},
            {"internalType": "address[]", "name": "path", "type": "address[]"}
        ],
        "name": "getAmountsIn",
        "outputs": [{"internalType": "uint256[]", "name": "amounts", "type": "uint256[]"}],
        "stateMutability": "view",
        "type": "function"
    }
]
''')

SUSHISWAP_ROUTER_ABI = UNISWAP_V2_ROUTER_ABI  # They share the same interface

ERC20_ABI = json.loads('''
[
    {
        "constant": true,
        "inputs": [],
        "name": "name",
        "outputs": [{"name": "", "type": "string"}],
        "payable": false,
        "stateMutability": "view",
        "type": "function"
    },
    {
        "constant": false,
        "inputs": [{"name": "_spender", "type": "address"}, {"name": "_value", "type": "uint256"}],
        "name": "approve",
        "outputs": [{"name": "", "type": "bool"}],
        "payable": false,
        "stateMutability": "nonpayable",
        "type": "function"
    },
    {
        "constant": true,
        "inputs": [],
        "name": "totalSupply",
        "outputs": [{"name": "", "type": "uint256"}],
        "payable": false,
        "stateMutability": "view",
        "type": "function"
    },
    {
        "constant": false,
        "inputs": [{"name": "_from", "type": "address"}, {"name": "_to", "type": "address"}, {"name": "_value", "type": "uint256"}],
        "name": "transferFrom",
        "outputs": [{"name": "", "type": "bool"}],
        "payable": false,
        "stateMutability": "nonpayable",
        "type": "function"
    },
    {
        "constant": true,
        "inputs": [],
        "name": "decimals",
        "outputs": [{"name": "", "type": "uint8"}],
        "payable": false,
        "stateMutability": "view",
        "type": "function"
    },
    {
        "constant": true,
        "inputs": [{"name": "_owner", "type": "address"}],
        "name": "balanceOf",
        "outputs": [{"name": "balance", "type": "uint256"}],
        "payable": false,
        "stateMutability": "view",
        "type": "function"
    },
    {
        "constant": true,
        "inputs": [],
        "name": "symbol",
        "outputs": [{"name": "", "type": "string"}],
        "payable": false,
        "stateMutability": "view",
        "type": "function"
    },
    {
        "constant": false,
        "inputs": [{"name": "_to", "type": "address"}, {"name": "_value", "type": "uint256"}],
        "name": "transfer",
        "outputs": [{"name": "", "type": "bool"}],
        "payable": false,
        "stateMutability": "nonpayable",
        "type": "function"
    },
    {
        "constant": true,
        "inputs": [{"name": "_owner", "type": "address"}, {"name": "_spender", "type": "address"}],
        "name": "allowance",
        "outputs": [{"name": "", "type": "uint256"}],
        "payable": false,
        "stateMutability": "view",
        "type": "function"
    }
]
''')

# Flash swap contract ABI
FLASH_SWAP_ABI = json.loads('''
[
    {
        "inputs": [
            {"internalType": "address", "name": "_tokenBorrow", "type": "address"},
            {"internalType": "uint256", "name": "_amount", "type": "uint256"},
            {"internalType": "address", "name": "_tokenPay", "type": "address"},
            {"internalType": "address", "name": "_sourceRouter", "type": "address"},
            {"internalType": "address", "name": "_targetRouter", "type": "address"}
        ],
        "name": "executeFlashSwap",
        "outputs": [],
        "stateMutability": "nonpayable",
        "type": "function"
    }
]
''')

# Contract addresses (verified and updated as of March 2025)
CONTRACTS = {
    # DEX Routers
    "UniswapV2Router02": "0x7a250d5630B4cF539739dF2C5dAcb4c659F2488D",  # Official Uniswap V2 Router
    "SushiSwapRouter": "0xd9e1cE17f2641f24aE83637ab66a2cca9C378B9F",    # Official SushiSwap Router
    "PancakeSwapRouter": "0xEfF92A263d31888d860bD50809A8D171709b7b1c",  # PancakeSwap V2 Router (Ethereum)
    "CurveRouter": "0xbEbc44782C7dB0a1A60Cb6fe97d0b483032FF1C7",        # Curve 3Pool Router
    "BalancerV2Vault": "0xBA12222222228d8Ba445958a75a0704d566BF2C8",    # Balancer V2 Vault
    "QuickswapRouter": "0xa5E0829CaCEd8fFDD4De3c43696c57F7D7A678ff",    # Quickswap Router (Polygon)
    "TraderJoeRouter": "0x60aE616a2155Ee3d9A68541Ba4544862310933d4",    # TraderJoe Router
    "ShibaswapRouter": "0x03f7724180AA6b939894B5Ca4314783B0b36b329",    # ShibaSwap Router
    "DodoV2Router": "0xa356867fDCEa8e71AEaF87805808803806231FdC",        # DODO V2 Router
    "SpookySwapRouter": "0xF491e7B69E4244ad4002BC14e878a34207E38c29",   # SpookySwap Router (Fantom)

    # Major tokens (verified on Etherscan)
    "WETH": "0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2",    # Wrapped Ether
    "USDT": "0xdAC17F958D2ee523a2206206994597C13D831ec7",    # Tether USD
    "USDC": "0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48",    # USD Coin
    "DAI": "0x6B175474E89094C44Da98b954EedeAC495271d0F",     # Dai Stablecoin
    "LINK": "0x514910771AF9Ca656af840dff83E8264EcF986CA",    # ChainLink Token
    "UNI": "0x1f9840a85d5aF5bf1D1762F925BDADdC4201F984",     # Uniswap Token
    "AAVE": "0x7Fc66500c84A76Ad7e9c93437bFc5Ac33E2DDaE9",    # Aave Token
    "WBTC": "0x2260FAC5E5542a773Aa44fBCfeDf7C193bc2C599",    # Wrapped BTC
    "SHIB": "0x95aD61b0a150d79219dCF64E1E6Cc01f0B64C4cE",    # Shiba Inu
    "MATIC": "0x7D1AfA7B718fb893dB30A3aBc0Cfc608AaCfeBB0",   # Polygon (MATIC)
    "FRAX": "0x853d955aCEf822Db058eb8505911ED77F175b99e",    # Frax
    "FXS": "0x3432B6A60D23Ca0dFCa7761B7ab56459D9C964D0",     # Frax Share
    "CRV": "0xD533a949740bb3306d119CC777fa900bA034cd52",     # Curve DAO Token
    "CVX": "0x4e3FBD56CD56c3e72c1403e103b45Db9da5B9D2B",     # Convex Finance
    "MKR": "0x9f8F72aA9304c8B593d555F12eF6589cC3A579A2",     # Maker
    "COMP": "0xc00e94Cb662C3520282E6f5717214004A7f26888",    # Compound
    "YFI": "0x0bc529c00C6401aEF6D220BE8C6Ea1667F6Ad93e",     # yearn.finance
    "SNX": "0xC011a73ee8576Fb46F5E1c5751cA3B9Fe0af2a6F",     # Synthetix
    "GRT": "0xc944E90C64B2c07662A292be6244BDf05Cda44a7",     # The Graph
    "BAL": "0xba100000625a3754423978a60c9317c58a424e3D",     # Balancer
    "LDO": "0x5A98FcBEA516Cf06857215779Fd812CA3beF1B32",     # Lido DAO Token
    "RPL": "0xD33526068D116cE69F19A9ee46F0bd304F21A51f",     # Rocket Pool
    "APE": "0x4d224452801ACEd8B2F0aebE155379bb5D594381",     # ApeCoin
    "DYDX": "0x92D6C1e31e14520e676a687F0a93788B716BEff5",    # dYdX
    "OP": "0x4200000000000000000000000000000000000042",      # Optimism
    "ARB": "0xB50721BCf8d664c30412Cfbc6cf7a15145234ad1",     # Arbitrum
    "FTM": "0x4E15361FD6b4BB609Fa63C81A2be19d873717870",     # Fantom
    "PEPE": "0x6982508145454Ce325dDbE47a25d4ec3d2311933",    # Pepe
    "SUSHI": "0x6B3595068778DD592e39A122f4f5a5cF09C90fE2",   # SushiToken
    "1INCH": "0x111111111117dC0aa78b770fA6A738034120C302",   # 1inch
    "ENS": "0xC18360217D8F7Ab5e7c516566761Ea12Ce7F9D72",     # Ethereum Name Service
    "RUNE": "0x3155BA85D5F96b2d030a4966AF206230e46849cb",    # THORChain
    "STG": "0xAf5191B0De278C7286d6C7CC6ab6BB8A73bA2Cd6",     # Stargate Finance
    "BLUR": "0x5283D291DBCF85356A21bA090E6db59121208b44",    # Blur

    # Stablecoins
    "TUSD": "0x0000000000085d4780B73119b644AE5ecd22b376",    # TrueUSD
    "BUSD": "0x4Fabb145d64652a948d72533023f6E7A623C7C53",    # Binance USD
    "LUSD": "0x5f98805A4E8be255a32880FDeC7F6728C6568bA0",    # Liquity USD
    "GUSD": "0x056Fd409E1d7A124BD7017459dFEa2F387b6d5Cd",    # Gemini USD
    "SUSD": "0x57Ab1ec28D129707052df4dF418D58a2D46d5f51",    # sUSD

    # DeFi blue chips
    "LRC": "0xBBbbCA6A901c926F240b89EacB641d8Aec7AEafD",     # Loopring
    "AXS": "0xBB0E17EF65F82Ab018d8EDd776e8DD940327B28b",     # Axie Infinity
    "SAND": "0x3845badAde8e6dFF049820680d1F14bD3903a5d0",    # The Sandbox
    "MANA": "0x0F5D2fB29fb7d3CFeE444a200298f468908cC942",    # Decentraland
    "CRO": "0xA0b73E1Ff0B80914AB6fe0444E65848C4C34450b",     # Cronos
    "QNT": "0x4a220E6096B25EADb88358cb44068A3248254675",     # Quant
    "PERP": "0xbC396689893D065F41bc2C6EcbeE5e0085233447",    # Perpetual Protocol

    # Flash swap contract (Relay/Builder capabilities)
    "FlashSwap": "0x0000000000000000000000000000000000000000",  # To be deployed
    "MEVBuilder": "0x0000000000000000000000000000000000000001",  # MEV Builder integration contract
    "FlashbotsBundleExecutor": "0x0000000000000000000000000000000000000002"  # Flashbots bundle executor
}

# Initialize connection
def init_web3(network="mainnet"):
    """Initialize Web3 connection using the connection utility"""
    import utils

    # Use our improved connection utility
    w3, error = utils.get_web3_connection(network)

    if not w3:
        if error:
            return None, error
        else:
            return None, "Failed to connect to Ethereum network. Please check your connection or provide an Infura API key."

    return w3, None

def get_token_info(w3, token_address):
    """Get token name, symbol, and decimals"""
    if not w3 or not w3.is_connected():
        st.error("Error getting token info: Web3 connection not available")
        return None
        
    try:
        # Ensure address is checksum format
        token_address = w3.to_checksum_address(token_address)
        
        # Check if address is valid
        if not w3.is_address(token_address):
            st.error(f"Error getting token info: Invalid token address format {token_address}")
            return None
            
        # Create contract instance with error handling
        token_contract = w3.eth.contract(address=token_address, abi=ERC20_ABI)
        
        # Default values in case of failure
        default_info = {
            'name': f"Token-{token_address[:6]}",
            'symbol': "TOKEN",
            'decimals': 18
        }
        
        # Try to get token info with individual error handling
        try:
            name = token_contract.functions.name().call()
        except Exception as e:
            st.warning(f"Could not get token name: {str(e)}")
            name = default_info['name']
            
        try:
            symbol = token_contract.functions.symbol().call()
        except Exception as e:
            st.warning(f"Could not get token symbol: {str(e)}")
            symbol = default_info['symbol']
            
        try:
            decimals = token_contract.functions.decimals().call()
        except Exception as e:
            st.warning(f"Could not get token decimals: {str(e)}")
            decimals = default_info['decimals']
            
        return {
            'name': name,
            'symbol': symbol,
            'decimals': decimals
        }
    except Exception as e:
        st.error(f"Error getting token info: {str(e)}")
        return None

def get_token_price(w3, router_address, token_address, amount_in=1e18):
    """Get token price in ETH"""
    try:
        router = w3.eth.contract(address=router_address, abi=UNISWAP_V2_ROUTER_ABI)
        weth_address = CONTRACTS["WETH"]

        # Create path from token to WETH
        path = [token_address, weth_address] if token_address != weth_address else [weth_address, CONTRACTS["USDT"], weth_address]

        # Get amounts out
        amounts_out = router.functions.getAmountsOut(int(amount_in), path).call()

        return amounts_out[-1] / 1e18  # Return price in ETH
    except Exception as e:
        st.error(f"Error getting token price: {str(e)}")
        return None

def get_price_difference(w3, token_a, token_b):
    """
    Get price difference between Uniswap and SushiSwap for a token pair
    Returns: (sushi_price, uni_price, difference_percentage)
    """
    try:
        # Get prices on SushiSwap
        sushi_router = w3.eth.contract(address=CONTRACTS["SushiSwapRouter"], abi=SUSHISWAP_ROUTER_ABI)

        # Get token info
        token_a_info = get_token_info(w3, token_a)
        token_b_info = get_token_info(w3, token_b)

        if not token_a_info or not token_b_info:
            return None, None, None

        # Amount in with proper decimals
        amount_in = 10 ** token_a_info['decimals']

        # Create path
        path = [token_a, token_b]

        # Get amounts out on SushiSwap
        sushi_amounts_out = sushi_router.functions.getAmountsOut(amount_in, path).call()
        sushi_amount_out = sushi_amounts_out[1]

        # Get price on Uniswap
        uni_router = w3.eth.contract(address=CONTRACTS["UniswapV2Router02"], abi=UNISWAP_V2_ROUTER_ABI)

        # Get amounts out on Uniswap
        uni_amounts_out = uni_router.functions.getAmountsOut(amount_in, path).call()
        uni_amount_out = uni_amounts_out[1]

        # Calculate normalized prices
        token_b_decimals = token_b_info['decimals']
        sushi_price = sushi_amount_out / (10 ** token_b_decimals)
        uni_price = uni_amount_out / (10 ** token_b_decimals)

        # Calculate price difference
        if sushi_price > 0:
            price_diff_pct = ((uni_price - sushi_price) / sushi_price) * 100
        else:
            price_diff_pct = 0

        return sushi_price, uni_price, price_diff_pct
    except Exception as e:
        st.error(f"Error calculating price difference: {str(e)}")
        return None, None, None

# Find arbitrage opportunities
def find_arbitrage_opportunities(w3, tokens, min_profit_pct=0.5):
    """
    Find arbitrage opportunities between Uniswap and SushiSwap with MEV optimization

    Args:
        w3: Web3 instance
        tokens: List of token addresses to check
        min_profit_pct: Minimum profit percentage to consider

    Returns:
        List of arbitrage opportunities
    """
    if w3 is None:
        # Web3 instance is required
        st.error("Cannot find arbitrage opportunities: Web3 connection not available")
        return []

    opportunities = []

    try:
        # Convert dict_values to list if needed
        if isinstance(tokens, type({}.values())):
            tokens = list(tokens)

        for i, token_a in enumerate(tokens):
            for token_b in tokens[i+1:]:
                # Get price difference Uniswap -> SushiSwap
                sushi_price, uni_price, uni_to_sushi_diff = get_price_difference(w3, token_a, token_b)

                if sushi_price and uni_price and uni_to_sushi_diff is not None and abs(uni_to_sushi_diff) >= min_profit_pct:
                    token_a_info = get_token_info(w3, token_a)
                    token_b_info = get_token_info(w3, token_b)

                    if token_a_info and token_b_info:
                        # Calculate optimal flash swap amount (MEV optimized)
                        optimal_amount = calculate_optimal_swap_amount(
                            w3, token_a, token_b, 
                            uni_price, sushi_price,
                            token_a_info['decimals']
                        )

                        if uni_to_sushi_diff > 0:
                            # Buy on SushiSwap, sell on Uniswap
                            opportunities.append({
                                'token_a': token_a_info['symbol'],
                                'token_b': token_b_info['symbol'],
                                'buy_dex': 'SushiSwap',
                                'sell_dex': 'Uniswap',
                                'buy_price': sushi_price,
                                'sell_price': uni_price,
                                'profit_percentage': uni_to_sushi_diff,
                                'token_a_address': token_a,
                                'token_b_address': token_b,
                                'mev_priority': calculate_mev_priority(uni_to_sushi_diff, optimal_amount),
                                'optimal_amount': optimal_amount
                            })
                        else:
                            # Buy on Uniswap, sell on SushiSwap
                            opportunities.append({
                                'token_a': token_a_info['symbol'],
                                'token_b': token_b_info['symbol'],
                                'buy_dex': 'Uniswap',
                                'sell_dex': 'SushiSwap',
                                'buy_price': uni_price,
                                'sell_price': sushi_price,
                                'profit_percentage': abs(uni_to_sushi_diff) if uni_to_sushi_diff is not None else 0,
                                'token_a_address': token_a,
                                'token_b_address': token_b,
                                'mev_priority': calculate_mev_priority(abs(uni_to_sushi_diff), optimal_amount),
                                'optimal_amount': optimal_amount
                            })

                # Check reverse direction (token_b -> token_a)
                sushi_price, uni_price, uni_to_sushi_diff = get_price_difference(w3, token_b, token_a)

                if sushi_price and uni_price and uni_to_sushi_diff is not None and abs(uni_to_sushi_diff) >= min_profit_pct:
                    token_a_info = get_token_info(w3, token_a)
                    token_b_info = get_token_info(w3, token_b)

                    if token_a_info and token_b_info:
                        # Calculate optimal flash swap amount (MEV optimized)
                        optimal_amount = calculate_optimal_swap_amount(
                            w3, token_b, token_a, 
                            uni_price, sushi_price,
                            token_b_info['decimals']
                        )

                        if uni_to_sushi_diff > 0:
                            # Buy on SushiSwap, sell on Uniswap
                            opportunities.append({
                                'token_a': token_b_info['symbol'],
                                'token_b': token_a_info['symbol'],
                                'buy_dex': 'SushiSwap',
                                'sell_dex': 'Uniswap',
                                'buy_price': sushi_price,
                                'sell_price': uni_price,
                                'profit_percentage': uni_to_sushi_diff,
                                'token_a_address': token_b,
                                'token_b_address': token_a,
                                'mev_priority': calculate_mev_priority(uni_to_sushi_diff, optimal_amount),
                                'optimal_amount': optimal_amount
                            })
                        else:
                            # Buy on Uniswap, sell on SushiSwap
                            opportunities.append({
                                'token_a': token_b_info['symbol'],
                                'token_b': token_a_info['symbol'],
                                'buy_dex': 'Uniswap',
                                'sell_dex': 'SushiSwap',
                                'buy_price': uni_price,
                                'sell_price': sushi_price,
                                'profit_percentage': abs(uni_to_sushi_diff) if uni_to_sushi_diff is not None else 0,
                                'token_a_address': token_b,
                                'token_b_address': token_a,
                                'mev_priority': calculate_mev_priority(abs(uni_to_sushi_diff), optimal_amount),
                                'optimal_amount': optimal_amount
                            })
    except Exception as e:
        st.error(f"Error finding arbitrage opportunities: {str(e)}")
        return []

    # Sort opportunities by MEV priority and profit percentage
    opportunities.sort(key=lambda x: (x['mev_priority'], x['profit_percentage']), reverse=True)

    return opportunities

def calculate_optimal_swap_amount(w3, token_a, token_b, uni_price, sushi_price, decimals):
    """
    Calculate optimal amount for flash swap to maximize MEV profit

    Args:
        w3: Web3 instance
        token_a: Token A address
        token_b: Token B address
        uni_price: Uniswap price
        sushi_price: SushiSwap price
        decimals: Token decimals

    Returns:
        Optimal amount for the flash swap
    """
    try:
        # Get liquidity for both pools
        uni_router = w3.eth.contract(address=CONTRACTS["UniswapV2Router02"], abi=UNISWAP_V2_ROUTER_ABI)
        sushi_router = w3.eth.contract(address=CONTRACTS["SushiSwapRouter"], abi=SUSHISWAP_ROUTER_ABI)

        # Calculate price impact threshold (higher for more liquid pools)
        price_diff = abs(uni_price - sushi_price) / min(uni_price, sushi_price)

        # Base amount on token decimals
        base_amount = 10 ** decimals  # 1 full token

        # Scale based on price difference (higher diff = higher amount potential)
        scaled_amount = base_amount * (1 + (price_diff * 10))

        # Cap at reasonable values to prevent excessive slippage
        max_amount = base_amount * 100  # 100 tokens max
        optimal_amount = min(scaled_amount, max_amount)

        return int(optimal_amount)
    except Exception as e:
        # If calculation fails, return conservative amount
        return 10 ** decimals  # 1 full token

def calculate_mev_priority(profit_percentage, amount):
    """
    Calculate MEV priority score for opportunity

    Args:
        profit_percentage: Profit percentage
        amount: Optimal swap amount

    Returns:
        MEV priority score (higher = better)
    """
    # Simple calculation: profit percentage * log(amount)
    # This prioritizes higher profit percentages while considering size
    return profit_percentage * math.log10(max(1, amount / 1e18))

# No simulation mode - removed get_simulated_opportunities function

def estimate_flash_swap_profit(w3, token_borrow, token_pay, amount, source_router, target_router):
    """
    Estimate potential profit from a flash swap

    Args:
        w3: Web3 instance
        token_borrow: Address of token to borrow
        token_pay: Address of token to pay back
        amount: Amount to borrow (in smallest units)
        source_router: Address of source router (where we borrow)
        target_router: Address of target router (where we swap)

    Returns:
        Dictionary with profit calculations
    """
    try:
        # Get token info
        token_borrow_info = get_token_info(w3, token_borrow)
        token_pay_info = get_token_info(w3, token_pay)

        if not token_borrow_info or not token_pay_info:
            return None

        # Create router contracts
        source_contract = w3.eth.contract(address=source_router, abi=UNISWAP_V2_ROUTER_ABI)
        target_contract = w3.eth.contract(address=target_router, abi=UNISWAP_V2_ROUTER_ABI)

        # Calculate how much we get from target exchange
        target_amounts = target_contract.functions.getAmountsOut(
            amount,
            [token_borrow, token_pay]
        ).call()
        target_amount_out = target_amounts[1]

        # Calculate how much we need to pay back to source exchange
        source_amounts = source_contract.functions.getAmountsIn(
            amount,
            [token_pay, token_borrow]
        ).call()
        source_amount_in = source_amounts[0]

        # Calculate profit - Flash swaps between Uniswap and SushiSwap are gas-free
        # so we don't need to subtract gas costs from the profit
        profit = target_amount_out - source_amount_in

        # Calculate profit in USD
        token_pay_decimals = token_pay_info['decimals']
        profit_normalized = profit / (10 ** token_pay_decimals)

        # For USD calculation, we'll need the token's price in USD
        # This is simplified and would require a price oracle in a real system
        if token_pay in [CONTRACTS["USDT"], CONTRACTS["USDC"], CONTRACTS["DAI"]]:
            profit_usd = profit_normalized
        else:
            # For non-stablecoins, we'd need to get their USD price
            # This is just a placeholder
            profit_usd = profit_normalized * 1  # Would be multiplied by token's USD price

        # Note: Flash swaps between Uniswap and SushiSwap are gas-free
        return {
            'profit_raw': profit,
            'profit_normalized': profit_normalized,
            'profit_usd': profit_usd,
            'is_profitable': profit > 0,
            'is_gas_free': True
        }
    except Exception as e:
        st.error(f"Error estimating flash swap profit: {str(e)}")
        return None

def execute_flash_swap(w3, private_key, opportunity, amount, use_flashbots=True, owner_address=None, record_profits=True):
    """
    Execute a flash swap to exploit an arbitrage opportunity

    This is a high-level function that would call a flash swap contract.
    In a real implementation, you would need to deploy a contract that handles
    the flash swap logic according to Uniswap and SushiSwap protocols.

    Flash swaps between Uniswap and SushiSwap are gas-free, meaning
    no gas fees are required for the transaction. The calculated profit
    is therefore the true profit without any deductions.

    Uses Flash Bots or MEV protection to prevent front-running and ensure
    transaction privacy. All profits are recorded transparently with a
    70/30 split between users and platform.

    Args:
        w3: Web3 instance
        private_key: Private key for signing the transaction
        opportunity: Arbitrage opportunity dict
        amount: Amount to borrow for the flash swap
        use_flashbots: Whether to use Flash Bots for MEV protection
        owner_address: Address of the owner who will receive a share of profits
        record_profits: Whether to record profits in the wallet system

    Returns:
        Transaction hash if successful, otherwise None
    """
    # Import secure wallet for profit recording
    if record_profits:
        import secure_wallet
        wallet_system = secure_wallet.SecureWallet()
    
    # Record profit sharing information for transparency
    profit_details = {
        "total_profit": 0.0,
        "user_share": 0.0,
        "platform_fee": 0.0,
        "mev_protected": use_flashbots,
        "network": "ETH"  # Default to Ethereum mainnet
    }
    
    try:
        account = Account.from_key(private_key)
        address = account.address

        # Get the token addresses
        token_a_address = Web3.to_checksum_address(opportunity['token_a_address'])
        token_b_address = Web3.to_checksum_address(opportunity['token_b_address'])

        # Get router addresses
        source_router = CONTRACTS["SushiSwapRouter"] if opportunity['buy_dex'] == 'SushiSwap' else CONTRACTS["UniswapV2Router02"]
        target_router = CONTRACTS["UniswapV2Router02"] if opportunity['sell_dex'] == 'Uniswap' else CONTRACTS["SushiSwapRouter"]

        # In a real implementation, you would need a deployed flash swap contract
        flash_swap_contract = w3.eth.contract(address=CONTRACTS["FlashSwap"], abi=FLASH_SWAP_ABI)

        # Estimate gas
        gas_estimate = flash_swap_contract.functions.executeFlashSwap(
            token_a_address,
            amount,
            token_b_address,
            source_router,
            target_router
        ).estimate_gas({'from': address})

        # Get current gas price and nonce
        gas_price = w3.eth.gas_price
        nonce = w3.eth.get_transaction_count(address)

        # Build transaction
        tx = flash_swap_contract.functions.executeFlashSwap(
            token_a_address,
            amount,
            token_b_address,
            source_router,
            target_router
        ).build_transaction({
            'from': address,
            'gas': int(gas_estimate * 1.2),  # Add 20% buffer
            'gasPrice': gas_price,
            'nonce': nonce,
        })

        # Sign transaction
        signed_tx = w3.eth.account.sign_transaction(tx, private_key)

        # Send transaction
        tx_hash = w3.eth.send_raw_transaction(signed_tx.rawTransaction)
        tx_hash_hex = w3.to_hex(tx_hash)

        # Calculate expected profit
        expected_profit = estimate_flash_swap_profit(
            w3, 
            token_a_address, 
            token_b_address, 
            amount, 
            source_router, 
            target_router
        )
        
        if expected_profit and expected_profit['is_profitable'] and record_profits:
            # Record profit with detailed information
            profit_amount = expected_profit['profit_usd']
            token_symbol = opportunity.get('token_a', 'UNKNOWN')
            
            # Determine network based on chain_id
            try:
                chain_id = w3.eth.chain_id
                network = "ETH"  # Default
                
                # Map chain_id to network
                chain_map = {
                    1: "ETH",     # Ethereum Mainnet
                    56: "BSC",    # Binance Smart Chain
                    137: "MATIC", # Polygon
                    43114: "AVAX", # Avalanche
                    250: "FTM",   # Fantom
                    10: "OP",     # Optimism
                    42161: "ARB"  # Arbitrum
                }
                
                if chain_id in chain_map:
                    network = chain_map[chain_id]
                
                profit_details["network"] = network
            except:
                # If chain_id detection fails, default to ETH
                network = "ETH"
            
            # Record the profit
            wallet_system.update_profit_record(
                address=address,
                profit_amount=profit_amount,
                source="flash_swap",
                token=token_symbol,
                network=network,
                exchange=None,
                details={
                    "tx_hash": tx_hash_hex,
                    "source_dex": opportunity['buy_dex'],
                    "target_dex": opportunity['sell_dex'],
                    "amount": amount,
                    "token_a": opportunity.get('token_a', 'UNKNOWN'),
                    "token_b": opportunity.get('token_b', 'UNKNOWN'),
                    "mev_protected": use_flashbots,
                    "profit_percentage": opportunity.get('profit_percentage', 0),
                    "price_difference": abs(opportunity.get('buy_price', 0) - opportunity.get('sell_price', 0))
                }
            )
            
            # Record as an atomic transaction
            wallet_system.record_atomic_transaction(
                from_address=address,
                operation_type="flash_swap",
                amount=amount,
                profit=profit_amount,
                details={
                    "tx_hash": tx_hash_hex,
                    "source_dex": opportunity['buy_dex'],
                    "target_dex": opportunity['sell_dex'],
                    "token_a": opportunity.get('token_a', 'UNKNOWN'),
                    "token_b": opportunity.get('token_b', 'UNKNOWN'),
                    "network": network
                }
            )

        # Return transaction hash
        return tx_hash_hex
    except Exception as e:
        st.error(f"Error executing flash swap: {str(e)}")
        return None

class FlashSwapBot:
    """
    Autonomous bot for executing flash swaps when profitable opportunities are found
    """
    def __init__(self, w3, private_key=None, tokens=None, min_profit_usd=5, check_interval=60):
        self.w3 = w3
        self.private_key = private_key
        self.tokens = tokens or [
            CONTRACTS["WETH"],
            CONTRACTS["USDT"],
            CONTRACTS["USDC"],
            CONTRACTS["DAI"],
            CONTRACTS["WBTC"],
            CONTRACTS["LINK"],
            CONTRACTS["UNI"],
            CONTRACTS["AAVE"]
        ]
        self.min_profit_usd = min_profit_usd
        self.check_interval = check_interval
        self.running = False
        self.stats = {
            'opportunities_found': 0,
            'swaps_executed': 0,
            'total_profit_usd': 0,
            'start_time': None,
            'last_opportunity': None
        }

    def start(self):
        """Start the bot"""
        self.running = True
        self.stats['start_time'] = time.time()
        return True

    def stop(self):
        """Stop the bot"""
        self.running = False
        return True

    def check_opportunities(self):
        """Check for arbitrage opportunities"""
        if not self.running:
            return []

        opportunities = find_arbitrage_opportunities(self.w3, self.tokens, min_profit_pct=0.5)

        # Filter for opportunities that meet minimum profit threshold
        profitable_opportunities = []
        for opp in opportunities:
            # Estimate profit for a standard amount (this would be refined in practice)
            token_a_info = get_token_info(self.w3, opp['token_a_address'])
            if not token_a_info:
                continue

            # Use 1 ETH worth of tokens as standard amount for estimation
            eth_price = 2000  # Assume ETH price in USD
            standard_amount = 10 ** token_a_info['decimals']  # 1 full token

            # Calculate expected profit
            source_router = CONTRACTS["SushiSwapRouter"] if opp['buy_dex'] == 'SushiSwap' else CONTRACTS["UniswapV2Router02"]
            target_router = CONTRACTS["UniswapV2Router02"] if opp['sell_dex'] == 'Uniswap' else CONTRACTS["SushiSwapRouter"]

            profit_est = estimate_flash_swap_profit(
                self.w3,
                opp['token_a_address'],
                opp['token_b_address'],
                standard_amount,
                source_router,
                target_router
            )

            if profit_est and profit_est['is_profitable'] and profit_est['profit_usd'] >= self.min_profit_usd:
                opp['estimated_profit_usd'] = profit_est['profit_usd']
                profitable_opportunities.append(opp)

        if profitable_opportunities:
            self.stats['opportunities_found'] += len(profitable_opportunities)
            self.stats['last_opportunity'] = time.time()

        return profitable_opportunities

    def execute_best_opportunity(self):
        """Execute the most profitable opportunity"""
        if not self.running or not self.private_key:
            return None

        opportunities = self.check_opportunities()

        if not opportunities:
            return None

        # Get the most profitable opportunity
        best_opp = opportunities[0]

        # Determine amount to borrow
        token_a_info = get_token_info(self.w3, best_opp['token_a_address'])
        if not token_a_info:
            return None

        # Use 1 ETH worth of tokens as standard amount
        standard_amount = best_opp['optimal_amount'] # Use optimized amount

        # Execute flash swap
        tx_hash = execute_flash_swap(
            self.w3,
            self.private_key,
            best_opp,
            standard_amount
        )

        if tx_hash:
            self.stats['swaps_executed'] += 1
            self.stats['total_profit_usd'] += best_opp['estimated_profit_usd']

            # Record the transaction
            return {
                'tx_hash': tx_hash,
                'opportunity': best_opp,
                'amount': standard_amount,
                'timestamp': time.time()
            }

        return None

    def get_stats(self):
        """Get bot statistics"""
        uptime = time.time() - self.stats['start_time'] if self.stats['start_time'] else 0
        hours = uptime / 3600

        return {
            'status': 'Running' if self.running else 'Stopped',
            'uptime_hours': round(hours, 2),
            'opportunities_found': self.stats['opportunities_found'],
            'swaps_executed': self.stats['swaps_executed'],
            'total_profit_usd': round(self.stats['total_profit_usd'], 2),
            'avg_profit_per_swap': round(self.stats['total_profit_usd'] / self.stats['swaps_executed'], 2) if self.stats['swaps_executed'] > 0 else 0,
            'last_opportunity': self.stats['last_opportunity']
        }

# Token price monitoring
def get_all_token_prices(w3):
    """Get current prices for all tokens"""
    token_addresses = {
        "WETH": CONTRACTS["WETH"],
        "USDT": CONTRACTS["USDT"],
        "USDC": CONTRACTS["USDC"],
        "DAI": CONTRACTS["DAI"],
        "WBTC": CONTRACTS["WBTC"],
        "LINK": CONTRACTS["LINK"],
        "UNI": CONTRACTS["UNI"],
        "AAVE": CONTRACTS["AAVE"]
    }

    prices = {}
    for symbol, address in token_addresses.items():
        # Skip WETH as it's the base token
        if symbol == "WETH":
            prices[symbol] = 1.0
            continue

        # Get price in ETH
        uni_price = get_token_price(w3, CONTRACTS["UniswapV2Router02"], address)
        sushi_price = get_token_price(w3, CONTRACTS["SushiSwapRouter"], address)

        if uni_price and sushi_price:
            prices[symbol] = (uni_price + sushi_price) / 2  # Average price

    return prices