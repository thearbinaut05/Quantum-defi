import os
import json
import time
import hashlib
import secrets
from web3 import Web3
from eth_account import Account
import streamlit as st
from typing import Dict, Tuple, Any, Optional, List

# Constants
WALLET_DATA_FILE = ".streamlit/wallet_data.json"

class SecureWallet:
    def __init__(self):
        """Initialize the secure wallet system"""
        self.ensure_wallet_data_file()
        self.w3 = Web3()

    def ensure_wallet_data_file(self):
        """Make sure the wallet data file exists"""
        os.makedirs(os.path.dirname(WALLET_DATA_FILE), exist_ok=True)

        if not os.path.exists(WALLET_DATA_FILE):
            with open(WALLET_DATA_FILE, 'w') as f:
                json.dump({
                    "wallets": {}, 
                    "balances": {},
                    "transactions": [],
                    "tokens": {
                        "ETH": {"decimals": 18, "name": "Ethereum", "symbol": "ETH"},
                        "USDT": {"decimals": 6, "name": "Tether USD", "symbol": "USDT"},
                        "USDC": {"decimals": 6, "name": "USD Coin", "symbol": "USDC"},
                        "DAI": {"decimals": 18, "name": "Dai Stablecoin", "symbol": "DAI"},
                        "BTC": {"decimals": 8, "name": "Bitcoin", "symbol": "BTC"},
                        "WBTC": {"decimals": 8, "name": "Wrapped Bitcoin", "symbol": "WBTC"},
                        "UNI": {"decimals": 18, "name": "Uniswap", "symbol": "UNI"},
                        "LINK": {"decimals": 18, "name": "Chainlink", "symbol": "LINK"},
                        "AAVE": {"decimals": 18, "name": "Aave", "symbol": "AAVE"}
                    }
                }, f, indent=2)
        else:
            # Ensure wallet data has the expected structure
            try:
                data = self.load_wallet_data()
                modified = False

                # Ensure transactions array exists
                if "transactions" not in data:
                    data["transactions"] = []
                    modified = True

                # Ensure tokens dictionary exists
                if "tokens" not in data:
                    data["tokens"] = {
                        "ETH": {"decimals": 18, "name": "Ethereum", "symbol": "ETH"},
                        "USDT": {"decimals": 6, "name": "Tether USD", "symbol": "USDT"},
                        "USDC": {"decimals": 6, "name": "USD Coin", "symbol": "USDC"},
                        "DAI": {"decimals": 18, "name": "Dai Stablecoin", "symbol": "DAI"},
                        "BTC": {"decimals": 8, "name": "Bitcoin", "symbol": "BTC"}
                    }
                    modified = True

                if modified:
                    self.save_wallet_data(data)
            except Exception as e:
                print(f"Error validating wallet data: {e}")

    def load_wallet_data(self) -> Dict:
        """Load wallet data from file"""
        self.ensure_wallet_data_file()
        with open(WALLET_DATA_FILE, 'r') as f:
            return json.load(f)

    def save_wallet_data(self, data: Dict):
        """Save wallet data to file"""
        self.ensure_wallet_data_file()
        with open(WALLET_DATA_FILE, 'w') as f:
            json.dump(data, f, indent=2)

    def create_wallet(self, username: str, password: str) -> Tuple[bool, Any]:
        """Create a new wallet for a user"""
        # Load existing data
        data = self.load_wallet_data()

        # Check if user already has a wallet
        if username in data["wallets"]:
            return False, "Wallet already exists for this user"

        # Create entropy from username, password, and random data
        entropy = username + password + secrets.token_hex(32)
        entropy_hash = hashlib.sha256(entropy.encode()).hexdigest()

        # Generate account using entropy
        account = Account.create(entropy_hash)
        private_key = account.key.hex()
        address = account.address

        # Encrypt private key with password before storing
        encryption_key = hashlib.sha256(password.encode()).hexdigest()
        encrypted_key = self.encrypt_key(private_key, encryption_key)

        # Store wallet data
        data["wallets"][username] = {
            "address": address,
            "encrypted_key": encrypted_key,
            "created_at": time.time()
        }

        # Initialize empty balances for the user
        data["balances"][address] = {}

        # Add some test tokens for new users (for demo purposes)
        self.add_test_tokens(data, address)

        self.save_wallet_data(data)

        return True, {"address": address, "private_key": private_key}

    def add_test_tokens(self, data: Dict, address: str):
        """Add test tokens to a new wallet for demonstration"""
        data["balances"][address] = {
            "ETH": 1.0,
            "USDT": 1000.0,
            "USDC": 1000.0,
            "DAI": 1000.0,
            "BTC": 0.05
        }

    def get_wallet(self, username: str, password: str) -> Tuple[bool, Any]:
        """Get a user's wallet with decrypted private key"""
        # Load existing data
        data = self.load_wallet_data()

        # Check if user has a wallet
        if username not in data["wallets"]:
            return False, "No wallet found for this user"

        wallet = data["wallets"][username]
        address = wallet["address"]
        encrypted_key = wallet["encrypted_key"]

        # Decrypt the private key
        encryption_key = hashlib.sha256(password.encode()).hexdigest()
        private_key = self.decrypt_key(encrypted_key, encryption_key)

        return True, {"address": address, "private_key": private_key}

    def update_token_balance(self, address: str, token: str, amount: float) -> bool:
        """Update token balance for a wallet"""
        data = self.load_wallet_data()

        if address not in data["balances"]:
            data["balances"][address] = {}

        data["balances"][address][token] = amount
        self.save_wallet_data(data)

        return True

    def get_token_balance(self, address: str, token: str) -> float:
        """Get token balance for a wallet"""
        data = self.load_wallet_data()

        if address not in data["balances"]:
            return 0.0

        return data["balances"][address].get(token, 0.0)

    def get_all_balances(self, address: str) -> Dict:
        """Get all token balances for a wallet"""
        data = self.load_wallet_data()

        if address not in data["balances"]:
            return {}

        return data["balances"][address]

    def get_token_info(self, token: str) -> Dict:
        """Get token information"""
        data = self.load_wallet_data()
        return data["tokens"].get(token, {})

    def transfer_tokens(self, from_address: str, to_address: str, token: str, amount: float, private_key: Optional[str] = None) -> Tuple[bool, str]:
        """Transfer tokens between wallets with zero gas fees (internal transaction)"""
        data = self.load_wallet_data()

        # Check if sender has wallet
        if from_address not in data["balances"]:
            return False, "Sender wallet not found"

        # Check if sender has enough balance
        current_balance = data["balances"][from_address].get(token, 0)
        if current_balance < amount:
            return False, f"Insufficient {token} balance"

        # Zero-gas internal transaction - just update the balances
        # Update sender balance
        data["balances"][from_address][token] = current_balance - amount

        # Update recipient balance
        if to_address not in data["balances"]:
            data["balances"][to_address] = {}
        recipient_balance = data["balances"][to_address].get(token, 0)
        data["balances"][to_address][token] = recipient_balance + amount

        # Record the transaction in the transaction history
        transaction = {
            "from": from_address,
            "to": to_address,
            "token": token,
            "amount": amount,
            "fee": 0.0,  # Zero fee
            "timestamp": time.time(),
            "tx_hash": self.generate_tx_hash(from_address, to_address, token, amount, time.time()),
            "status": "completed"
        }

        # Make sure transactions array exists
        if "transactions" not in data:
            data["transactions"] = []

        data["transactions"].append(transaction)
        self.save_wallet_data(data)

        return True, f"Transferred {amount} {token} to {to_address}"

    def generate_tx_hash(self, from_addr: str, to_addr: str, token: str, amount: float, timestamp: float) -> str:
        """Generate a unique transaction hash for internal transactions"""
        tx_data = f"{from_addr}{to_addr}{token}{amount}{timestamp}{secrets.token_hex(8)}"
        return "0x" + hashlib.sha256(tx_data.encode()).hexdigest()

    def get_transaction_history(self, address: Optional[str] = None) -> List[Dict]:
        """Get transaction history, optionally filtered by address"""
        data = self.load_wallet_data()
        transactions = data.get("transactions", [])

        if address:
            # Filter transactions for this address (both sent and received)
            transactions = [tx for tx in transactions if tx["from"] == address or tx["to"] == address]

        # Sort by timestamp, newest first
        transactions.sort(key=lambda x: x["timestamp"], reverse=True)
        return transactions

    def encrypt_key(self, private_key: str, encryption_key: str) -> str:
        """
        Encrypt private key using AES-like XOR encryption
        Note: In a production environment, use a proper encryption library like cryptography
        """
        # Simple XOR encryption - NOT for production use
        encrypted = ""
        for i, c in enumerate(private_key):
            key_char = encryption_key[i % len(encryption_key)]
            encrypted_char = chr(ord(c) ^ ord(key_char))
            encrypted += encrypted_char
        return encrypted.encode().hex()

    def decrypt_key(self, encrypted_key: str, encryption_key: str) -> str:
        """
        Decrypt private key using AES-like XOR encryption
        Note: In a production environment, use a proper encryption library like cryptography
        """
        # Simple XOR decryption - NOT for production use
        encrypted = bytes.fromhex(encrypted_key).decode()
        decrypted = ""
        for i, c in enumerate(encrypted):
            key_char = encryption_key[i % len(encryption_key)]
            decrypted_char = chr(ord(c) ^ ord(key_char))
            decrypted += decrypted_char
        return decrypted
        
    def get_user_profits(self, address: str) -> Dict:
        """Get user profits and revenue sharing info"""
        data = self.load_wallet_data()
        
        # Initialize if not exists
        if "profits" not in data:
            data["profits"] = {}
        
        if address not in data["profits"]:
            data["profits"][address] = {
                "total_profit": 0.0,
                "user_share": 0.0,
                "platform_fee": 0.0,
                "trades_count": 0,
                "profit_by_source": {
                    "arbitrage": 0.0,
                    "flash_swap": 0.0,
                    "quantum_trading": 0.0,
                    "dex_trading": 0.0,
                    "exchange_trading": 0.0
                },
                "profit_by_token": {},
                "profit_history": [],
                "profit_by_network": {}
            }
            
        return data["profits"].get(address, {})
        
    def update_profit_record(self, address: str, profit_amount: float, source: str = None, 
                            token: str = None, network: str = None, 
                            exchange: str = None, details: Dict = None) -> None:
        """
        Update profit records with comprehensive tracking
        
        Args:
            address: User wallet address
            profit_amount: Amount of profit in USD
            source: Source of profit (arbitrage, flash_swap, quantum_trading, etc.)
            token: Token symbol
            network: Network identifier (ETH, BSC, etc.)
            exchange: Exchange identifier
            details: Additional transaction details
        """
        data = self.load_wallet_data()
        
        # Initialize if not exists
        if "profits" not in data:
            data["profits"] = {}
            
        if address not in data["profits"]:
            data["profits"][address] = {
                "total_profit": 0.0,
                "user_share": 0.0,
                "platform_fee": 0.0,
                "trades_count": 0,
                "profit_by_source": {
                    "arbitrage": 0.0,
                    "flash_swap": 0.0,
                    "quantum_trading": 0.0,
                    "dex_trading": 0.0,
                    "exchange_trading": 0.0
                },
                "profit_by_token": {},
                "profit_history": [],
                "profit_by_network": {}
            }
        
        # Calculate shares (70% to user, 30% platform fee)
        user_share = profit_amount * 0.7
        platform_fee = profit_amount * 0.3
        
        # Update user profits
        data["profits"][address]["total_profit"] += profit_amount
        data["profits"][address]["user_share"] += user_share
        data["profits"][address]["platform_fee"] += platform_fee
        data["profits"][address]["trades_count"] += 1
        
        # Update source tracking
        if source and source in data["profits"][address]["profit_by_source"]:
            data["profits"][address]["profit_by_source"][source] += profit_amount
        
        # Update token tracking
        if token:
            if token not in data["profits"][address]["profit_by_token"]:
                data["profits"][address]["profit_by_token"][token] = 0.0
            data["profits"][address]["profit_by_token"][token] += profit_amount
        
        # Update network tracking
        if network:
            if "profit_by_network" not in data["profits"][address]:
                data["profits"][address]["profit_by_network"] = {}
            if network not in data["profits"][address]["profit_by_network"]:
                data["profits"][address]["profit_by_network"][network] = 0.0
            data["profits"][address]["profit_by_network"][network] += profit_amount
        
        # Add to history
        profit_entry = {
            "timestamp": time.time(),
            "amount": profit_amount,
            "user_share": user_share,
            "platform_fee": platform_fee,
            "source": source,
            "token": token,
            "network": network,
            "exchange": exchange
        }
        
        # Add additional details if provided
        if details:
            profit_entry.update(details)
            
        data["profits"][address]["profit_history"].append(profit_entry)
        
        # Update platform totals
        if "platform_totals" not in data:
            data["platform_totals"] = {
                "total_fees": 0.0,
                "total_volume": 0.0,
                "total_profit": 0.0,
                "profit_by_source": {},
                "profit_by_network": {},
                "profit_by_token": {}
            }
        
        data["platform_totals"]["total_fees"] += platform_fee
        data["platform_totals"]["total_profit"] += profit_amount
        
        # Update platform source tracking
        if source:
            if "profit_by_source" not in data["platform_totals"]:
                data["platform_totals"]["profit_by_source"] = {}
            if source not in data["platform_totals"]["profit_by_source"]:
                data["platform_totals"]["profit_by_source"][source] = 0.0
            data["platform_totals"]["profit_by_source"][source] += profit_amount
            
        # Update platform network tracking
        if network:
            if "profit_by_network" not in data["platform_totals"]:
                data["platform_totals"]["profit_by_network"] = {}
            if network not in data["platform_totals"]["profit_by_network"]:
                data["platform_totals"]["profit_by_network"][network] = 0.0
            data["platform_totals"]["profit_by_network"][network] += profit_amount
            
        # Update platform token tracking
        if token:
            if "profit_by_token" not in data["platform_totals"]:
                data["platform_totals"]["profit_by_token"] = {}
            if token not in data["platform_totals"]["profit_by_token"]:
                data["platform_totals"]["profit_by_token"][token] = 0.0
            data["platform_totals"]["profit_by_token"][token] += profit_amount
        
        self.save_wallet_data(data)
        
    def get_profit_metrics(self, address: str) -> Dict:
        """
        Get comprehensive profit metrics for reporting and visualization
        
        Args:
            address: User wallet address
            
        Returns:
            Dictionary with profit metrics
        """
        profits = self.get_user_profits(address)
        
        if not profits:
            return {
                "total_profit": 0.0,
                "metrics": {
                    "daily": [],
                    "monthly": [],
                    "by_source": [],
                    "by_token": [],
                    "by_network": []
                }
            }
            
        # Calculate time-based metrics
        history = profits.get("profit_history", [])
        daily_profits = {}
        monthly_profits = {}
        
        for entry in history:
            timestamp = entry.get("timestamp", 0)
            profit = entry.get("amount", 0.0)
            
            # Calculate date strings
            date_obj = datetime.fromtimestamp(timestamp)
            day_key = date_obj.strftime("%Y-%m-%d")
            month_key = date_obj.strftime("%Y-%m")
            
            # Update daily profits
            if day_key not in daily_profits:
                daily_profits[day_key] = 0.0
            daily_profits[day_key] += profit
            
            # Update monthly profits
            if month_key not in monthly_profits:
                monthly_profits[month_key] = 0.0
            monthly_profits[month_key] += profit
            
        # Format source metrics
        source_metrics = [
            {"source": source, "profit": amount}
            for source, amount in profits.get("profit_by_source", {}).items()
            if amount > 0
        ]
        
        # Format token metrics
        token_metrics = [
            {"token": token, "profit": amount}
            for token, amount in profits.get("profit_by_token", {}).items()
            if amount > 0
        ]
        
        # Format network metrics
        network_metrics = [
            {"network": network, "profit": amount}
            for network, amount in profits.get("profit_by_network", {}).items()
            if amount > 0
        ]
        
        # Format daily and monthly profit metrics
        daily_metrics = [
            {"date": day, "profit": profit}
            for day, profit in sorted(daily_profits.items())
        ]
        
        monthly_metrics = [
            {"month": month, "profit": profit}
            for month, profit in sorted(monthly_profits.items())
        ]
        
        return {
            "total_profit": profits.get("total_profit", 0.0),
            "user_share": profits.get("user_share", 0.0),
            "platform_fee": profits.get("platform_fee", 0.0),
            "trades_count": profits.get("trades_count", 0),
            "metrics": {
                "daily": daily_metrics,
                "monthly": monthly_metrics,
                "by_source": source_metrics,
                "by_token": token_metrics,
                "by_network": network_metrics
            }
        }
    
    def get_total_platform_fees(self) -> float:
        """Get total platform fees collected"""
        data = self.load_wallet_data()
        
        if "platform_totals" not in data:
            return 0.0
            
        return data["platform_totals"].get("total_fees", 0.0)
        
    def get_total_trading_volume(self) -> float:
        """Get total trading volume"""
        data = self.load_wallet_data()
        
        if "platform_totals" not in data:
            return 0.0
            
        return data["platform_totals"].get("total_volume", 0.0)
        
    def record_atomic_transaction(self, from_address: str, operation_type: str, 
                                amount: float, profit: float, details: Dict) -> str:
        """Record an atomic transaction (system trading with user funds)"""
        data = self.load_wallet_data()
        
        # Generate unique transaction ID
        tx_id = self.generate_tx_hash(from_address, "SYSTEM", operation_type, amount, time.time())
        
        # Create transaction record
        transaction = {
            "id": tx_id,
            "from": from_address,
            "to": "SYSTEM",
            "type": operation_type,
            "amount": amount,
            "profit": profit,
            "timestamp": time.time(),
            "details": details,
            "atomic": True,
            "status": "completed"
        }
        
        # Ensure transactions array exists
        if "atomic_transactions" not in data:
            data["atomic_transactions"] = []
            
        # Add transaction
        data["atomic_transactions"].append(transaction)
        
        # Record profits (if any)
        if profit > 0:
            self.update_profit_record(from_address, profit)
            
        # Update trading volume
        if "platform_totals" not in data:
            data["platform_totals"] = {"total_volume": 0.0, "total_fees": 0.0, "total_profit": 0.0}
        
        data["platform_totals"]["total_volume"] += amount
        
        self.save_wallet_data(data)
        return tx_id
        
    def get_atomic_transactions(self, address: str) -> List[Dict]:
        """Get atomic transactions for an address"""
        data = self.load_wallet_data()
        
        if "atomic_transactions" not in data:
            return []
            
        # Filter transactions for this address
        transactions = [tx for tx in data["atomic_transactions"] if tx["from"] == address]
        
        # Sort by timestamp, newest first
        transactions.sort(key=lambda x: x["timestamp"], reverse=True)
        return transactions

    def import_wallet(self, username: str, password: str, private_key: str) -> Tuple[bool, Any]:
        """Import an existing wallet using private key"""
        # Load existing data
        data = self.load_wallet_data()

        # Check if user already has a wallet
        if username in data["wallets"]:
            return False, "User already has a wallet. Please use a different username."

        try:
            # Create account from private key
            account = Account.from_key(private_key)
            address = account.address

            # Encrypt private key with password before storing
            encryption_key = hashlib.sha256(password.encode()).hexdigest()
            encrypted_key = self.encrypt_key(private_key, encryption_key)

            # Store wallet data
            data["wallets"][username] = {
                "address": address,
                "encrypted_key": encrypted_key,
                "created_at": time.time(),
                "imported": True
            }

            # Initialize empty balances for the user if not already existing
            if address not in data["balances"]:
                data["balances"][address] = {}

            self.save_wallet_data(data)

            return True, {"address": address, "private_key": private_key}

        except Exception as e:
            return False, f"Failed to import wallet: {str(e)}"

# Utility functions for the wallet UI
def create_and_fund_test_wallet(username: str, token_amounts: Dict) -> Tuple[bool, str]:
    """Create and fund a test wallet with specified tokens"""
    wallet_system = SecureWallet()
    success, result = wallet_system.create_wallet(username, "test_password")

    if success:
        address = result["address"]
        for token, amount in token_amounts.items():
            wallet_system.update_token_balance(address, token, amount)
        return True, address
    return False, "Failed to create wallet"

def get_wallet_info_by_address(address: str) -> Dict:
    """Get username and other info for a wallet address"""
    wallet_system = SecureWallet()
    data = wallet_system.load_wallet_data()

    for username, wallet_data in data["wallets"].items():
        if wallet_data["address"].lower() == address.lower():
            return {
                "username": username,
                "created_at": wallet_data["created_at"],
                "imported": wallet_data.get("imported", False)
            }

    return {}