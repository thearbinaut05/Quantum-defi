import streamlit as st
import pandas as pd
import time
from web3 import Web3
import secure_wallet
import auth
import os
import json
import qrcode
import io
from PIL import Image
import base64
from datetime import datetime

def wallet_ui():
    """Main wallet UI function"""
    st.header("Secure Token Wallet")

    # Check if user is logged in
    if "username" not in st.session_state:
        st.warning("Please log in to access your wallet")
        return

    username = st.session_state.username

    # Initialize wallet system
    wallet_system = secure_wallet.SecureWallet()

    # Check if user has a wallet
    data = wallet_system.load_wallet_data()
    has_wallet = username in data.get("wallets", {})

    if not has_wallet:
        st.info("You don't have a wallet yet. Create one to start managing your tokens.")

        # Offer two options: create a new wallet or import existing
        tab1, tab2 = st.tabs(["Create New Wallet", "Import Existing Wallet"])

        with tab1:
            if st.button("Create Wallet", key="create_new_wallet"):
                # For simplicity, we're using the same password as login
                # In a production system, you should prompt for a separate wallet password
                user_data = auth.load_users()
                if username in user_data["users"]:
                    password_hash = user_data["users"][username]["password_hash"]

                    # Create wallet with derived password
                    success, result = wallet_system.create_wallet(username, password_hash)

                    if success:
                        st.success(f"Wallet created successfully! Your address: {result['address']}")

                        # Store wallet address in user profile
                        profile_data = {"wallet_address": result["address"]}
                        auth.update_user_profile(username, profile_data)

                        # Also update session state
                        st.session_state.wallet_address = result["address"]
                        st.rerun()
                    else:
                        st.error(result)

        with tab2:
            private_key = st.text_input("Enter Private Key", type="password", help="Your private key will be encrypted and stored securely")

            if st.button("Import Wallet", key="import_wallet"):
                if not private_key or not private_key.startswith("0x"):
                    st.error("Please enter a valid private key")
                else:
                    user_data = auth.load_users()
                    if username in user_data["users"]:
                        password_hash = user_data["users"][username]["password_hash"]

                        # Import wallet with private key
                        success, result = wallet_system.import_wallet(username, password_hash, private_key)

                        if success:
                            st.success(f"Wallet imported successfully! Your address: {result['address']}")

                            # Store wallet address in user profile
                            profile_data = {"wallet_address": result["address"]}
                            auth.update_user_profile(username, profile_data)

                            # Also update session state
                            st.session_state.wallet_address = result["address"]
                            st.rerun()
                        else:
                            st.error(result)
    else:
        # Get user's wallet information
        user_data = auth.load_users()
        password_hash = user_data["users"][username]["password_hash"]

        success, wallet_info = wallet_system.get_wallet(username, password_hash)

        if success:
            wallet_address = wallet_info["address"]

            # Store in session state if not already there
            if "wallet_address" not in st.session_state:
                st.session_state.wallet_address = wallet_address

            # Display wallet address with copy button
            col1, col2 = st.columns([3, 1])
            with col1:
                st.success(f"Wallet connected: {wallet_address}")
            with col2:
                if st.button("📋 Copy", help="Copy address to clipboard"):
                    # Use JavaScript to copy to clipboard
                    st.write(f"""
                    <script>
                        navigator.clipboard.writeText("{wallet_address}");
                        alert("Address copied to clipboard!");
                    </script>
                    """, unsafe_allow_html=True)
                    st.toast("Address copied to clipboard!")

            # Tabs for different wallet functions
            tab1, tab2, tab3 = st.tabs(["Balances", "Send", "Transactions"])

            with tab1:
                wallet_balance_ui(wallet_system, wallet_address)

            with tab2:
                transaction_ui(wallet_system, wallet_address, wallet_info.get("private_key"))

            with tab3:
                transaction_history_ui(wallet_system, wallet_address)
        else:
            st.error("Error retrieving wallet. Please try again.")

def wallet_balance_ui(wallet_system, wallet_address):
    """UI for showing wallet balances"""
    st.subheader("Wallet Balances")

    # Get all token balances
    balances = wallet_system.get_all_balances(wallet_address)

    if not balances:
        st.info("No token balances found")

        # For testing, add some demo tokens
        if st.button("Add Test Tokens"):
            wallet_system.update_token_balance(wallet_address, "ETH", 1.5)
            wallet_system.update_token_balance(wallet_address, "USDT", 1000)
            wallet_system.update_token_balance(wallet_address, "USDC", 1000)
            wallet_system.update_token_balance(wallet_address, "BTC", 0.05)
            st.success("Test tokens added to your wallet")
            st.rerun()
    else:
        # Token logos (simplified for demo)
        token_logos = {
            "ETH": "https://cryptologos.cc/logos/ethereum-eth-logo.png",
            "USDT": "https://cryptologos.cc/logos/tether-usdt-logo.png",
            "USDC": "https://cryptologos.cc/logos/usd-coin-usdc-logo.png",
            "DAI": "https://cryptologos.cc/logos/multi-collateral-dai-dai-logo.png",
            "BTC": "https://cryptologos.cc/logos/bitcoin-btc-logo.png",
            "WBTC": "https://cryptologos.cc/logos/wrapped-bitcoin-wbtc-logo.png",
            "UNI": "https://cryptologos.cc/logos/uniswap-uni-logo.png",
            "LINK": "https://cryptologos.cc/logos/chainlink-link-logo.png",
            "AAVE": "https://cryptologos.cc/logos/aave-aave-logo.png"
        }

        # Total value in USD (estimated)
        token_prices = {
            "ETH": 3000,
            "USDT": 1,
            "USDC": 1,
            "DAI": 1,
            "BTC": 60000,
            "WBTC": 60000,
            "UNI": 10,
            "LINK": 15,
            "AAVE": 100
        }

        total_value = sum(balances.get(token, 0) * token_prices.get(token, 0) for token in balances)

        # Display total estimated value
        st.metric("Total Estimated Value", f"${total_value:,.2f}")

        # Display balances
        st.write("Your token balances:")

        # Create QR code for the wallet address
        qr = qrcode.QRCode(
            version=1,
            error_correction=qrcode.constants.ERROR_CORRECT_L,
            box_size=10,
            border=4,
        )
        qr.add_data(wallet_address)
        qr.make(fit=True)

        img = qr.make_image(fill_color="black", back_color="white")
        buffered = io.BytesIO()
        img.save(buffered, format="PNG")
        img_str = base64.b64encode(buffered.getvalue()).decode()

        # Add deposit option
        with st.expander("📥 Deposit Tokens", expanded=False):
            st.write("Scan this QR code or copy the address to deposit tokens to your wallet:")
            st.image(f"data:image/png;base64,{img_str}", width=200)
            st.code(wallet_address)
            st.info("Any tokens sent to this address will be automatically added to your wallet.")

        # Display token balances in a more visually appealing way
        cols = st.columns(3)

        i = 0
        for token, balance in balances.items():
            if balance > 0:
                with cols[i % 3]:
                    st.container(height=120, border=True).markdown(
                        f"""
                        <div style='display: flex; align-items: center;'>
                            <img src='{token_logos.get(token, "https://via.placeholder.com/50")}' width='40'>
                            <div style='margin-left: 10px;'>
                                <div style='font-weight: bold;'>{token}</div>
                                <div style='font-size: 1.2em;'>{balance:.6f}</div>
                                <div style='color: gray; font-size: 0.8em;'>${balance * token_prices.get(token, 0):,.2f}</div>
                            </div>
                        </div>
                        """, 
                        unsafe_allow_html=True
                    )
                i += 1

def transaction_ui(wallet_system, wallet_address, private_key):
    """UI for transactions"""
    st.subheader("Send Tokens")

    # Get all token balances
    balances = wallet_system.get_all_balances(wallet_address)

    if not balances:
        st.info("You need some tokens to make transactions.")
        return

    # Only show tokens with balances > 0
    tokens_with_balance = {k: v for k, v in balances.items() if v > 0}

    if not tokens_with_balance:
        st.info("You don't have any tokens to send.")
        return

    # Token selection
    token_options = list(tokens_with_balance.keys())
    token_symbol = st.selectbox("Select Token", token_options)

    # Get current balance
    current_balance = tokens_with_balance.get(token_symbol, 0)

    # Get token info for proper display
    token_info = wallet_system.get_token_info(token_symbol)
    token_decimals = token_info.get("decimals", 18)

    # Recipient address
    recipient = st.text_input("Recipient Address", placeholder="0x...", help="Enter the recipient wallet address")

    col1, col2 = st.columns(2)

    with col1:
        # Amount with max button
        amount = st.number_input(
            f"Amount of {token_symbol}",
            min_value=0.0,
            max_value=float(current_balance),
            step=0.01 if current_balance >= 1 else 0.0001,
            format=f"%.{min(6, token_decimals)}f"
        )

    with col2:
        st.metric("Available Balance", f"{current_balance:.6f} {token_symbol}")
        if st.button("MAX"):
            # This doesn't actually work directly in Streamlit, but we can simulate it
            st.session_state.amount = current_balance
            st.rerun()

    # Transaction fee (always zero in our internal system)
    st.info("✓ Zero Transaction Fee - Our secure wallet enables gasless transactions")

    # Send button
    if st.button("Send Tokens", type="primary"):
        if not recipient or not Web3.is_address(recipient):
            st.error("Invalid recipient address. Please enter a valid Ethereum address.")
        elif amount <= 0:
            st.error("Amount must be greater than 0")
        elif amount > current_balance:
            st.error(f"Insufficient balance. You have {current_balance} {token_symbol}")
        else:
            # Show confirmation
            st.warning(f"You are about to send {amount} {token_symbol} to {recipient}")

            if st.button("Confirm Transaction", key="confirm_tx"):
                # Execute the transaction
                success, message = wallet_system.transfer_tokens(
                    wallet_address, recipient, token_symbol, amount, private_key
                )

                if success:
                    st.balloons()
                    st.success(message)
                    # Add a slight delay to simulate transaction processing
                    time.sleep(1)
                    st.rerun()
                else:
                    st.error(message)

def transaction_history_ui(wallet_system, address):
    """UI for transaction history"""
    # User profits information
    st.subheader("Your Profits")
    profits = wallet_system.get_user_profits(address)

    col1, col2, col3 = st.columns(3)
    with col1:
        st.metric("Total Profit", f"${profits.get('total_profit', 0.0):.2f}")
    with col2:
        st.metric("Your Share (70%)", f"${profits.get('user_share', 0.0):.2f}")
    with col3:
        st.metric("Platform Fee (30%)", f"${profits.get('platform_fee', 0.0):.2f}")

    # Transaction tabs
    transaction_tabs = st.tabs(["Regular Transactions", "Atomic Trading", "Custody Information"])

    with transaction_tabs[0]:
        st.subheader("Transaction History")

        transactions = wallet_system.get_transaction_history(address)

        if transactions:
            # Convert to DataFrame for better display
            tx_data = []
            for tx in transactions:
                tx_data.append({
                    "Date": datetime.fromtimestamp(tx["timestamp"]).strftime("%Y-%m-%d %H:%M"),
                    "Type": "Send" if tx["from"] == address else "Receive",
                    "Token": tx["token"],
                    "Amount": f"{tx['amount']:.6f}",
                    "Fee": f"{tx['fee']:.6f}",
                    "Status": tx["status"].title()
                })

            tx_df = pd.DataFrame(tx_data)
            st.dataframe(tx_df, use_container_width=True)
        else:
            st.info("No transactions yet.")

    with transaction_tabs[1]:
        st.subheader("Atomic Trading Activity")
        st.info("""
        Below are all automatic trades executed by the system using your funds in custody.
        All trades are atomic (executed in a single transaction) and use flash bots or secure
        MEV protection to prevent front-running and ensure transaction privacy.
        """)

        atomic_txs = wallet_system.get_atomic_transactions(address)

        if atomic_txs:
            # Convert to DataFrame for better display
            atomic_data = []
            for tx in atomic_txs:
                atomic_data.append({
                    "Date": datetime.fromtimestamp(tx["timestamp"]).strftime("%Y-%m-%d %H:%M"),
                    "Operation": tx["type"],
                    "Amount": f"${tx['amount']:.2f}",
                    "Profit": f"${tx['profit']:.2f}",
                    "Your Share": f"${tx['profit'] * 0.7:.2f}",
                    "Platform Fee": f"${tx['profit'] * 0.3:.2f}"
                })

            atomic_df = pd.DataFrame(atomic_data)
            st.dataframe(atomic_df, use_container_width=True)
        else:
            st.info("No atomic trading activity yet.")

    with transaction_tabs[2]:
        st.subheader("Custody Information")

        st.markdown("""
        ### Transparent Custody Terms

        When you deposit funds to this platform, you agree to the following terms:

        1. **Custody Authorization**: By depositing funds, you authorize the platform to use your funds for trading opportunities using atomic transactions.

        2. **Profit Sharing**: All profits from trading with your funds are shared:
           - **70%** directly to you
           - **30%** platform fee

        3. **Transaction Security**: All transactions use:
           - Atomic execution (all-or-nothing)
           - Flash Bots integration to prevent front-running
           - MEV protection
           - Zero-gas internal transfers

        4. **Full Transparency**: Every transaction using your funds is recorded and visible in the "Atomic Trading" tab.

        5. **Withdrawal Rights**: You maintain the right to withdraw your funds at any time.
        """)

        # Add consent toggle
        if st.checkbox("I understand and consent to these terms", value=True):
            st.success("Thank you for your consent. Your funds are now eligible for atomic trading operations.")
        else:
            st.warning("Your funds will not be used for atomic trading until you consent to the terms.")

        # Trading activity toggle
        st.subheader("Atomic Trading Settings")

        use_funds_for_trading = st.toggle("Allow platform to use my funds for atomic trading", value=True)

        if use_funds_for_trading:
            st.success("Your funds are enabled for atomic trading operations with profit sharing.")

            # Advanced settings
            with st.expander("Advanced Settings"):
                st.slider("Maximum percentage of funds to use (%)", 0, 100, 80, 5)
                st.multiselect("Allowed tokens for trading", 
                               ["ETH", "BTC", "USDT", "USDC", "DAI", "LINK"], 
                               ["ETH", "USDT", "USDC"])
        else:
            st.info("Your funds will not be used for trading operations.")


if __name__ == "__main__":
    st.set_page_config(
        page_title="Secure Wallet",
        page_icon="💰",
        layout="wide"
    )
    wallet_ui()