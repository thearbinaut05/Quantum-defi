import streamlit as st
import pandas as pd
import numpy as np
import plotly.graph_objects as go
import plotly.express as px
from datetime import datetime, timedelta
import random
import time
import auth
import utils

def format_amount(amount):
    """Format amount with appropriate prefix"""
    if abs(amount) >= 1_000_000:
        return f"${amount/1_000_000:.2f}M"
    elif abs(amount) >= 1_000:
        return f"${amount/1_000:.2f}K"
    else:
        return f"${amount:.2f}"

def create_historical_data(days=30, volatility=0.02, start_value=10000, trend=0.01):
    """Create sample historical portfolio data"""
    dates = [datetime.now() - timedelta(days=i) for i in range(days, -1, -1)]

    # Initialize with starting value
    values = [start_value]

    # Generate rest of the values with random walk and trend
    for i in range(1, len(dates)):
        change = values[-1] * (np.random.normal(trend, volatility))
        new_value = max(values[-1] + change, 0)  # Ensure non-negative
        values.append(new_value)

    return pd.DataFrame({"date": dates, "value": values})

def create_token_allocations(username=None):
    """Create or get token allocations"""
    if username:
        # Get user's preferred tokens if authenticated
        profile = auth.get_user_profile(username)
        if profile and "trading_preferences" in profile:
            preferred_tokens = profile["trading_preferences"].get("preferred_tokens", ["BTC", "ETH"])
        else:
            preferred_tokens = ["BTC", "ETH"]
    else:
        preferred_tokens = ["BTC", "ETH"]

    # Add some default tokens if list is too short
    default_tokens = ["BTC", "ETH", "USDC", "USDT", "XRP", "LINK"]
    for token in default_tokens:
        if token not in preferred_tokens and len(preferred_tokens) < 5:
            preferred_tokens.append(token)

    # Generate random allocations
    allocations = {}
    remaining = 100.0

    for i, token in enumerate(preferred_tokens):
        if i == len(preferred_tokens) - 1:
            # Last token gets remainder
            allocations[token] = remaining
        else:
            # Random allocation
            allocation = min(random.uniform(5, 40), remaining)
            allocations[token] = allocation
            remaining -= allocation

    return allocations

def get_trade_history(username=None, max_trades=50):
    """Get or create trade history"""
    if username:
        # Get actual trade history from user profile in the future
        pass

    # Sample trade data
    assets = ["BTC", "ETH", "XRP", "LINK", "USDC", "USDT"]
    actions = ["buy", "sell"]

    trades = []
    current_time = datetime.now()

    for i in range(max_trades):
        # Generate a trade
        asset = random.choice(assets)
        action = random.choice(actions)
        amount = random.uniform(0.01, 2) if asset in ["BTC", "ETH"] else random.uniform(10, 1000)
        price = random.uniform(20000, 40000) if asset == "BTC" else (
                random.uniform(1000, 3000) if asset == "ETH" else random.uniform(0.1, 10))
        value = amount * price
        trade_time = current_time - timedelta(minutes=random.randint(1, 60*24*7))

        profit = random.uniform(-500, 1000) if action == "sell" else None

        trades.append({
            "timestamp": trade_time,
            "asset": asset,
            "action": action,
            "amount": amount,
            "price": price,
            "value": value,
            "profit": profit
        })

    # Sort by timestamp
    trades = sorted(trades, key=lambda x: x["timestamp"], reverse=True)

    return pd.DataFrame(trades)

def get_current_positions(username=None):
    """Get or create current positions"""
    if username:
        # Get actual positions from user profile in the future
        pass

    # Sample position data
    assets = ["BTC", "ETH", "XRP", "LINK"]
    positions = []

    for asset in assets:
        # Randomly decide if we have this position
        if random.random() > 0.3:
            amount = random.uniform(0.1, 5) if asset in ["BTC", "ETH"] else random.uniform(100, 10000)
            entry_price = random.uniform(20000, 35000) if asset == "BTC" else (
                          random.uniform(1500, 2500) if asset == "ETH" else random.uniform(0.5, 5))
            current_price = entry_price * (1 + random.uniform(-0.2, 0.3))
            value = amount * current_price
            profit_pct = ((current_price / entry_price) - 1) * 100
            profit_amount = value - (amount * entry_price)

            positions.append({
                "asset": asset,
                "amount": amount,
                "entry_price": entry_price,
                "current_price": current_price,
                "value": value,
                "profit_pct": profit_pct,
                "profit_amount": profit_amount
            })

    return pd.DataFrame(positions)

def get_real_time_stats(username=None):
    """Get real-time trading statistics"""
    try:
        if username:
            # Get actual stats from user profile in the future
            try:
                profile = auth.get_user_profile(username)
                if profile and "trading_performance" in profile:
                    perf = profile["trading_performance"]
                    portfolio_value = perf.get("portfolio_value", 10000)
                    total_profit = perf.get("total_profit", 0)
                    win_rate = perf.get("win_rate", 0)
                else:
                    portfolio_value = 10000
                    total_profit = 0
                    win_rate = 0
            except Exception as e:
                st.error(f"Error fetching user profile: {str(e)}")
                portfolio_value = 10000
                total_profit = 0
                win_rate = 0
        else:
            portfolio_value = random.uniform(9000, 15000)
            total_profit = portfolio_value - 10000  # Assuming starting capital of 10000
            win_rate = random.uniform(0.4, 0.7)

        # Calculate other stats
        daily_profit = random.uniform(-200, 500)
        weekly_profit = random.uniform(-500, 1500)
        monthly_profit = random.uniform(-1000, 5000)

        # ROI calculations
        daily_roi = (daily_profit / (portfolio_value - daily_profit)) * 100 if portfolio_value - daily_profit > 0 else 0
        weekly_roi = (weekly_profit / (portfolio_value - weekly_profit)) * 100 if portfolio_value - weekly_profit > 0 else 0
        monthly_roi = (monthly_profit / (portfolio_value - monthly_profit)) * 100 if portfolio_value - monthly_profit > 0 else 0

        # Generate some market signals
        assets = ["BTC", "ETH", "XRP", "LINK", "LTC"]
        signals = []

        for asset in assets:
            if random.random() > 0.6:  # 40% chance of having a signal
                signal_type = random.choice(["buy", "sell", "hold"])
                confidence = random.uniform(0.6, 0.95)
                signals.append({
                    "asset": asset,
                    "signal": signal_type,
                    "confidence": confidence,
                    "timestamp": datetime.now() - timedelta(minutes=random.randint(1, 60))
                })

        signals_df = pd.DataFrame(signals) if signals else None

        # Return all stats as a dictionary
        return {
            "portfolio_value": portfolio_value,
            "total_profit": total_profit,
            "daily": {
                "profit": daily_profit,
                "roi": daily_roi
            },
            "weekly": {
                "profit": weekly_profit,
                "roi": weekly_roi
            },
            "monthly": {
                "profit": monthly_profit,
                "roi": monthly_roi
            },
            "win_rate": win_rate,
            "signals": signals_df
        }
    except Exception as e:
        st.error(f"Error getting real-time stats: {str(e)}")
        # Return fallback data
        return {
            "portfolio_value": 10000,
            "total_profit": 0,
            "daily": {"profit": 0, "roi": 0},
            "weekly": {"profit": 0, "roi": 0},
            "monthly": {"profit": 0, "roi": 0},
            "win_rate": 0.5,
            "signals": None
        }

def render_portfolio_performance(username=None):
    """Render the portfolio performance section"""

    try:
        st.subheader("Portfolio Performance")

        # Fetch portfolio history
        try:
            if username:
                # TODO: In the future, fetch actual portfolio history from user profile
                portfolio_history = create_historical_data()
            else:
                portfolio_history = create_historical_data()

            # Plot portfolio history
            fig = px.line(
                portfolio_history, 
                x="date", 
                y="value", 
                title="Portfolio Value History",
                labels={"date": "Date", "value": "Value (USD)"}
            )

            fig.update_layout(
                hovermode="x unified",
                plot_bgcolor="rgba(0,0,0,0)",
                yaxis=dict(
                    gridcolor="rgba(200,200,200,0.2)",
                ),
                xaxis=dict(
                    gridcolor="rgba(200,200,200,0.2)",
                )
            )

            st.plotly_chart(fig, use_container_width=True)
        except Exception as e:
            st.error(f"Error rendering portfolio chart: {str(e)}")

        # Get current stats
        try:
            stats = get_real_time_stats(username)

            # Display key metrics
            col1, col2, col3, col4 = st.columns(4)

            with col1:
                st.metric(
                    "Portfolio Value",
                    format_amount(stats["portfolio_value"]),
                    f"{stats['total_profit']/stats['portfolio_value']*100:.2f}%" if stats["portfolio_value"] > 0 else "0.00%"
                )

            with col2:
                st.metric(
                    "Total Profit/Loss",
                    format_amount(stats["total_profit"]),
                    f"{stats['total_profit']/10000*100:.2f}%" if stats["total_profit"] != 0 else None
                )

            with col3:
                st.metric(
                    "Win Rate", 
                    f"{stats['win_rate']*100:.1f}%"
                )

            with col4:
                st.metric(
                    "Monthly ROI",
                    f"{stats['monthly']['roi']:.2f}%", 
                    f"{stats['monthly']['profit']:.2f}"
                )
        except Exception as e:
            st.error(f"Error rendering portfolio metrics: {str(e)}")
            st.info("Using fallback metrics due to data loading issues")

            # Display fallback metrics
            col1, col2, col3, col4 = st.columns(4)
            with col1:
                st.metric("Portfolio Value", "$10,000.00")
            with col2:
                st.metric("Total Profit/Loss", "$0.00")
            with col3:
                st.metric("Win Rate", "50.0%")
            with col4:
                st.metric("Monthly ROI", "0.00%")
    except Exception as e:
        st.error(f"Error in portfolio performance rendering: {str(e)}")
        st.warning("Please refresh the page to try again.")

def render_active_positions(username=None):
    """Render the active positions section"""

    st.subheader("Active Positions")

    # Get current positions
    positions = get_current_positions(username)

    if positions.empty:
        st.info("No active positions at the moment.")
        return

    # Format the dataframe for display
    formatted_positions = positions.copy()
    formatted_positions["amount"] = formatted_positions["amount"].apply(lambda x: f"{x:.4f}" if x < 1 else f"{x:.2f}")
    formatted_positions["entry_price"] = formatted_positions["entry_price"].apply(lambda x: f"${x:.2f}")
    formatted_positions["current_price"] = formatted_positions["current_price"].apply(lambda x: f"${x:.2f}")
    formatted_positions["value"] = formatted_positions["value"].apply(lambda x: f"${x:.2f}")
    formatted_positions["profit_pct"] = formatted_positions["profit_pct"].apply(lambda x: f"{x:.2f}%")

    # Color the profit column based on value
    def color_profit(val):
        try:
            # Extract numeric value from string (remove $ and % signs)
            if isinstance(val, str):
                if val.endswith('%'):
                    num = float(val.replace('%', ''))
                else:
                    num = float(val.replace('$', ''))
            else:
                num = val

            if num > 0:
                return 'color: green'
            elif num < 0:
                return 'color: red'
            else:
                return ''
        except:
            return ''

    # Format profit amount column
    formatted_positions["profit_amount"] = formatted_positions["profit_amount"].apply(
        lambda x: f"${x:.2f}" if abs(x) < 1000 else (
            f"${x/1000:.2f}K" if abs(x) < 1000000 else f"${x/1000000:.2f}M"
        )
    )

    # Display the dataframe with styling - using .map instead of deprecated .applymap
    if not formatted_positions.empty:
        st.dataframe(
            formatted_positions.style.map(
                color_profit, 
                subset=["profit_pct", "profit_amount"]
            ),
            use_container_width=True
        )
    else:
        st.info("No active positions to display")

    # Portfolio allocation pie chart
    st.subheader("Portfolio Allocation")

    # Calculate allocation percentages
    total_value = positions["value"].sum()
    allocations = positions.groupby("asset")["value"].sum() / total_value * 100

    # Create pie chart
    fig = px.pie(
        values=allocations.values, 
        names=allocations.index, 
        title="Asset Allocation",
        hole=0.4
    )

    fig.update_traces(
        textposition='inside', 
        textinfo='percent+label'
    )

    fig.update_layout(
        legend=dict(
            orientation="h",
            yanchor="bottom",
            y=-0.1,
            xanchor="center",
            x=0.5
        )
    )

    st.plotly_chart(fig, use_container_width=True)

def render_market_signals(username=None):
    """Render the market signals section"""

    st.subheader("Trading Signals")

    # Get real-time stats which include signals
    stats = get_real_time_stats(username)
    signals = stats["signals"]

    if signals is None or signals.empty:
        st.info("No active trading signals at the moment.")
        return

    # Format the signals dataframe
    signals["timestamp"] = signals["timestamp"].dt.strftime("%Y-%m-%d %H:%M")
    signals["confidence"] = signals["confidence"].apply(lambda x: f"{x*100:.1f}%")

    # Color code the signals
    def color_signal(val):
        if val == "buy":
            return 'background-color: rgba(0,255,0,0.2); color: green'
        elif val == "sell":
            return 'background-color: rgba(255,0,0,0.2); color: red'
        else:
            return 'background-color: rgba(255,255,0,0.2); color: orange'

    # Display the signals
    if signals is not None and not signals.empty:
        st.dataframe(
            signals.style.map(
                color_signal, 
                subset=["signal"]
            ),
            use_container_width=True
        )
    else:
        st.info("No active trading signals at the moment.")

def render_recent_trades(username=None, wallet_address=None):
    """Render the recent trades section"""

    st.subheader("Recent Trades")

    # Get trade history
    trades = get_trade_history(username, max_trades=20)

    if trades.empty:
        st.info("No recent trades to display.")
        return

    # Format the dataframe for display
    formatted_trades = trades.copy()
    formatted_trades["timestamp"] = formatted_trades["timestamp"].dt.strftime("%Y-%m-%d %H:%M")
    formatted_trades["amount"] = formatted_trades["amount"].apply(lambda x: f"{x:.4f}" if x < 1 else f"{x:.2f}")
    formatted_trades["price"] = formatted_trades["price"].apply(lambda x: f"${x:.2f}")
    formatted_trades["value"] = formatted_trades["value"].apply(lambda x: f"${x:.2f}")

    # Format profit column
    formatted_trades["profit"] = formatted_trades["profit"].apply(
        lambda x: f"${x:.2f}" if x is not None and abs(x) < 1000 else (
            f"${x/1000:.2f}K" if x is not None and abs(x) < 1000000 else (
                f"${x/1000000:.2f}M" if x is not None else "-"
            )
        )
    )

    # Color the action column
    def color_action(val):
        if val == "buy":
            return 'background-color: rgba(0,255,0,0.2); color: green'
        elif val == "sell":
            return 'background-color: rgba(255,0,0,0.2); color: red'
        else:
            return ''

    # Color the profit column
    def color_profit(val):
        if val == "-":
            return ''

        try:
            # Extract numeric value
            num = float(val.replace('$', '').replace('K', '000').replace('M', '000000'))

            if num > 0:
                return 'color: green'
            elif num < 0:
                return 'color: red'
            else:
                return ''
        except:
            return ''

    # Display the dataframe with styling
    if not formatted_trades.empty:
        st.dataframe(
            formatted_trades.style.map(
                color_action, 
                subset=["action"]
            ).map(
                color_profit,
                subset=["profit"]
            ),
            use_container_width=True
        )
    else:
        st.info("No recent trades to display.")


def render_trading_dashboard(username=None):
    """Main function to render the trading dashboard"""
    st.title("Trading Dashboard")

    # Initialize essential services
    if "wallet_address" in st.session_state:
        wallet_address = st.session_state.wallet_address

        # Import exchange manager
        try:
            import exchange_manager
            exchange_mgr = exchange_manager.ExchangeManager()
        except ImportError:
            exchange_mgr = None
    else:
        wallet_address = None
        exchange_mgr = None

    # Get data from sources
    positions = get_current_positions(username)
    recent_trades = get_trade_history(username)
    signals = get_real_time_stats(username)["signals"]

    # Get exchange data if available
    exchange_positions = []
    exchange_trades = []

    if username and exchange_mgr:
        try:
            # Get exchange API keys
            exchange_keys = exchange_mgr.get_api_keys(username)

            # Get trading history from first available exchange
            if exchange_keys:
                first_exchange = list(exchange_keys.keys())[0]
                exchange_trades = exchange_mgr.get_trading_history(username, first_exchange)

            # Combine exchange positions with regular positions
            # This would require additional implementation
        except Exception as e:
            st.warning(f"Could not load exchange data: {str(e)}")

    # Layout with tabs
    tab1, tab2, tab3, tab4 = st.tabs([
        "Portfolio", "Recent Trades", "Trading Signals", "Exchange Activity"
    ])

    with tab1:
        render_portfolio(positions, wallet_address)

    with tab2:
        render_recent_trades(username, wallet_address)

    with tab3:
        render_market_signals(signals)

    with tab4:
        render_exchange_activity(username, exchange_mgr)


def render_portfolio(positions, wallet_address=None):
    """Render the portfolio section"""
    st.header("Portfolio")

    # Calculate total portfolio value
    total_value = sum([pos['current_value'] for pos in positions]) if positions is not None and not positions.empty else 0

    # Display portfolio metrics
    col1, col2, col3 = st.columns(3)

    col1.metric(
        "Total Portfolio Value", 
        f"${total_value:,.2f}"
    )

    # Calculate total profit/loss
    total_profit = sum([pos['profit_amount'] for pos in positions]) if positions is not None and not positions.empty else 0
    total_profit_pct = (total_profit / (total_value - total_profit)) * 100 if total_value > total_profit else 0

    col2.metric(
        "Total Profit/Loss", 
        f"${total_profit:,.2f}",
        f"{total_profit_pct:.2f}%"
    )

    col3.metric(
        "Active Positions", 
        len(positions) if positions is not None else 0
    )

    # Format positions for display
    if positions is not None and not positions.empty:
        formatted_positions = pd.DataFrame(positions)

        # Format profit columns
        formatted_positions['profit_pct'] = formatted_positions['profit_pct'].apply(lambda x: f"{x:.2f}%")
        formatted_positions['profit_amount'] = formatted_positions['profit_amount'].apply(lambda x: f"${x:.2f}")

        # Format price and value columns
        formatted_positions['entry_price'] = formatted_positions['entry_price'].apply(lambda x: f"${x:.2f}")
        formatted_positions['current_price'] = formatted_positions['current_price'].apply(lambda x: f"${x:.2f}")
        formatted_positions['current_value'] = formatted_positions['current_value'].apply(lambda x: f"${x:.2f}")

        # Function to color profits
        def color_profit(val):
            """Apply colors to profit values"""
            val_str = str(val)
            if val_str.startswith('-'):
                return 'background-color: rgba(255,0,0,0.2); color: red'
            elif val_str.startswith('0.00%') or val_str.startswith('$0.00'):
                return ''
            else:
                return 'background-color: rgba(0,255,0,0.2); color: green'

        # Safe display of dataframe
        try:
            # Display the dataframe with styling
            if not formatted_positions.empty:
                st.dataframe(
                    formatted_positions.style.map(
                        color_profit, 
                        subset=["profit_pct", "profit_amount"]
                    ),
                    use_container_width=True
                )
            else:
                st.info("No active positions to display")
        except Exception as e:
            # Fallback to simple display if styling fails
            st.warning("Using simplified display due to rendering issue")
            st.dataframe(formatted_positions, use_container_width=True)
    else:
        st.info("No active positions to display")

    # Portfolio allocation pie chart
    st.subheader("Portfolio Allocation")

    # Display allocation chart if positions exist
    if positions is not None and not positions.empty:
        try:
            import plotly.express as px

            # Create dataframe for pie chart
            allocation_data = []
            for pos in positions:
                allocation_data.append({
                    'asset': pos['asset'],
                    'value': pos['current_value']
                })

            allocation_df = pd.DataFrame(allocation_data)

            # Create pie chart
            fig = px.pie(
                allocation_df,
                values='value',
                names='asset',
                title='Portfolio Allocation by Asset',
                hole=0.4
            )

            # Update layout
            fig.update_layout(
                legend=dict(
                    orientation="h",
                    yanchor="bottom",
                    y=-0.1,
                    xanchor="center",
                    x=0.5
                )
            )

            st.plotly_chart(fig, use_container_width=True)
        except Exception as e:
            st.error(f"Could not render allocation chart: {str(e)}")
    else:
        st.info("No positions to show allocation")

    # Get wallet profits if available
    if wallet_address:
        try:
            import secure_wallet
            wallet_system = secure_wallet.SecureWallet()

            profit_data = wallet_system.get_user_profits(wallet_address)

            if profit_data and profit_data.get('total_profit', 0) > 0:
                st.subheader("Trading Performance")

                col1, col2, col3 = st.columns(3)

                with col1:
                    st.metric(
                        "Total Trading Profit", 
                        f"${profit_data.get('total_profit', 0):,.2f}"
                    )

                with col2:
                    st.metric(
                        "Your Share", 
                        f"${profit_data.get('user_share', 0):,.2f}"
                    )

                with col3:
                    st.metric(
                        "Completed Trades", 
                        f"{profit_data.get('trades_count', 0)}"
                    )

                # Display profit by source
                profit_by_source = profit_data.get('profit_by_source', {})
                if profit_by_source:
                    try:
                        source_data = []
                        for source, amount in profit_by_source.items():
                            if amount > 0:
                                source_data.append({
                                    'source': source.replace('_', ' ').title(),
                                    'profit': amount
                                })

                        if source_data:
                            source_df = pd.DataFrame(source_data)

                            # Create bar chart
                            fig = px.bar(
                                source_df,
                                x='source',
                                y='profit',
                                title='Profit by Trading Strategy',
                                color='profit',
                                color_continuous_scale='Viridis'
                            )

                            st.plotly_chart(fig, use_container_width=True)
                    except Exception as e:
                        st.warning(f"Could not render profit by source chart: {str(e)}")
        except Exception as e:
            st.warning(f"Could not load wallet profit data: {str(e)}")

def render_exchange_activity(username, exchange_mgr):
    st.header("Exchange Activity")
    if exchange_mgr is None:
        st.info("Exchange manager not initialized.")
        return

    # Placeholder for exchange activity display
    st.write("This section will display exchange trading data.")


def render_trading_signals(signals):
    st.header("Trading Signals")
    if signals is None or signals.empty:
        st.info("No signals available")
        return
    st.dataframe(signals)

def dashboard_ui():
    """Main function to display the dashboard"""
    try:
        # Get username if logged in
        username = st.session_state.get("username", None)

        # Render the dashboard
        render_trading_dashboard(username)
    except Exception as e:
        st.error(f"Dashboard error: {str(e)}")
        st.warning("An error occurred while loading the dashboard. Please try refreshing the page.")

        # Display minimal fallback UI
        st.title("Trading Dashboard (Error Recovery Mode)")
        st.info("The dashboard encountered an error and is running in recovery mode. Some features may be limited.")

        if st.button("Try Refreshing"):
            st.rerun()

# Placeholder modules - Replace with actual implementations
import secure_wallet
class SecureWallet:
    def get_user_profits(self, wallet_address):
      return {'total_profit': 1000, 'user_share': 500, 'trades_count': 10, 'profit_by_source': {'strategy_A': 300, 'strategy_B': 200}}

import exchange_manager
class ExchangeManager:
    def get_api_keys(self, username):
        return {"binance": "fake_api_key"}

    def get_trading_history(self, username, exchange):
        return pd.DataFrame({"timestamp": [datetime.now()], "asset": ["BTC"], "action": ["buy"], "amount": [1], "price": [30000], "value": [30000], "profit": [100]})

if __name__ == "__main__":
    st.set_page_config(
        page_title="Trading Dashboard",
        page_icon="📊",
        layout="wide"
    )
    dashboard_ui()