"""
Autonomous Data Collector for Quantum DeFi Protocol

This module implements advanced AI-driven data collection and analysis for cryptocurrency markets.
Instead of solely relying on traditional API sources, this module:

1. Utilizes AI to analyze web content, social sentiment, and market indicators
2. Generates its own trading signals based on pattern recognition and quantitative analysis
3. Implements self-improving data collection mechanisms
4. Autonomously identifies market inefficiencies and potential trading opportunities
"""

import os
import time
import json
import random
import requests
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import streamlit as st
from scipy import stats
import trafilatura
import anthropic
from anthropic import Anthropic
from collections import defaultdict

# Import project modules
import crypto_data
import quantum_market_model as qmm

# Constants and configuration
SENTIMENT_UPDATE_INTERVAL = 1800  # 30 minutes in seconds
WEB_SOURCES_UPDATE_INTERVAL = 3600  # 1 hour in seconds
PATTERN_RECOGNITION_INTERVAL = 1200  # 20 minutes in seconds
MAX_SOURCES_PER_RUN = 5  # Maximum number of sources to analyze per run
MARKET_TRENDS_MEMORY = 24  # Hours of market trend memory to maintain

class AutonomousMarketDataCollector:
    """
    Advanced AI-driven market data collection and analysis system that operates
    autonomously to gather insights beyond traditional API sources.
    """
    
    def __init__(self):
        # Initialize state
        self.last_sentiment_update = 0
        self.last_web_sources_update = 0
        self.last_pattern_recognition = 0
        
        # Initialize data storage
        self.sentiment_data = {}
        self.market_signals = {}
        self.discovered_patterns = []
        self.web_content_insights = {}
        self.quantitative_metrics = {}
        self.market_inefficiencies = []
        self.active_collection_tasks = []
        
        # AI configuration
        self.ai_ready = self._initialize_ai()
        
        # Market trend memory (rolling window)
        self.market_trends = defaultdict(list)
        
        # Collection sources
        self.web_sources = self._initialize_web_sources()
        
        # Self-improving parameters
        self.collection_priorities = {
            'sentiment': 0.5,
            'technical': 0.7,
            'fundamental': 0.6,
            'network': 0.4,
            'social': 0.8
        }
    
    def _initialize_ai(self):
        """Initialize the AI components for analysis"""
        try:
            # Check if Anthropic API key is available
            anthropic_key = os.environ.get('ANTHROPIC_API_KEY')
            if not anthropic_key:
                st.warning("ANTHROPIC_API_KEY not found. Some autonomous data collection features will be limited.")
                return False
                
            # Initialize Anthropic client
            self.ai_client = Anthropic(api_key=anthropic_key)
            
            # Test AI connection
            self._test_ai_connection()
            return True
            
        except Exception as e:
            st.error(f"Failed to initialize AI components: {str(e)}")
            return False
    
    def _test_ai_connection(self):
        """Test connection to AI service"""
        try:
            if not os.environ.get('ANTHROPIC_API_KEY'):
                return False
                
            # Simple test message
            response = self.ai_client.messages.create(
                model="claude-3-5-sonnet-20241022",
                max_tokens=10,
                messages=[{"role": "user", "content": "Say 'connection successful' if you receive this message."}]
            )
            
            if "connection successful" in response.content[0].text.lower():
                print("AI connection established successfully")
                return True
            else:
                print("AI connection test resulted in unexpected response")
                return False
                
        except Exception as e:
            print(f"AI connection test failed: {str(e)}")
            return False
    
    def _initialize_web_sources(self):
        """Initialize list of web sources for data collection"""
        return {
            'news': [
                'https://cointelegraph.com/',
                'https://www.coindesk.com/',
                'https://decrypt.co/',
                'https://cryptobriefing.com/',
                'https://www.theblockcrypto.com/'
            ],
            'analysis': [
                'https://insights.glassnode.com/',
                'https://cryptoquant.com/analytics',
                'https://messari.io/research',
                'https://blog.chainalysis.com/'
            ],
            'social': [
                'https://www.reddit.com/r/CryptoCurrency/',
                'https://www.reddit.com/r/ethereum/',
                'https://www.reddit.com/r/defi/'
            ],
            'forums': [
                'https://bitcointalk.org/index.php?board=1.0',
                'https://ethresear.ch/'
            ]
        }
    
    def run_collection_cycle(self):
        """Run a complete data collection cycle"""
        current_time = time.time()
        
        # Update collection priorities dynamically
        self._update_collection_priorities()
        
        # Run components based on their intervals and priorities
        if (current_time - self.last_sentiment_update) >= SENTIMENT_UPDATE_INTERVAL:
            if random.random() < self.collection_priorities['sentiment']:
                self._collect_market_sentiment()
                self.last_sentiment_update = current_time
        
        if (current_time - self.last_web_sources_update) >= WEB_SOURCES_UPDATE_INTERVAL:
            if random.random() < self.collection_priorities['fundamental']:
                self._collect_web_content()
                self.last_web_sources_update = current_time
        
        if (current_time - self.last_pattern_recognition) >= PATTERN_RECOGNITION_INTERVAL:
            if random.random() < self.collection_priorities['technical']:
                self._recognize_market_patterns()
                self.last_pattern_recognition = current_time
        
        # Always update market trends
        self._update_market_trends()
        
        # Find market inefficiencies
        self._find_market_inefficiencies()
        
        # Generate comprehensive market signals
        self._generate_market_signals()
        
        return {
            "sentiment": self.sentiment_data,
            "signals": self.market_signals, 
            "patterns": self.discovered_patterns,
            "inefficiencies": self.market_inefficiencies
        }
    
    def _collect_market_sentiment(self):
        """
        Analyze market sentiment from various sources using AI
        """
        print("Collecting market sentiment...")
        assets = crypto_data.get_available_cryptos()[:10]  # Focus on top 10 assets
        
        # Update sentiment for each asset
        for asset in assets:
            # Get existing sentiment or initialize
            current_sentiment = self.sentiment_data.get(asset, {
                'value': 0,
                'sources': 0,
                'change': 0,
                'timestamp': time.time(),
                'confidence': 0
            })
            
            if self.ai_ready:
                # Use AI to analyze sentiment if available
                sentiment_value, confidence = self._analyze_asset_sentiment_with_ai(asset)
            else:
                # Otherwise use quantitative analysis
                sentiment_value, confidence = self._analyze_asset_sentiment_quantitative(asset)
            
            # Calculate change and update
            previous = current_sentiment['value']
            change = sentiment_value - previous
            
            self.sentiment_data[asset] = {
                'value': sentiment_value,
                'sources': current_sentiment['sources'] + 1,
                'change': change,
                'timestamp': time.time(),
                'confidence': confidence
            }
        
        print(f"Sentiment collection complete for {len(assets)} assets")
    
    def _analyze_asset_sentiment_with_ai(self, asset):
        """Use AI to analyze sentiment for a specific asset"""
        try:
            # Get recent headlines about the asset
            sources = []
            for category, urls in self.web_sources.items():
                source = random.choice(urls)
                sources.append(source)
            
            # Limit to a random subset
            sources = random.sample(sources, min(3, len(sources)))
            
            # Content to analyze (would extract real content in production)
            sample_content = f"Recent market discussions, news and trends related to {asset}."
            
            # Send to AI for analysis
            prompt = f"""
            Analyze the current market sentiment for {asset} based on the following information:
            
            {sample_content}
            
            Score the sentiment on a scale from -1 (extremely bearish) to +1 (extremely bullish).
            Also rate your confidence in this assessment from 0 to 1.
            
            Provide output in JSON format with keys "sentiment_score" and "confidence".
            """
            
            response = self.ai_client.messages.create(
                model="claude-3-5-sonnet-20241022",
                max_tokens=200,
                messages=[{"role": "user", "content": prompt}]
            )
            
            # Extract JSON from response
            response_text = response.content[0].text
            if '{' in response_text and '}' in response_text:
                json_str = response_text[response_text.find('{'):response_text.rfind('}')+1]
                result = json.loads(json_str)
                return result.get('sentiment_score', 0), result.get('confidence', 0.5)
            else:
                # Fallback if response isn't proper JSON
                return 0, 0.3
                
        except Exception as e:
            print(f"Error analyzing sentiment with AI for {asset}: {str(e)}")
            return 0, 0.3
    
    def _analyze_asset_sentiment_quantitative(self, asset):
        """
        Analyze sentiment based on quantitative metrics when AI is unavailable
        """
        # Get price data
        historical_data = crypto_data.get_historical_data(asset, days=7)
        
        if historical_data is None or historical_data.empty:
            return 0, 0.3
        
        # Calculate momentum
        returns = historical_data['close'].pct_change().dropna()
        momentum = returns.mean() * 100
        
        # Calculate volatility
        volatility = returns.std() * 100
        
        # Calculate RSI
        rsi = crypto_data.calculate_rsi(historical_data['close']).iloc[-1]
        
        # Normalize RSI to -1 to 1 range (50 is neutral)
        normalized_rsi = (rsi - 50) / 50
        
        # Normalize momentum based on volatility
        normalized_momentum = momentum / (volatility + 1e-6)  # Avoid division by zero
        
        # Combine signals
        sentiment = (normalized_rsi * 0.6) + (normalized_momentum * 0.4)
        
        # Clamp to -1 to 1 range
        sentiment = max(-1, min(1, sentiment))
        
        # Confidence based on data quality
        data_quality = min(1.0, len(historical_data) / 7)  # Higher quality if more data points
        momentum_confidence = 1.0 - (volatility / 30)  # Lower confidence with higher volatility
        confidence = data_quality * max(0.3, momentum_confidence)
        
        return sentiment, confidence
    
    def _collect_web_content(self):
        """
        Collect and analyze content from web sources
        """
        print("Collecting web content...")
        
        # Select a random category and source
        category = random.choice(list(self.web_sources.keys()))
        sources = self.web_sources[category]
        selected_sources = random.sample(sources, min(MAX_SOURCES_PER_RUN, len(sources)))
        
        insights = {}
        
        for source_url in selected_sources:
            try:
                # Use trafilatura to extract text from the web page
                downloaded = trafilatura.fetch_url(source_url)
                if downloaded:
                    extracted_text = trafilatura.extract(downloaded)
                    if extracted_text and len(extracted_text) > 100:
                        if self.ai_ready:
                            # Use AI to analyze the content
                            analysis = self._analyze_content_with_ai(extracted_text, category)
                        else:
                            # Simple keyword-based analysis
                            analysis = self._analyze_content_keywords(extracted_text)
                        
                        insights[source_url] = {
                            'category': category,
                            'timestamp': time.time(),
                            'analysis': analysis
                        }
            except Exception as e:
                print(f"Error processing {source_url}: {str(e)}")
        
        # Merge with existing insights
        self.web_content_insights.update(insights)
        
        # Keep only the most recent insights (max 50)
        if len(self.web_content_insights) > 50:
            # Sort by timestamp and keep most recent
            sorted_insights = sorted(
                self.web_content_insights.items(), 
                key=lambda x: x[1]['timestamp'], 
                reverse=True
            )
            self.web_content_insights = dict(sorted_insights[:50])
        
        print(f"Web content collection complete for {len(selected_sources)} sources")
    
    def _analyze_content_with_ai(self, content, category):
        """Use AI to analyze web content"""
        try:
            # Limit content length to avoid token limits
            max_chars = 8000
            if len(content) > max_chars:
                content = content[:max_chars] + "..."
            
            prompt = f"""
            Analyze the following cryptocurrency and DeFi related content.
            Extract key market insights, emerging trends, and potential trading signals.
            
            Content category: {category}
            
            Content:
            {content}
            
            Provide analysis in JSON format with the following keys:
            1. "key_insights" (list of string): The most important takeaways
            2. "market_impact" (dict): Potential impact on different assets (asset -> impact description)
            3. "sentiment" (float): Overall sentiment from -1 (bearish) to 1 (bullish)
            4. "confidence" (float): Confidence in analysis from 0 to 1
            5. "emerging_trends" (list of string): Any emerging trends identified
            """
            
            response = self.ai_client.messages.create(
                model="claude-3-5-sonnet-20241022",
                max_tokens=1000,
                messages=[{"role": "user", "content": prompt}]
            )
            
            # Extract JSON from response
            response_text = response.content[0].text
            if '{' in response_text and '}' in response_text:
                json_str = response_text[response_text.find('{'):response_text.rfind('}')+1]
                result = json.loads(json_str)
                return result
            else:
                # Fallback
                return {
                    "key_insights": ["Failed to parse AI response"],
                    "market_impact": {},
                    "sentiment": 0,
                    "confidence": 0.3,
                    "emerging_trends": []
                }
                
        except Exception as e:
            print(f"Error analyzing content with AI: {str(e)}")
            return {
                "key_insights": ["Error in AI analysis"],
                "market_impact": {},
                "sentiment": 0,
                "confidence": 0.3,
                "emerging_trends": []
            }
    
    def _analyze_content_keywords(self, content):
        """Simple keyword-based content analysis when AI is unavailable"""
        crypto_keywords = {
            'bitcoin': {'sentiment': 0, 'count': 0},
            'ethereum': {'sentiment': 0, 'count': 0},
            'defi': {'sentiment': 0, 'count': 0},
            'bull': {'sentiment': 0.7, 'count': 0},
            'bear': {'sentiment': -0.7, 'count': 0},
            'rally': {'sentiment': 0.8, 'count': 0},
            'crash': {'sentiment': -0.8, 'count': 0},
            'growth': {'sentiment': 0.5, 'count': 0},
            'decline': {'sentiment': -0.5, 'count': 0},
            'launch': {'sentiment': 0.6, 'count': 0},
            'hack': {'sentiment': -0.9, 'count': 0},
            'security': {'sentiment': 0.3, 'count': 0},
            'regulation': {'sentiment': -0.2, 'count': 0},
            'adoption': {'sentiment': 0.7, 'count': 0},
            'ban': {'sentiment': -0.8, 'count': 0}
        }
        
        # Count occurrences of keywords
        content_lower = content.lower()
        for keyword in crypto_keywords:
            crypto_keywords[keyword]['count'] = content_lower.count(keyword)
        
        # Calculate overall sentiment
        total_count = sum(item['count'] for item in crypto_keywords.values())
        if total_count > 0:
            sentiment = sum(item['sentiment'] * item['count'] for item in crypto_keywords.values()) / total_count
        else:
            sentiment = 0
        
        # Extract key insights (most mentioned keywords)
        sorted_keywords = sorted(
            crypto_keywords.items(), 
            key=lambda x: x[1]['count'], 
            reverse=True
        )
        key_insights = [f"{keyword}" for keyword, data in sorted_keywords[:5] if data['count'] > 0]
        
        # Identify assets mentioned
        market_impact = {}
        crypto_assets = crypto_data.get_available_cryptos()
        for asset in crypto_assets:
            if asset.lower() in content_lower or TOKEN_ID_MAP.get(asset, "").lower() in content_lower:
                market_impact[asset] = "Mentioned in content"
        
        return {
            "key_insights": key_insights,
            "market_impact": market_impact,
            "sentiment": sentiment,
            "confidence": min(0.3, 0.1 + (total_count / 100)),  # Higher confidence with more keyword matches
            "emerging_trends": []
        }
    
    def _recognize_market_patterns(self):
        """
        Identify market patterns using technical analysis
        """
        print("Identifying market patterns...")
        
        assets = crypto_data.get_available_cryptos()[:10]  # Focus on top assets
        
        new_patterns = []
        
        for asset in assets:
            # Get historical data
            data = crypto_data.get_historical_data(asset, days=30)
            
            if data is None or data.empty:
                continue
            
            # Identify common patterns
            try:
                patterns = self._identify_technical_patterns(data, asset)
                
                if patterns:
                    new_patterns.extend(patterns)
                    
            except Exception as e:
                print(f"Error detecting patterns for {asset}: {str(e)}")
        
        # Add new patterns to discovered patterns
        if new_patterns:
            self.discovered_patterns.extend(new_patterns)
            
            # Keep only the most recent patterns (max 100)
            if len(self.discovered_patterns) > 100:
                self.discovered_patterns = self.discovered_patterns[-100:]
        
        print(f"Pattern recognition complete, found {len(new_patterns)} new patterns")
    
    def _identify_technical_patterns(self, data, asset):
        """Identify technical chart patterns in price data"""
        patterns = []
        
        # Make sure we have enough data
        if len(data) < 10:
            return patterns
        
        # Get price data
        close_prices = data['close'].values
        
        # Pattern 1: Double Top
        if self._is_double_top(close_prices):
            patterns.append({
                'asset': asset,
                'pattern': 'Double Top',
                'signal': 'bearish',
                'confidence': 0.7,
                'timestamp': time.time()
            })
        
        # Pattern 2: Double Bottom
        if self._is_double_bottom(close_prices):
            patterns.append({
                'asset': asset,
                'pattern': 'Double Bottom',
                'signal': 'bullish',
                'confidence': 0.7,
                'timestamp': time.time()
            })
        
        # Pattern 3: Head and Shoulders
        if self._is_head_and_shoulders(close_prices):
            patterns.append({
                'asset': asset,
                'pattern': 'Head and Shoulders',
                'signal': 'bearish',
                'confidence': 0.8,
                'timestamp': time.time()
            })
        
        # Pattern 4: Inverse Head and Shoulders
        if self._is_inverse_head_and_shoulders(close_prices):
            patterns.append({
                'asset': asset,
                'pattern': 'Inverse Head and Shoulders',
                'signal': 'bullish',
                'confidence': 0.8,
                'timestamp': time.time()
            })
        
        # Pattern 5: Bull Flag
        if self._is_bull_flag(data):
            patterns.append({
                'asset': asset,
                'pattern': 'Bull Flag',
                'signal': 'bullish',
                'confidence': 0.6,
                'timestamp': time.time()
            })
        
        # Pattern 6: Bear Flag
        if self._is_bear_flag(data):
            patterns.append({
                'asset': asset,
                'pattern': 'Bear Flag',
                'signal': 'bearish',
                'confidence': 0.6,
                'timestamp': time.time()
            })
        
        return patterns
    
    def _is_double_top(self, prices):
        """Check for double top pattern"""
        if len(prices) < 15:
            return False
            
        # Simple implementation - look for two peaks of similar height
        # with a valley in between
        peaks = []
        for i in range(1, len(prices) - 1):
            if prices[i] > prices[i-1] and prices[i] > prices[i+1]:
                peaks.append((i, prices[i]))
        
        if len(peaks) < 2:
            return False
        
        # Check the last two peaks
        if len(peaks) >= 2:
            peak1 = peaks[-2]
            peak2 = peaks[-1]
            
            # Check if peaks are of similar height
            if abs(peak1[1] - peak2[1]) / peak1[1] < 0.03:
                # Check if there's a valley in between
                valley = min(prices[peak1[0]:peak2[0]])
                peak_to_valley = (peak1[1] - valley) / peak1[1]
                
                if peak_to_valley > 0.03:
                    return True
        
        return False
    
    def _is_double_bottom(self, prices):
        """Check for double bottom pattern"""
        if len(prices) < 15:
            return False
            
        # Simple implementation - look for two troughs of similar height
        # with a peak in between
        troughs = []
        for i in range(1, len(prices) - 1):
            if prices[i] < prices[i-1] and prices[i] < prices[i+1]:
                troughs.append((i, prices[i]))
        
        if len(troughs) < 2:
            return False
        
        # Check the last two troughs
        if len(troughs) >= 2:
            trough1 = troughs[-2]
            trough2 = troughs[-1]
            
            # Check if troughs are of similar height
            if abs(trough1[1] - trough2[1]) / trough1[1] < 0.03:
                # Check if there's a peak in between
                peak = max(prices[trough1[0]:trough2[0]])
                trough_to_peak = (peak - trough1[1]) / trough1[1]
                
                if trough_to_peak > 0.03:
                    return True
        
        return False
    
    def _is_head_and_shoulders(self, prices):
        """Check for head and shoulders pattern"""
        if len(prices) < 20:
            return False
            
        # Need at least 5 extreme points (3 peaks and 2 troughs)
        peaks = []
        for i in range(2, len(prices) - 2):
            if prices[i] > prices[i-1] and prices[i] > prices[i-2] and \
               prices[i] > prices[i+1] and prices[i] > prices[i+2]:
                peaks.append((i, prices[i]))
        
        troughs = []
        for i in range(2, len(prices) - 2):
            if prices[i] < prices[i-1] and prices[i] < prices[i-2] and \
               prices[i] < prices[i+1] and prices[i] < prices[i+2]:
                troughs.append((i, prices[i]))
        
        if len(peaks) < 3 or len(troughs) < 2:
            return False
        
        # Check the last three peaks and two troughs
        if len(peaks) >= 3 and len(troughs) >= 2:
            left_shoulder = peaks[-3]
            head = peaks[-2]
            right_shoulder = peaks[-1]
            
            left_trough = troughs[-2]
            right_trough = troughs[-1]
            
            # Verify the sequence: left shoulder -> left trough -> head -> right trough -> right shoulder
            if left_shoulder[0] < left_trough[0] < head[0] < right_trough[0] < right_shoulder[0]:
                # Check if head is higher than shoulders
                if head[1] > left_shoulder[1] and head[1] > right_shoulder[1]:
                    # Check if shoulders are of similar height
                    if abs(left_shoulder[1] - right_shoulder[1]) / left_shoulder[1] < 0.1:
                        # Check if troughs are of similar height (neckline)
                        if abs(left_trough[1] - right_trough[1]) / left_trough[1] < 0.05:
                            return True
        
        return False
    
    def _is_inverse_head_and_shoulders(self, prices):
        """Check for inverse head and shoulders pattern"""
        if len(prices) < 20:
            return False
            
        # Need at least 5 extreme points (3 troughs and 2 peaks)
        troughs = []
        for i in range(2, len(prices) - 2):
            if prices[i] < prices[i-1] and prices[i] < prices[i-2] and \
               prices[i] < prices[i+1] and prices[i] < prices[i+2]:
                troughs.append((i, prices[i]))
        
        peaks = []
        for i in range(2, len(prices) - 2):
            if prices[i] > prices[i-1] and prices[i] > prices[i-2] and \
               prices[i] > prices[i+1] and prices[i] > prices[i+2]:
                peaks.append((i, prices[i]))
        
        if len(troughs) < 3 or len(peaks) < 2:
            return False
        
        # Check the last three troughs and two peaks
        if len(troughs) >= 3 and len(peaks) >= 2:
            left_shoulder = troughs[-3]
            head = troughs[-2]
            right_shoulder = troughs[-1]
            
            left_peak = peaks[-2]
            right_peak = peaks[-1]
            
            # Verify the sequence: left shoulder -> left peak -> head -> right peak -> right shoulder
            if left_shoulder[0] < left_peak[0] < head[0] < right_peak[0] < right_shoulder[0]:
                # Check if head is lower than shoulders
                if head[1] < left_shoulder[1] and head[1] < right_shoulder[1]:
                    # Check if shoulders are of similar height
                    if abs(left_shoulder[1] - right_shoulder[1]) / left_shoulder[1] < 0.1:
                        # Check if peaks are of similar height (neckline)
                        if abs(left_peak[1] - right_peak[1]) / left_peak[1] < 0.05:
                            return True
        
        return False
    
    def _is_bull_flag(self, data):
        """Check for bull flag pattern"""
        if len(data) < 14:
            return False
            
        # Need significant price rise followed by consolidation
        prices = data['close'].values
        
        # Check for strong move up in the first half
        first_half = prices[:len(prices)//2]
        initial_price = first_half[0]
        final_price = first_half[-1]
        
        if final_price < initial_price:
            return False
        
        price_increase = (final_price - initial_price) / initial_price
        
        # Need at least 5% increase for flag pole
        if price_increase < 0.05:
            return False
        
        # Check for consolidation in second half (flag)
        second_half = prices[len(prices)//2:]
        
        # Consolidation means price stays within a narrow range
        price_range = (max(second_half) - min(second_half)) / min(second_half)
        
        # Range should be less than the initial increase
        if price_range > price_increase:
            return False
        
        # Check for downward or sideways trend in flag
        slope, _, _, _, _ = stats.linregress(range(len(second_half)), second_half)
        
        # Slope should be flat to slightly negative
        if slope > 0.001:
            return False
        
        return True
    
    def _is_bear_flag(self, data):
        """Check for bear flag pattern"""
        if len(data) < 14:
            return False
            
        # Need significant price drop followed by consolidation
        prices = data['close'].values
        
        # Check for strong move down in the first half
        first_half = prices[:len(prices)//2]
        initial_price = first_half[0]
        final_price = first_half[-1]
        
        if final_price > initial_price:
            return False
        
        price_decrease = (initial_price - final_price) / initial_price
        
        # Need at least 5% decrease for flag pole
        if price_decrease < 0.05:
            return False
        
        # Check for consolidation in second half (flag)
        second_half = prices[len(prices)//2:]
        
        # Consolidation means price stays within a narrow range
        price_range = (max(second_half) - min(second_half)) / min(second_half)
        
        # Range should be less than the initial decrease
        if price_range > price_decrease:
            return False
        
        # Check for upward or sideways trend in flag
        slope, _, _, _, _ = stats.linregress(range(len(second_half)), second_half)
        
        # Slope should be flat to slightly positive
        if slope < -0.001:
            return False
        
        return True
    
    def _update_market_trends(self):
        """Update and maintain market trend data"""
        assets = crypto_data.get_available_cryptos()[:10]  # Focus on top assets
        
        current_time = time.time()
        
        for asset in assets:
            # Get current price
            price = crypto_data.get_current_price(asset)
            
            if price:
                # Add to trend history
                self.market_trends[asset].append({
                    'price': price,
                    'timestamp': current_time
                })
                
                # Keep only recent history (MARKET_TRENDS_MEMORY hours)
                cutoff_time = current_time - (MARKET_TRENDS_MEMORY * 3600)
                self.market_trends[asset] = [
                    point for point in self.market_trends[asset] 
                    if point['timestamp'] > cutoff_time
                ]
    
    def _find_market_inefficiencies(self):
        """
        Identify potential market inefficiencies by analyzing collected data
        """
        assets = crypto_data.get_available_cryptos()[:10]
        
        new_inefficiencies = []
        
        for asset in assets:
            # Skip if we don't have trend data
            if asset not in self.market_trends or len(self.market_trends[asset]) < 2:
                continue
            
            # Get latest price
            latest_data = self.market_trends[asset][-1]
            current_price = latest_data['price']
            
            # Check sentiment vs price action
            if asset in self.sentiment_data:
                sentiment = self.sentiment_data[asset]['value']
                
                # Calculate recent price change
                if len(self.market_trends[asset]) > 1:
                    earliest_available = self.market_trends[asset][0]['price']
                    price_change = (current_price - earliest_available) / earliest_available
                    
                    # Check for sentiment-price divergence
                    # Positive sentiment but price falling
                    if sentiment > 0.5 and price_change < -0.03:
                        new_inefficiencies.append({
                            'asset': asset,
                            'type': 'sentiment_price_divergence',
                            'description': f"Positive sentiment but price falling for {asset}",
                            'opportunity': 'potential_buy',
                            'timestamp': time.time(),
                            'metrics': {
                                'sentiment': sentiment,
                                'price_change': price_change
                            }
                        })
                    
                    # Negative sentiment but price rising
                    elif sentiment < -0.5 and price_change > 0.03:
                        new_inefficiencies.append({
                            'asset': asset,
                            'type': 'sentiment_price_divergence',
                            'description': f"Negative sentiment but price rising for {asset}",
                            'opportunity': 'potential_sell',
                            'timestamp': time.time(),
                            'metrics': {
                                'sentiment': sentiment,
                                'price_change': price_change
                            }
                        })
            
            # Look for pattern-based inefficiencies
            asset_patterns = [p for p in self.discovered_patterns if p['asset'] == asset]
            if asset_patterns:
                latest_pattern = max(asset_patterns, key=lambda x: x['timestamp'])
                pattern_age = time.time() - latest_pattern['timestamp']
                
                # If pattern is recent (last 6 hours) but price hasn't moved accordingly
                if pattern_age < 21600:  # 6 hours in seconds
                    if len(self.market_trends[asset]) > 5:
                        recent_price_change = (current_price - self.market_trends[asset][-5]['price']) / self.market_trends[asset][-5]['price']
                        
                        # Bullish pattern but price stagnant or falling
                        if latest_pattern['signal'] == 'bullish' and recent_price_change < 0.005:
                            new_inefficiencies.append({
                                'asset': asset,
                                'type': 'pattern_price_divergence',
                                'description': f"Bullish {latest_pattern['pattern']} pattern detected but price not rising for {asset}",
                                'opportunity': 'potential_buy',
                                'timestamp': time.time(),
                                'metrics': {
                                    'pattern': latest_pattern['pattern'],
                                    'pattern_confidence': latest_pattern['confidence'],
                                    'recent_price_change': recent_price_change
                                }
                            })
                        
                        # Bearish pattern but price stagnant or rising
                        elif latest_pattern['signal'] == 'bearish' and recent_price_change > -0.005:
                            new_inefficiencies.append({
                                'asset': asset,
                                'type': 'pattern_price_divergence',
                                'description': f"Bearish {latest_pattern['pattern']} pattern detected but price not falling for {asset}",
                                'opportunity': 'potential_sell',
                                'timestamp': time.time(),
                                'metrics': {
                                    'pattern': latest_pattern['pattern'],
                                    'pattern_confidence': latest_pattern['confidence'],
                                    'recent_price_change': recent_price_change
                                }
                            })
        
        # Add new inefficiencies to the list
        if new_inefficiencies:
            self.market_inefficiencies.extend(new_inefficiencies)
            
            # Keep only recent inefficiencies (last 24 hours)
            cutoff_time = time.time() - 86400  # 24 hours in seconds
            self.market_inefficiencies = [
                ineff for ineff in self.market_inefficiencies
                if ineff['timestamp'] > cutoff_time
            ]
            
            # Sort by timestamp (most recent first)
            self.market_inefficiencies.sort(key=lambda x: x['timestamp'], reverse=True)
            
            # Keep only top 50
            if len(self.market_inefficiencies) > 50:
                self.market_inefficiencies = self.market_inefficiencies[:50]
    
    def _generate_market_signals(self):
        """
        Generate comprehensive market signals based on all collected data
        """
        assets = crypto_data.get_available_cryptos()[:10]  # Focus on top assets
        
        for asset in assets:
            # Initialize signal with default neutral values
            signal = {
                'asset': asset,
                'timestamp': time.time(),
                'sentiment_signal': 'neutral',
                'sentiment_strength': 0,
                'technical_signal': 'neutral',
                'technical_strength': 0,
                'inefficiency_signal': 'neutral',
                'inefficiency_strength': 0,
                'combined_signal': 'neutral',
                'signal_strength': 0,
                'timeframe': '4h',  # Default timeframe
                'confidence': 0.5
            }
            
            # Process sentiment data
            if asset in self.sentiment_data:
                sentiment = self.sentiment_data[asset]['value']
                confidence = self.sentiment_data[asset]['confidence']
                
                if sentiment > 0.3:
                    signal['sentiment_signal'] = 'bullish'
                    signal['sentiment_strength'] = sentiment
                elif sentiment < -0.3:
                    signal['sentiment_signal'] = 'bearish'
                    signal['sentiment_strength'] = -sentiment
            
            # Process technical patterns
            asset_patterns = [p for p in self.discovered_patterns if p['asset'] == asset]
            if asset_patterns:
                # Get the most recent pattern
                latest_pattern = max(asset_patterns, key=lambda x: x['timestamp'])
                age_hours = (time.time() - latest_pattern['timestamp']) / 3600
                
                # Only consider recent patterns (last 12 hours)
                if age_hours < 12:
                    signal['technical_signal'] = latest_pattern['signal']
                    signal['technical_strength'] = latest_pattern['confidence'] * (1 - (age_hours / 24))
            
            # Process inefficiencies
            asset_inefficiencies = [i for i in self.market_inefficiencies if i['asset'] == asset]
            if asset_inefficiencies:
                # Get the most significant inefficiency
                if any(i['opportunity'] == 'potential_buy' for i in asset_inefficiencies):
                    signal['inefficiency_signal'] = 'bullish'
                    signal['inefficiency_strength'] = 0.7  # Fixed strength for now
                elif any(i['opportunity'] == 'potential_sell' for i in asset_inefficiencies):
                    signal['inefficiency_signal'] = 'bearish'
                    signal['inefficiency_strength'] = 0.7
            
            # Calculate combined signal
            signal_values = {
                'bullish': 1,
                'neutral': 0,
                'bearish': -1
            }
            
            # Weighted average of signals
            sentiment_value = signal_values[signal['sentiment_signal']] * signal['sentiment_strength']
            technical_value = signal_values[signal['technical_signal']] * signal['technical_strength']
            inefficiency_value = signal_values[signal['inefficiency_signal']] * signal['inefficiency_strength']
            
            # Weights for different signals
            weights = {
                'sentiment': 0.3,
                'technical': 0.4,
                'inefficiency': 0.3
            }
            
            # Calculate weighted sum
            combined_value = (
                (sentiment_value * weights['sentiment']) +
                (technical_value * weights['technical']) +
                (inefficiency_value * weights['inefficiency'])
            )
            
            # Determine combined signal
            if combined_value > 0.2:
                signal['combined_signal'] = 'bullish'
                signal['signal_strength'] = combined_value
            elif combined_value < -0.2:
                signal['combined_signal'] = 'bearish'
                signal['signal_strength'] = -combined_value
            
            # Calculate confidence based on agreement between signals
            signals_list = [
                signal['sentiment_signal'],
                signal['technical_signal'],
                signal['inefficiency_signal']
            ]
            
            if all(s == signals_list[0] for s in signals_list):
                # All signals agree
                signal['confidence'] = 0.9
            elif signals_list.count('neutral') == 2:
                # Two neutrals and one direction
                signal['confidence'] = 0.6
            elif signals_list.count('bullish') == 2 or signals_list.count('bearish') == 2:
                # Two agree, one disagrees
                signal['confidence'] = 0.7
            elif 'bullish' in signals_list and 'bearish' in signals_list:
                # Conflicting signals
                signal['confidence'] = 0.5
            
            # Update signal in market signals dictionary
            self.market_signals[asset] = signal
    
    def _update_collection_priorities(self):
        """Dynamically adjust data collection priorities based on results"""
        # Default adjustment is small
        adjustment = 0.05
        
        # Increase priority for components that discovered useful information
        if self.market_inefficiencies:
            # Count inefficiencies by type
            sentiment_inefficiencies = sum(1 for i in self.market_inefficiencies if i['type'] == 'sentiment_price_divergence')
            pattern_inefficiencies = sum(1 for i in self.market_inefficiencies if i['type'] == 'pattern_price_divergence')
            
            if sentiment_inefficiencies > 0:
                self.collection_priorities['sentiment'] = min(1.0, self.collection_priorities['sentiment'] + adjustment)
            
            if pattern_inefficiencies > 0:
                self.collection_priorities['technical'] = min(1.0, self.collection_priorities['technical'] + adjustment)
        
        # Increase priority for components with high signal confidence
        high_confidence_signals = [s for s in self.market_signals.values() if s['confidence'] > 0.7]
        if high_confidence_signals:
            # Simple reinforcement - increase all priorities
            for key in self.collection_priorities:
                self.collection_priorities[key] = min(1.0, self.collection_priorities[key] + (adjustment / 2))
        
        # Normalize priorities to ensure they don't all become 1.0
        total = sum(self.collection_priorities.values())
        if total > 0:
            factor = (len(self.collection_priorities) * 0.7) / total  # Target average of 0.7
            for key in self.collection_priorities:
                self.collection_priorities[key] *= factor
    
    def get_available_data(self):
        """Get all available market data for dashboard display"""
        return {
            'sentiment': self.sentiment_data,
            'market_signals': self.market_signals,
            'discovered_patterns': self.discovered_patterns,
            'market_inefficiencies': self.market_inefficiencies,
            'web_insights': self.web_content_insights,
            'market_trends': self.market_trends,
            'collection_status': {
                'priorities': self.collection_priorities,
                'last_sentiment_update': self.last_sentiment_update,
                'last_web_sources_update': self.last_web_sources_update,
                'last_pattern_recognition': self.last_pattern_recognition,
                'ai_ready': self.ai_ready
            }
        }
    
    def get_trading_signals(self):
        """Get actionable trading signals"""
        return {asset: signal for asset, signal in self.market_signals.items()
                if signal['combined_signal'] != 'neutral' and signal['confidence'] > 0.6}
    
    def get_inefficiency_opportunities(self):
        """Get market inefficiency opportunities"""
        # Return most recent inefficiencies first
        return sorted(self.market_inefficiencies, key=lambda x: x['timestamp'], reverse=True)
    
    def get_collection_status(self):
        """Get current status of data collection"""
        return {
            'collection_priorities': self.collection_priorities,
            'ai_ready': self.ai_ready,
            'last_sentiment_update': datetime.fromtimestamp(self.last_sentiment_update) if self.last_sentiment_update > 0 else None,
            'last_web_sources_update': datetime.fromtimestamp(self.last_web_sources_update) if self.last_web_sources_update > 0 else None,
            'last_pattern_recognition': datetime.fromtimestamp(self.last_pattern_recognition) if self.last_pattern_recognition > 0 else None,
            'active_collection_tasks': self.active_collection_tasks
        }


# Mapping from the crypto_data module, used by the keyword analysis
TOKEN_ID_MAP = {
    "BTC": "bitcoin",
    "ETH": "ethereum",
    "XRP": "ripple",
    "LTC": "litecoin",
    "BCH": "bitcoin-cash",
    "ADA": "cardano",
    "DOT": "polkadot",
    "LINK": "chainlink",
    "XLM": "stellar",
    "UNI": "uniswap",
    "DOGE": "dogecoin", 
    "SOL": "solana",
    "AAVE": "aave",
    "WBTC": "wrapped-bitcoin",
    "USDC": "usd-coin",
    "USDT": "tether",
    "DAI": "dai",
    "MATIC": "matic-network",
    "AVAX": "avalanche-2",
    "FTM": "fantom",
    "SUSHI": "sushi"
}


# Singleton instance for global access
_collector_instance = None

def get_collector():
    """Get the singleton collector instance"""
    global _collector_instance
    if _collector_instance is None:
        _collector_instance = AutonomousMarketDataCollector()
    return _collector_instance

def run_autonomous_collection():
    """Run a complete autonomous data collection cycle"""
    collector = get_collector()
    return collector.run_collection_cycle()