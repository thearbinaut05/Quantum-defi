"""
Cryptocurrency Data Module

This module provides functions to fetch cryptocurrency market data from:
1. CryptoCompare API for real-time and historical price data
2. Direct blockchain sources using Web3 connections
3. DEX smart contracts for real trading pair data
4. On-chain database for persistent storage
"""

import os
import json
import time
import logging
import random
import pandas as pd
import numpy as np
import requests
from datetime import datetime, timedelta
import streamlit as st
import psycopg2
from psycopg2.extras import RealDictCursor

# Import our blockchain data collector
import blockchain_data_collector as bdc

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# CryptoCompare API configuration
CRYPTOCOMPARE_API_KEY = os.environ.get('CRYPTOCOMPARE_API_KEY')
CRYPTOCOMPARE_BASE_URL = "https://min-api.cryptocompare.com/data"

# Etherscan API configuration
ETHERSCAN_API_KEY = os.environ.get('ETHERSCAN_API_KEY')
ETHERSCAN_BASE_URL = "https://api.etherscan.io/api"

# Common cryptocurrency mapping (symbol to standard name)
CRYPTO_SYMBOL_MAP = {
    "BTC": "bitcoin",
    "ETH": "ethereum",
    "USDT": "tether",
    "USDC": "usd-coin",
    "DAI": "dai",
    "LINK": "chainlink",
    "UNI": "uniswap",
    "AAVE": "aave",
    "WBTC": "wrapped-bitcoin",
    "SUSHI": "sushiswap",
    "COMP": "compound",
    "SNX": "synthetix-network-token",
    "YFI": "yearn-finance",
    "MKR": "maker",
    "BAT": "basic-attention-token",
    "ZRX": "0x",
    "REN": "ren",
    "MATIC": "polygon",
    "SOL": "solana",
    "AVAX": "avalanche",
    "DOT": "polkadot",
    "ADA": "cardano",
    "XRP": "ripple"
}

# Connect to PostgreSQL database
def get_db_connection():
    """Get a connection to the PostgreSQL database"""
    try:
        conn = psycopg2.connect(os.environ.get('DATABASE_URL'))
        return conn
    except Exception as e:
        logger.error(f"Database connection error: {str(e)}")
        return None

def get_available_exchanges():
    """
    Get list of available exchanges
    
    Returns:
        List of exchange names
    """
    conn = get_db_connection()
    if not conn:
        return ["Uniswap V3", "Uniswap V2", "Sushiswap", "Curve", "Balancer"]
    
    try:
        with conn.cursor() as cur:
            cur.execute("SELECT name FROM dexes WHERE is_active = TRUE ORDER BY name")
            exchanges = [row[0] for row in cur.fetchall()]
        
        return exchanges
    except Exception as e:
        logger.error(f"Error getting available exchanges: {str(e)}")
        return ["Uniswap V3", "Uniswap V2", "Sushiswap", "Curve", "Balancer"]
    finally:
        conn.close()

def get_available_cryptos():
    """
    Get list of available cryptocurrencies
    
    Returns:
        List of cryptocurrency symbols
    """
    conn = get_db_connection()
    if not conn:
        return ["ETH", "WETH", "BTC", "USDC", "USDT", "DAI", "LINK", "UNI", "AAVE"]
    
    try:
        with conn.cursor() as cur:
            cur.execute("SELECT symbol FROM assets WHERE is_active = TRUE ORDER BY symbol")
            cryptos = [row[0] for row in cur.fetchall()]
        
        return cryptos
    except Exception as e:
        logger.error(f"Error getting available cryptocurrencies: {str(e)}")
        return ["ETH", "WETH", "BTC", "USDC", "USDT", "DAI", "LINK", "UNI", "AAVE"]
    finally:
        conn.close()

def get_current_price_from_cryptocompare(crypto, exchange=None):
    """
    Get current price directly from CryptoCompare API
    
    Args:
        crypto: Cryptocurrency symbol
        exchange: Optional exchange name
        
    Returns:
        Current price in USD
    """
    try:
        if not CRYPTOCOMPARE_API_KEY:
            logger.error("CryptoCompare API key is not available")
            return None
            
        url = f"{CRYPTOCOMPARE_BASE_URL}/price"
        params = {
            "fsym": crypto.upper(),
            "tsyms": "USD",
            "api_key": CRYPTOCOMPARE_API_KEY
        }
        
        # Add exchange if specified
        if exchange:
            params["e"] = exchange
            
        response = requests.get(url, params=params)
        
        if response.status_code == 200:
            data = response.json()
            if "USD" in data:
                return float(data["USD"])
                
        logger.warning(f"Failed to get price for {crypto} from CryptoCompare")
        return None
        
    except Exception as e:
        logger.error(f"Error getting price from CryptoCompare: {str(e)}")
        return None

def get_current_price(crypto, exchange=None):
    """
    Get current price for a cryptocurrency - first tries database,
    then CryptoCompare API, and finally blockchain sources
    
    Args:
        crypto: Cryptocurrency symbol
        exchange: Optional exchange name (if None, gets average price)
    
    Returns:
        Current price in USD
    """
    # First, try to get from database (cached data)
    conn = get_db_connection()
    if conn:
        try:
            # Query to get latest price data
            if exchange:
                query = """
                    WITH latest_prices AS (
                        SELECT md.asset_id, md.price_usd, md.timestamp, md.source, a.symbol
                        FROM market_data md
                        JOIN assets a ON md.asset_id = a.id
                        WHERE a.symbol = %s AND md.source ILIKE %s
                        ORDER BY md.timestamp DESC
                        LIMIT 1
                    )
                    SELECT price_usd, timestamp FROM latest_prices
                """
                params = (crypto, f"%{exchange}%")
            else:
                query = """
                    WITH latest_prices AS (
                        SELECT md.asset_id, md.price_usd, md.timestamp, a.symbol
                        FROM market_data md
                        JOIN assets a ON md.asset_id = a.id
                        WHERE a.symbol = %s
                        ORDER BY md.timestamp DESC
                        LIMIT 1
                    )
                    SELECT price_usd, timestamp FROM latest_prices
                """
                params = (crypto,)
            
            with conn.cursor() as cur:
                cur.execute(query, params)
                result = cur.fetchone()
            
            if result:
                price, timestamp = result
                
                # Check if data is fresh (less than 15 minutes old)
                timestamp = timestamp.replace(tzinfo=None)  # Remove timezone info for comparison
                age_minutes = (datetime.now() - timestamp).total_seconds() / 60
                
                if age_minutes < 15:
                    conn.close()
                    return float(price)
        except Exception as e:
            logger.error(f"Database error: {str(e)}")
        finally:
            conn.close()
    
    # If we get here, database didn't have fresh data
    # Try to get from CryptoCompare API
    logger.info(f"Getting fresh price data for {crypto} from CryptoCompare")
    api_price = get_current_price_from_cryptocompare(crypto, exchange)
    
    if api_price is not None:
        # Store in database for future use
        try:
            store_price_in_db(crypto, api_price, source="cryptocompare")
        except Exception as e:
            logger.error(f"Error storing price in database: {str(e)}")
        
        return api_price
    
    # If all else fails, try to get data from blockchain
    logger.info(f"Getting price data for {crypto} from blockchain")
    try:
        bdc.run_data_collection_cycle()
        
        # Connect to database again
        conn = get_db_connection()
        if conn:
            try:
                # Same query as before but after blockchain collection
                if exchange:
                    query = """
                        WITH latest_prices AS (
                            SELECT md.asset_id, md.price_usd, md.timestamp, md.source, a.symbol
                            FROM market_data md
                            JOIN assets a ON md.asset_id = a.id
                            WHERE a.symbol = %s AND md.source ILIKE %s
                            ORDER BY md.timestamp DESC
                            LIMIT 1
                        )
                        SELECT price_usd, timestamp FROM latest_prices
                    """
                    params = (crypto, f"%{exchange}%")
                else:
                    query = """
                        WITH latest_prices AS (
                            SELECT md.asset_id, md.price_usd, md.timestamp, a.symbol
                            FROM market_data md
                            JOIN assets a ON md.asset_id = a.id
                            WHERE a.symbol = %s
                            ORDER BY md.timestamp DESC
                            LIMIT 1
                        )
                        SELECT price_usd, timestamp FROM latest_prices
                    """
                    params = (crypto,)
                
                with conn.cursor() as cur:
                    cur.execute(query, params)
                    result = cur.fetchone()
                
                if result:
                    price, _ = result
                    return float(price)
            finally:
                conn.close()
    except Exception as e:
        logger.error(f"Error during blockchain data collection: {str(e)}")
    
    # If we get here, we couldn't get the price
    logger.warning(f"No price data available for {crypto}")
    return 0

def store_price_in_db(symbol, price_usd, source="cryptocompare"):
    """
    Store price data in the database
    
    Args:
        symbol: Cryptocurrency symbol
        price_usd: Price in USD
        source: Data source
    """
    conn = get_db_connection()
    if not conn:
        logger.error("Failed to connect to database")
        return
    
    try:
        # First, get or create asset record
        with conn.cursor() as cur:
            cur.execute("SELECT id FROM assets WHERE symbol = %s", (symbol,))
            result = cur.fetchone()
            
            if result:
                asset_id = result[0]
            else:
                # Create new asset record
                name = symbol.lower().capitalize()
                cur.execute(
                    "INSERT INTO assets (symbol, name, is_active) VALUES (%s, %s, TRUE) RETURNING id",
                    (symbol, name)
                )
                asset_id = cur.fetchone()[0]
        
            # Insert price data
            cur.execute(
                """
                INSERT INTO market_data 
                (asset_id, price_usd, volume_24h, market_cap, source, timestamp)
                VALUES (%s, %s, 0, 0, %s, %s)
                """,
                (asset_id, price_usd, source, datetime.now())
            )
            
        conn.commit()
    except Exception as e:
        conn.rollback()
        logger.error(f"Error storing price in database: {str(e)}")
    finally:
        conn.close()

def get_historical_data(crypto, days=30, exchange=None):
    """
    Get historical price data for a cryptocurrency using the CryptoCompare API
    
    Args:
        crypto: Cryptocurrency symbol
        days: Number of days of data to fetch
        exchange: Optional exchange name (if None, gets market average)
    
    Returns:
        DataFrame with historical data (date, open, high, low, close, volume)
    """
    try:
        if not CRYPTOCOMPARE_API_KEY:
            logger.error("CryptoCompare API key is not available. Please set the CRYPTOCOMPARE_API_KEY environment variable.")
            st.error("CryptoCompare API key is required for market data. Please contact the administrator.")
            return None
            
        # Build the API URL for OHLCV (Open, High, Low, Close, Volume) data
        # CryptoCompare API provides complete OHLCV data
        limit = days
        url = f"{CRYPTOCOMPARE_BASE_URL}/v2/histoday"
        params = {
            "fsym": crypto.upper(),  # From Symbol
            "tsym": "USD",          # To Symbol (USD)
            "limit": limit,         # Number of data points
            "api_key": CRYPTOCOMPARE_API_KEY
        }
        
        # Add exchange parameter if specified
        if exchange:
            params["e"] = exchange
            
        logger.info(f"Fetching historical data for {crypto}/USD from CryptoCompare")
        response = requests.get(url, params=params)
        
        if response.status_code == 200:
            data = response.json()
            
            # Check if response is valid
            if data.get("Response") == "Success" and "Data" in data:
                ohlcv_data = data["Data"]["Data"]
                
                if not ohlcv_data:
                    logger.warning(f"No historical data available for {crypto}")
                    st.warning(f"No historical data available for {crypto}. Please try another cryptocurrency.")
                    return None
                
                # Create DataFrame from the data
                df = pd.DataFrame(ohlcv_data)
                
                # Convert timestamp to datetime
                df['timestamp'] = pd.to_datetime(df['time'], unit='s')
                df.set_index('timestamp', inplace=True)
                
                # Rename columns to standard format
                df.rename(columns={
                    'open': 'open',
                    'high': 'high',
                    'low': 'low',
                    'close': 'close',
                    'volumefrom': 'volume'
                }, inplace=True)
                
                # Select only the columns we need
                df = df[['open', 'high', 'low', 'close', 'volume']]
                
                # Add technical indicators
                df['sma_7'] = df['close'].rolling(window=7).mean()
                df['ema_14'] = df['close'].ewm(span=14, adjust=False).mean()
                df['rsi_14'] = calculate_rsi(df['close'], 14)
                
                return df
            else:
                error_message = data.get("Message", "Unknown error")
                logger.error(f"CryptoCompare API error: {error_message}")
                st.error(f"Error fetching data: {error_message}")
                return None
        else:
            logger.error(f"CryptoCompare API request failed with status code {response.status_code}")
            st.error(f"Failed to fetch market data. Status code: {response.status_code}")
            return None
            
    except Exception as e:
        logger.error(f"Error fetching historical data: {str(e)}")
        st.error(f"Error fetching historical data: {str(e)}")
        return None

def calculate_rsi(prices, window=14):
    """
    Calculate the Relative Strength Index (RSI) for a price series
    
    Args:
        prices: Series of prices
        window: RSI window length (typically 14)
        
    Returns:
        Series with RSI values
    """
    # Calculate price changes
    delta = prices.diff()
    
    # Separate gains and losses
    gain = delta.copy()
    loss = delta.copy()
    gain[gain < 0] = 0
    loss[loss > 0] = 0
    loss = -loss
    
    # Calculate average gain and loss
    avg_gain = gain.rolling(window=window).mean()
    avg_loss = loss.rolling(window=window).mean()
    
    # Calculate RS and RSI
    rs = avg_gain / avg_loss
    rsi = 100 - (100 / (1 + rs))
    
    return rsi