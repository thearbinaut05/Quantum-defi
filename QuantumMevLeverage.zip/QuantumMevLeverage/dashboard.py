import streamlit as st
import pandas as pd
import numpy as np
import plotly.graph_objects as go
import plotly.express as px
from datetime import datetime, timedelta
import time
import random

# Import local modules
import crypto_data
import utils
import quantum_visualizer

def render_dashboard():
    """Render the main dashboard page"""
    st.title("Quantum DeFi Protocol Dashboard")
    
    # Check if user is connected
    if not st.session_state.connected:
        st.warning("Please connect your wallet to view personalized data.")
    
    # Create dashboard metrics
    col1, col2, col3, col4 = st.columns(4)
    
    # TVL (Total Value Locked)
    tvl = format_currency(random.uniform(1000000, 10000000))
    col1.metric("Total Value Locked", tvl, "+5.2%")
    
    # 24h Trading Volume
    volume = format_currency(random.uniform(500000, 2000000))
    col2.metric("24h Volume", volume, "+2.8%")
    
    # Active Positions
    active_positions = random.randint(100, 500)
    col3.metric("Active Positions", f"{active_positions}", "+12")
    
    # Protocol Earnings
    earnings = format_currency(random.uniform(10000, 50000))
    col4.metric("Protocol Earnings", earnings, "+4.7%")
    
    # Create tabs for different dashboard sections
    tab1, tab2, tab3 = st.tabs(["Market Overview", "Protocol Stats", "My Portfolio"])
    
    with tab1:
        render_market_overview()
    
    with tab2:
        render_protocol_stats()
    
    with tab3:
        render_portfolio_view()

def render_market_overview():
    """Render the market overview section"""
    st.subheader("Quantum Market Overview")
    
    # Main market chart
    st.markdown("### Market Quantum State")
    
    # Check if market mapper is initialized
    if 'market_mapper' in st.session_state:
        # Get top assets to display
        assets = ['BTC', 'ETH', 'XRP', 'LINK']
        
        try:
            # Attempt to update market state
            st.session_state.market_mapper.update_market_state(assets)
            
            # Get visualization
            fig = quantum_visualizer.visualize_market_overview(
                st.session_state.market_mapper.quantum_state,
                assets
            )
            
            st.plotly_chart(fig, use_container_width=True)
            
            # Add market predictions
            st.markdown("### Quantum Price Predictions (24h)")
            
            predictions = st.session_state.market_mapper.predict_price_movements(
                assets=assets,
                time_horizon=24
            )
            
            # Create prediction dataframe
            if predictions:
                pred_data = []
                for asset, pred in predictions.items():
                    pred_data.append({
                        'Asset': asset,
                        'Direction': "Up" if pred['direction'] > 0 else "Down",
                        'Expected Change': f"{pred['expected_return']:.2f}%",
                        'Confidence': f"{pred['confidence']*100:.1f}%",
                        'Signal': "Strong Buy" if pred['expected_return'] > 3 else
                                "Buy" if pred['expected_return'] > 1 else
                                "Strong Sell" if pred['expected_return'] < -3 else
                                "Sell" if pred['expected_return'] < -1 else "Hold"
                    })
                
                pred_df = pd.DataFrame(pred_data)
                st.dataframe(pred_df, use_container_width=True)
            
        except Exception as e:
            st.error(f"Error rendering market overview: {str(e)}")
            
            # Fallback to simulated data
            fig = go.Figure()
            fig.add_trace(go.Scatter(
                x=pd.date_range(start=datetime.now()-timedelta(days=30), end=datetime.now(), freq='D'),
                y=np.cumsum(np.random.normal(0, 1, 31)),
                mode='lines',
                name='Market Index'
            ))
            fig.update_layout(title="Simulated Market Data (Fallback)")
            st.plotly_chart(fig, use_container_width=True)
    else:
        # Fallback if market mapper not initialized
        st.info("Market data is being initialized...")
        
        # Show a placeholder chart
        dates = pd.date_range(start=datetime.now()-timedelta(days=30), end=datetime.now(), freq='D')
        values = np.cumsum(np.random.normal(0, 1, 31))
        
        fig = px.line(
            x=dates, 
            y=values,
            labels={'x': 'Date', 'y': 'Value'},
            title='Market Overview (Loading...)'
        )
        st.plotly_chart(fig, use_container_width=True)
    
    # Recent opportunities
    st.markdown("### Recent Opportunities")
    
    # Combine flash swap and arbitrage opportunities
    all_opportunities = []
    
    if 'flash_opportunities' in st.session_state and st.session_state.flash_opportunities:
        for opp in st.session_state.flash_opportunities[:3]:  # Take top 3
            all_opportunities.append({
                'Type': 'Flash Swap',
                'Description': f"{opp['base_token']}/{opp['quote_token']} via {' → '.join(opp['path'])}",
                'Profit': f"{opp['profit_percentage']:.2f}%",
                'Required Capital': format_currency(opp['required_capital']),
                'Expected Profit': format_currency(opp['expected_profit_usd']),
                'Timestamp': datetime.fromtimestamp(opp['execution_time']).strftime('%H:%M:%S')
            })
    
    if 'arbitrage_opportunities' in st.session_state and st.session_state.arbitrage_opportunities:
        for opp in st.session_state.arbitrage_opportunities[:3]:  # Take top 3
            all_opportunities.append({
                'Type': 'Arbitrage',
                'Description': f"{opp['trading_pair']} via {' → '.join(opp['path'])}",
                'Profit': f"{opp['profit_percentage']:.2f}%",
                'Required Capital': format_currency(random.uniform(1000, 5000)),
                'Expected Profit': format_currency(random.uniform(10, 100)),
                'Timestamp': datetime.fromtimestamp(opp['execution_time']).strftime('%H:%M:%S')
            })
    
    # Add some leveraged opportunities if needed to make at least 3 total
    while len(all_opportunities) < 3:
        all_opportunities.append({
            'Type': 'Leverage',
            'Description': f"{random.choice(['BTC', 'ETH', 'LINK'])} {random.choice(['Long', 'Short'])} Position",
            'Profit': f"{random.uniform(1, 5):.2f}%",
            'Required Capital': format_currency(random.uniform(500, 2000)),
            'Expected Profit': format_currency(random.uniform(10, 50)),
            'Timestamp': (datetime.now() - timedelta(minutes=random.randint(5, 60))).strftime('%H:%M:%S')
        })
    
    # Display opportunities
    if all_opportunities:
        opportunities_df = pd.DataFrame(all_opportunities)
        st.dataframe(opportunities_df, use_container_width=True)
    else:
        st.info("No recent opportunities detected. Try scanning for opportunities in the Flash Swap or Arbitrage sections.")

def render_protocol_stats():
    """Render protocol statistics section"""
    st.subheader("Protocol Statistics")
    
    # Create two columns
    col1, col2 = st.columns(2)
    
    with col1:
        # Flash swap stats
        st.markdown("### Flash Swap Performance")
        
        # Generate sample data if needed
        dates = pd.date_range(start=datetime.now()-timedelta(days=30), end=datetime.now(), freq='D')
        cumulative_profit = np.cumsum(np.random.uniform(0.1, 0.5, len(dates)))
        success_rate = [min(1.0, 0.7 + 0.01 * i + random.uniform(-0.05, 0.05)) for i in range(len(dates))]
        
        # Create figure with dual y-axis
        fig = go.Figure()
        
        # Add cumulative profit trace
        fig.add_trace(
            go.Scatter(
                x=dates,
                y=cumulative_profit,
                name="Cumulative Profit (ETH)",
                line=dict(color='#6B46C1', width=2)
            )
        )
        
        # Add success rate trace
        fig.add_trace(
            go.Scatter(
                x=dates,
                y=success_rate,
                name="Success Rate",
                line=dict(color='#38A169', width=2, dash='dot'),
                yaxis="y2"
            )
        )
        
        # Set layout with dual y-axis
        fig.update_layout(
            title_text="Flash Swap Performance",
            legend=dict(
                orientation="h",
                yanchor="bottom",
                y=1.02,
                xanchor="right",
                x=1
            ),
            yaxis=dict(
                title="Cumulative Profit (ETH)",
                titlefont=dict(color="#6B46C1"),
                tickfont=dict(color="#6B46C1")
            ),
            yaxis2=dict(
                title="Success Rate",
                titlefont=dict(color="#38A169"),
                tickfont=dict(color="#38A169"),
                anchor="x",
                overlaying="y",
                side="right",
                range=[0, 1]
            )
        )
        
        st.plotly_chart(fig, use_container_width=True)
    
    with col2:
        # Arbitrage stats
        st.markdown("### Arbitrage Performance")
        
        # Generate sample data
        dates = pd.date_range(start=datetime.now()-timedelta(days=30), end=datetime.now(), freq='D')
        
        # Generate different arbitrage types
        types = ['Triangular', 'Cross-DEX', 'Cross-Chain']
        colors = ['#6B46C1', '#3182CE', '#E53E3E']
        
        # Create data for each type
        data = {}
        for t, color in zip(types, colors):
            data[t] = [random.uniform(0.05, 0.3) for _ in range(len(dates))]
        
        # Create stacked bar chart
        fig = go.Figure()
        
        for t, color in zip(types, colors):
            fig.add_trace(
                go.Bar(
                    x=dates,
                    y=data[t],
                    name=f"{t} Arbitrage",
                    marker_color=color
                )
            )
        
        # Set layout
        fig.update_layout(
            title_text="Arbitrage Profit by Type",
            legend=dict(
                orientation="h",
                yanchor="bottom",
                y=1.02,
                xanchor="right",
                x=1
            ),
            yaxis=dict(
                title="Average Profit %"
            ),
            barmode='stack'
        )
        
        st.plotly_chart(fig, use_container_width=True)
    
    # Protocol health metrics
    st.markdown("### Protocol Health")
    
    col1, col2, col3 = st.columns(3)
    
    # TVL growth chart
    with col1:
        # Generate sample data
        dates = pd.date_range(start=datetime.now()-timedelta(days=90), end=datetime.now(), freq='D')
        tvl = 1000000 + np.cumsum(np.random.normal(10000, 5000, len(dates)))
        
        # Create figure
        fig = go.Figure()
        
        fig.add_trace(
            go.Scatter(
                x=dates,
                y=tvl,
                name="TVL",
                fill='tozeroy',
                line=dict(color='#6B46C1', width=2)
            )
        )
        
        # Set layout
        fig.update_layout(
            title_text="Total Value Locked (90 days)",
            yaxis=dict(
                title="TVL (USD)"
            )
        )
        
        st.plotly_chart(fig, use_container_width=True)
    
    # User growth chart
    with col2:
        # Generate sample data
        dates = pd.date_range(start=datetime.now()-timedelta(days=90), end=datetime.now(), freq='D')
        users = 100 + np.cumsum(np.random.normal(5, 2, len(dates)))
        
        # Create figure
        fig = go.Figure()
        
        fig.add_trace(
            go.Scatter(
                x=dates,
                y=users,
                name="Users",
                fill='tozeroy',
                line=dict(color='#3182CE', width=2)
            )
        )
        
        # Set layout
        fig.update_layout(
            title_text="User Growth (90 days)",
            yaxis=dict(
                title="Total Users"
            )
        )
        
        st.plotly_chart(fig, use_container_width=True)
    
    # Transaction volume
    with col3:
        # Generate sample data
        dates = pd.date_range(start=datetime.now()-timedelta(days=90), end=datetime.now(), freq='D')
        volume = np.random.uniform(100000, 500000, len(dates))
        
        # Create figure
        fig = go.Figure()
        
        fig.add_trace(
            go.Bar(
                x=dates,
                y=volume,
                name="Volume",
                marker_color='#38A169'
            )
        )
        
        # Set layout
        fig.update_layout(
            title_text="Daily Transaction Volume (90 days)",
            yaxis=dict(
                title="Volume (USD)"
            )
        )
        
        st.plotly_chart(fig, use_container_width=True)

def render_portfolio_view():
    """Render user portfolio view"""
    
    if not st.session_state.connected:
        st.warning("Please connect your wallet to view your portfolio.")
        return
    
    st.subheader("My Portfolio")
    
    # Portfolio summary metrics
    col1, col2, col3, col4 = st.columns(4)
    
    # Total portfolio value
    portfolio_value = random.uniform(5000, 20000)
    col1.metric("Portfolio Value", format_currency(portfolio_value), f"{random.uniform(-5, 15):.2f}%")
    
    # Open positions
    open_positions = random.randint(1, 5)
    col2.metric("Open Positions", f"{open_positions}")
    
    # P&L
    pnl = random.uniform(-1000, 3000)
    pnl_percentage = (pnl / portfolio_value) * 100
    col3.metric("P&L", format_currency(pnl), f"{pnl_percentage:.2f}%", delta_color="normal" if pnl >= 0 else "inverse")
    
    # ROI
    roi = random.uniform(-10, 30)
    col4.metric("ROI", f"{roi:.2f}%", delta_color="normal" if roi >= 0 else "inverse")
    
    # Portfolio allocation chart
    st.markdown("### Portfolio Allocation")
    
    # Generate sample portfolio data
    assets = ['ETH', 'BTC', 'USDC', 'LINK', 'UNI', 'AAVE']
    allocations = [random.uniform(0.1, 0.3) for _ in range(len(assets))]
    allocations = [a / sum(allocations) for a in allocations]  # Normalize
    
    # Create pie chart
    fig = go.Figure(
        go.Pie(
            labels=assets,
            values=allocations,
            hole=0.4,
            marker=dict(
                colors=['#3182CE', '#F6AD55', '#38A169', '#6B46C1', '#E53E3E', '#805AD5']
            )
        )
    )
    
    fig.update_layout(
        title_text="Asset Allocation"
    )
    
    st.plotly_chart(fig, use_container_width=True)
    
    # Portfolio performance chart
    st.markdown("### Portfolio Performance")
    
    # Generate sample performance data
    dates = pd.date_range(start=datetime.now()-timedelta(days=90), end=datetime.now(), freq='D')
    
    # Create baseline (e.g., market average)
    market = 1000 + np.cumsum(np.random.normal(1, 10, len(dates)))
    
    # Create portfolio performance (slightly better than market)
    portfolio = 1000 + np.cumsum(np.random.normal(2, 10, len(dates)))
    
    # Normalize both to percentage change
    market_pct = [(x / market[0] - 1) * 100 for x in market]
    portfolio_pct = [(x / portfolio[0] - 1) * 100 for x in portfolio]
    
    # Create figure
    fig = go.Figure()
    
    fig.add_trace(
        go.Scatter(
            x=dates,
            y=portfolio_pct,
            name="Your Portfolio",
            line=dict(color='#6B46C1', width=2)
        )
    )
    
    fig.add_trace(
        go.Scatter(
            x=dates,
            y=market_pct,
            name="Market Average",
            line=dict(color='#3182CE', width=2, dash='dot')
        )
    )
    
    # Set layout
    fig.update_layout(
        title_text="Portfolio Performance (90 days)",
        xaxis_title="Date",
        yaxis_title="Performance (%)",
        legend=dict(
            orientation="h",
            yanchor="bottom",
            y=1.02,
            xanchor="right",
            x=1
        )
    )
    
    st.plotly_chart(fig, use_container_width=True)
    
    # Recent transactions
    st.markdown("### Recent Transactions")
    
    # Generate sample transaction data
    num_transactions = random.randint(5, 10)
    transactions = []
    
    for _ in range(num_transactions):
        tx_type = random.choice(['Swap', 'Flash Swap', 'Leverage Open', 'Leverage Close', 'Deposit', 'Withdraw'])
        asset1 = random.choice(assets)
        asset2 = random.choice([a for a in assets if a != asset1]) if tx_type == 'Swap' else ''
        
        amount = random.uniform(0.1, 2) if asset1 in ['ETH', 'BTC'] else random.uniform(10, 1000)
        
        if tx_type == 'Swap':
            description = f"Swap {amount:.4f} {asset1} for {asset2}"
        elif tx_type == 'Flash Swap':
            description = f"Flash Swap via {random.choice(['Uniswap', 'Sushiswap', 'Curve'])}"
        elif tx_type == 'Leverage Open':
            description = f"Open {random.choice(['Long', 'Short'])} {asset1} position"
        elif tx_type == 'Leverage Close':
            description = f"Close {random.choice(['Long', 'Short'])} {asset1} position"
        elif tx_type == 'Deposit':
            description = f"Deposit {amount:.4f} {asset1}"
        else:  # Withdraw
            description = f"Withdraw {amount:.4f} {asset1}"
        
        tx_hash = "0x" + ''.join(random.choice("0123456789abcdef") for _ in range(16)) + "..."
        timestamp = datetime.now() - timedelta(minutes=random.randint(5, 60*24*7))
        value = random.uniform(10, 1000) if tx_type != 'Flash Swap' else random.uniform(100, 5000)
        
        transactions.append({
            'Type': tx_type,
            'Description': description,
            'Value': format_currency(value),
            'Timestamp': timestamp.strftime('%Y-%m-%d %H:%M'),
            'Tx Hash': tx_hash
        })
    
    # Sort by timestamp (most recent first)
    transactions.sort(key=lambda x: datetime.strptime(x['Timestamp'], '%Y-%m-%d %H:%M'), reverse=True)
    
    # Display transactions
    transactions_df = pd.DataFrame(transactions)
    st.dataframe(transactions_df, use_container_width=True)

def format_currency(amount):
    """Format a number as currency"""
    if amount >= 1000000:
        return f"${amount/1000000:.2f}M"
    elif amount >= 1000:
        return f"${amount/1000:.2f}K"
    else:
        return f"${amount:.2f}"
