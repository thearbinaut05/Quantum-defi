import numpy as np
import pandas as pd
import time
import random
from datetime import datetime
import streamlit as st
import traceback

# Import project modules
import utils
from utils import ethereum_utils

class FlashSwapDetector:
    """
    Detects flash swap opportunities across multiple DEXes
    and executes profitable flash loans for arbitrage
    """
    
    def __init__(self, dexes, tokens, min_profit_threshold=0.1):
        """
        Initialize the flash swap detector
        
        Args:
            dexes: List of DEXes to check
            tokens: List of tokens to monitor
            min_profit_threshold: Minimum profit percentage to consider
        """
        self.dexes = dexes
        self.tokens = tokens
        self.min_profit_threshold = min_profit_threshold
        
        # Track opportunities
        self.opportunities = []
        self.executed_swaps = []
        
        # Last scan time
        self.last_scan = None
        
        # Performance metrics
        self.success_rate = 0
        self.average_profit = 0
        self.total_profit = 0
        
        # Opportunity history
        self.opportunity_history = []
    
    def find_opportunities(self):
        """
        Scan for flash swap opportunities
        
        Returns:
            List of detected opportunities
        """
        opportunities = []
        
        # Record scan time
        self.last_scan = datetime.now()
        
        # For demonstration purposes, this is a simulated scan
        # In a real implementation, this would connect to DEXes and check prices
        
        # Generate some simulated opportunities
        for _ in range(random.randint(0, 3)):
            # Choose random tokens
            base_token = random.choice(self.tokens)
            quote_token = random.choice([t for t in self.tokens if t != base_token])
            
            # Select random DEXes for the path (at least 2)
            path_dexes = random.sample(self.dexes, min(len(self.dexes), random.randint(2, len(self.dexes))))
            
            # Create the path
            path = []
            for dex in path_dexes:
                path.append(dex)
            
            # Connect the loop
            path.append(path[0])
            
            # Generate a random profit percentage (sometimes below threshold)
            profit_percentage = max(0, np.random.normal(0.2, 0.3))
            
            # Only include if above threshold
            if profit_percentage >= self.min_profit_threshold:
                # Calculate required capital and expected profit
                required_capital = random.uniform(1000, 10000)
                expected_profit_usd = required_capital * profit_percentage / 100
                
                # Estimate gas cost (simple estimate)
                estimated_gas_cost = 0.005 * len(path) * random.uniform(0.8, 1.2)
                
                # Calculate net profit
                net_profit_usd = expected_profit_usd - estimated_gas_cost
                
                # Only include if actually profitable
                if net_profit_usd > 0:
                    opportunity = {
                        'path': path,
                        'base_token': base_token,
                        'quote_token': quote_token,
                        'profit_percentage': profit_percentage,
                        'required_capital': required_capital,
                        'expected_profit_usd': expected_profit_usd,
                        'estimated_gas_cost': estimated_gas_cost,
                        'net_profit_usd': net_profit_usd,
                        'execution_time': time.time()
                    }
                    
                    opportunities.append(opportunity)
        
        # Add to opportunity history
        if opportunities:
            self.opportunity_history.extend(opportunities)
            
            # Keep history limited
            if len(self.opportunity_history) > 100:
                self.opportunity_history = self.opportunity_history[-100:]
        
        # Store current opportunities
        self.opportunities = opportunities
        
        return opportunities
    
    def execute_flash_swap(self, opportunity, wallet_address):
        """
        Execute a flash swap based on a detected opportunity
        
        Args:
            opportunity: Dictionary describing the opportunity
            wallet_address: Address of the wallet executing the swap
            
        Returns:
            Result of the execution
        """
        # In a real implementation, this would submit the transaction to the network
        # For demonstration, we'll simulate success with occasional failures
        
        success = random.random() < 0.9  # 90% success rate
        
        if success:
            # Simulate execution time
            time.sleep(1)
            
            # Generate a fake transaction hash
            tx_hash = "0x" + "".join(random.choice("0123456789abcdef") for _ in range(64))
            
            # Calculate actual profit (slightly different from expected)
            actual_profit_usd = opportunity['expected_profit_usd'] * random.uniform(0.8, 1.1)
            actual_profit_percentage = opportunity['profit_percentage'] * random.uniform(0.8, 1.1)
            
            # Record execution
            execution_record = {
                'opportunity': opportunity,
                'wallet_address': wallet_address,
                'tx_hash': tx_hash,
                'status': 'success',
                'actual_profit_usd': actual_profit_usd,
                'actual_profit_percentage': actual_profit_percentage,
                'execution_time': datetime.now()
            }
            
            # Update performance metrics
            self.executed_swaps.append(execution_record)
            self.success_rate = sum(1 for swap in self.executed_swaps if swap['status'] == 'success') / len(self.executed_swaps)
            self.total_profit += actual_profit_usd
            self.average_profit = self.total_profit / len(self.executed_swaps)
            
            return {
                'success': True,
                'tx_hash': tx_hash,
                'actual_profit_usd': actual_profit_usd,
                'actual_profit_percentage': actual_profit_percentage
            }
        else:
            # Simulate execution failure
            time.sleep(1)
            
            # Record failure
            failure_record = {
                'opportunity': opportunity,
                'wallet_address': wallet_address,
                'status': 'failed',
                'error': 'Transaction reverted due to price movement',
                'execution_time': datetime.now()
            }
            
            # Update performance metrics
            self.executed_swaps.append(failure_record)
            self.success_rate = sum(1 for swap in self.executed_swaps if swap['status'] == 'success') / len(self.executed_swaps)
            
            return {
                'success': False,
                'error': 'Transaction reverted due to price movement'
            }
    
    def update_settings(self, tokens=None, dexes=None, min_profit_threshold=None):
        """
        Update detector settings
        
        Args:
            tokens: List of tokens to monitor
            dexes: List of DEXes to check
            min_profit_threshold: Minimum profit percentage threshold
        """
        if tokens is not None:
            self.tokens = tokens
        
        if dexes is not None:
            self.dexes = dexes
        
        if min_profit_threshold is not None:
            self.min_profit_threshold = min_profit_threshold
    
    def get_historical_performance(self):
        """
        Get historical performance data for flash swaps
        
        Returns:
            List of performance data points
        """
        if not self.executed_swaps:
            return []
        
        # Extract relevant metrics
        performance_data = []
        
        for swap in self.executed_swaps:
            if swap['status'] == 'success':
                data_point = {
                    'timestamp': swap['execution_time'],
                    'profit_percentage': swap['actual_profit_percentage'],
                    'profit_usd': swap['actual_profit_usd'],
                    'path': ' → '.join(swap['opportunity']['path'])
                }
                performance_data.append(data_point)
        
        return performance_data
    
    def get_execution_stats(self):
        """
        Get execution statistics
        
        Returns:
            Dictionary of execution statistics
        """
        if not self.executed_swaps:
            return {
                'total_executions': 0,
                'success_rate': 0,
                'total_profit_usd': 0,
                'average_profit_usd': 0,
                'highest_profit_usd': 0
            }
        
        total_executions = len(self.executed_swaps)
        successful_executions = sum(1 for swap in self.executed_swaps if swap['status'] == 'success')
        success_rate = successful_executions / total_executions if total_executions > 0 else 0
        
        profits = [swap['actual_profit_usd'] for swap in self.executed_swaps if swap['status'] == 'success']
        total_profit_usd = sum(profits)
        average_profit_usd = total_profit_usd / successful_executions if successful_executions > 0 else 0
        highest_profit_usd = max(profits) if profits else 0
        
        return {
            'total_executions': total_executions,
            'success_rate': success_rate,
            'total_profit_usd': total_profit_usd,
            'average_profit_usd': average_profit_usd,
            'highest_profit_usd': highest_profit_usd
        }
