"""
Leverage Position Manager

This module provides functionality for managing leveraged trading positions
with risk management and position optimization based on quantum market insights.
"""

import numpy as np
import pandas as pd
import time
from datetime import datetime
import random
import streamlit as st

# Import custom modules
import quantum_market_model as qmm

# Constants
MAX_LEVERAGE = 10
LIQUIDATION_THRESHOLD = 1.1  # Position gets liquidated at 110% collateralization
DEFAULT_STOP_LOSS = 0.05  # 5% default stop loss
DEFAULT_TAKE_PROFIT = 0.1  # 10% default take profit

class LeveragePositionManager:
    """
    Manages leveraged positions with risk management.
    """
    
    def __init__(self, initial_capital=10000):
        """
        Initialize the leverage position manager.
        
        Args:
            initial_capital: Initial capital in USD
        """
        self.initial_capital = initial_capital
        self.positions = []
        self.position_history = []
        self.capital = initial_capital
        self.next_position_id = 1
    
    def open_position(self, asset, side, size_usd, leverage, entry_price, 
                      stop_loss_pct=DEFAULT_STOP_LOSS, take_profit_pct=DEFAULT_TAKE_PROFIT):
        """
        Open a new leveraged position.
        
        Args:
            asset: Asset symbol
            side: "long" or "short"
            size_usd: Position size in USD (before leverage)
            leverage: Leverage factor
            entry_price: Entry price
            stop_loss_pct: Stop loss percentage
            take_profit_pct: Take profit percentage
            
        Returns:
            New position object
        """
        # Validate inputs
        leverage = max(1, min(MAX_LEVERAGE, leverage))
        
        # Check if we have enough capital
        if size_usd > self.capital:
            size_usd = self.capital  # Limit to available capital
        
        # Calculate position details
        position_size_with_leverage = size_usd * leverage
        liquidation_price = self._calculate_liquidation_price(
            entry_price, leverage, side)
        
        # Calculate stop loss and take profit prices
        if side == "long":
            stop_loss_price = entry_price * (1 - stop_loss_pct)
            take_profit_price = entry_price * (1 + take_profit_pct)
        else:
            stop_loss_price = entry_price * (1 + stop_loss_pct)
            take_profit_price = entry_price * (1 - take_profit_pct)
        
        # Create position object
        position = {
            "id": self.next_position_id,
            "asset": asset,
            "side": side,
            "size_usd": size_usd,
            "leverage": leverage,
            "position_size": position_size_with_leverage,
            "entry_price": entry_price,
            "current_price": entry_price,
            "liquidation_price": liquidation_price,
            "stop_loss_price": stop_loss_price,
            "take_profit_price": take_profit_price,
            "stop_loss_pct": stop_loss_pct,
            "take_profit_pct": take_profit_pct,
            "unrealized_pnl": 0,
            "unrealized_pnl_pct": 0,
            "status": "open",
            "health": 100,  # Position health (100 = perfect, 0 = liquidated)
            "open_time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "close_time": None,
            "duration": 0,
            "quantum_adjusted_risk": self._calculate_quantum_risk(asset, side, leverage)
        }
        
        # Update state
        self.next_position_id += 1
        self.positions.append(position)
        self.capital -= size_usd
        
        return position
    
    def close_position(self, position_id):
        """
        Close a position by ID.
        
        Args:
            position_id: Position ID to close
            
        Returns:
            Closed position details if successful, None otherwise
        """
        position = self._get_position_by_id(position_id)
        
        if not position or position["status"] != "open":
            return None
        
        # Get current price
        current_price = self._get_current_price(position["asset"])
        
        # Update position with final details
        position["current_price"] = current_price
        position["close_price"] = current_price
        
        # Calculate PnL
        self._update_position_pnl(position)
        
        # Update position status
        position["status"] = "closed"
        position["close_time"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        position["duration"] = self._calculate_duration(position)
        
        # Add to history
        self.position_history.append(position.copy())
        
        # Return capital + profit
        realized_pnl = position["unrealized_pnl"]
        self.capital += position["size_usd"] + realized_pnl
        
        # Remove from active positions
        self.positions = [p for p in self.positions if p["id"] != position_id]
        
        return position
    
    def update_positions(self):
        """
        Update all open positions with current prices and check for liquidations,
        stop losses, and take profits.
        
        Returns:
            List of updated positions
        """
        for position in self.positions:
            if position["status"] != "open":
                continue
            
            # Get current price
            current_price = self._get_current_price(position["asset"])
            position["current_price"] = current_price
            
            # Update PnL
            self._update_position_pnl(position)
            
            # Check for liquidation, stop loss, or take profit
            if self._check_liquidation(position):
                self._liquidate_position(position)
            elif self._check_stop_loss(position):
                self._close_position_with_reason(position, "stop_loss")
            elif self._check_take_profit(position):
                self._close_position_with_reason(position, "take_profit")
            
            # Update position health
            self._update_position_health(position)
        
        return self.positions
    
    def get_all_positions(self):
        """
        Get all active positions.
        
        Returns:
            List of positions
        """
        return self.positions
    
    def get_position_history(self):
        """
        Get history of closed positions.
        
        Returns:
            List of historical positions
        """
        return self.position_history
    
    def update_stop_loss(self, position_id, new_stop_loss_pct):
        """
        Update the stop loss for a position.
        
        Args:
            position_id: Position ID
            new_stop_loss_pct: New stop loss percentage
            
        Returns:
            Updated position if successful, None otherwise
        """
        position = self._get_position_by_id(position_id)
        
        if not position or position["status"] != "open":
            return None
        
        # Update stop loss percentage
        position["stop_loss_pct"] = new_stop_loss_pct
        
        # Recalculate stop loss price
        if position["side"] == "long":
            position["stop_loss_price"] = position["entry_price"] * (1 - new_stop_loss_pct)
        else:
            position["stop_loss_price"] = position["entry_price"] * (1 + new_stop_loss_pct)
        
        return position
    
    def update_take_profit(self, position_id, new_take_profit_pct):
        """
        Update the take profit for a position.
        
        Args:
            position_id: Position ID
            new_take_profit_pct: New take profit percentage
            
        Returns:
            Updated position if successful, None otherwise
        """
        position = self._get_position_by_id(position_id)
        
        if not position or position["status"] != "open":
            return None
        
        # Update take profit percentage
        position["take_profit_pct"] = new_take_profit_pct
        
        # Recalculate take profit price
        if position["side"] == "long":
            position["take_profit_price"] = position["entry_price"] * (1 + new_take_profit_pct)
        else:
            position["take_profit_price"] = position["entry_price"] * (1 - new_take_profit_pct)
        
        return position
    
    def get_portfolio_metrics(self):
        """
        Calculate portfolio metrics.
        
        Returns:
            Dictionary of portfolio metrics
        """
        total_position_value = sum([p["position_size"] for p in self.positions])
        total_margin_used = sum([p["size_usd"] for p in self.positions])
        unrealized_pnl = sum([p["unrealized_pnl"] for p in self.positions])
        
        # Calculate average leverage
        avg_leverage = 0
        if self.positions:
            avg_leverage = sum([p["leverage"] for p in self.positions]) / len(self.positions)
        
        # Calculate portfolio risk score
        risk_score = self._calculate_portfolio_risk_score()
        
        # Total value
        total_value = self.capital + total_margin_used + unrealized_pnl
        
        return {
            "capital": self.capital,
            "total_position_value": total_position_value,
            "total_margin_used": total_margin_used,
            "unrealized_pnl": unrealized_pnl,
            "avg_leverage": avg_leverage,
            "risk_score": risk_score,
            "total_value": total_value,
            "return_pct": (total_value / self.initial_capital - 1) * 100
        }
    
    def get_portfolio_assets(self):
        """
        Get list of assets in the portfolio.
        
        Returns:
            List of assets with details
        """
        assets = {}
        
        for position in self.positions:
            asset = position["asset"]
            
            if asset not in assets:
                # Get current price
                current_price = self._get_current_price(asset)
                
                # Get daily change
                daily_change_pct = random.uniform(-5, 5)  # Placeholder
                
                # Initialize asset data
                assets[asset] = {
                    "asset": asset,
                    "positions": 0,
                    "total_size_usd": 0,
                    "avg_leverage": 0,
                    "total_exposure": 0,
                    "unrealized_pnl": 0,
                    "current_price": current_price,
                    "daily_change_pct": daily_change_pct,
                    "sharpe_ratio": random.uniform(0.5, 3)  # Placeholder
                }
            
            # Update asset data
            assets[asset]["positions"] += 1
            assets[asset]["total_size_usd"] += position["size_usd"]
            assets[asset]["total_exposure"] += position["position_size"]
            assets[asset]["unrealized_pnl"] += position["unrealized_pnl"]
        
        # Calculate average leverage
        for asset in assets.values():
            if asset["total_size_usd"] > 0:
                asset["avg_leverage"] = asset["total_exposure"] / asset["total_size_usd"]
        
        return list(assets.values())
    
    def _get_position_by_id(self, position_id):
        """
        Get a position by ID.
        
        Args:
            position_id: Position ID
            
        Returns:
            Position object if found, None otherwise
        """
        for position in self.positions:
            if position["id"] == position_id:
                return position
        return None
    
    def _get_current_price(self, asset):
        """
        Get current price for an asset.
        
        Args:
            asset: Asset symbol
            
        Returns:
            Current price
        """
        # In a real implementation, this would fetch actual price data
        # Use quantum model if available, otherwise generate a placeholder
        if hasattr(qmm, 'get_asset_price'):
            return qmm.get_asset_price(asset)
        
        # Placeholder base prices
        base_prices = {
            "BTC": 50000,
            "ETH": 3000,
            "LINK": 15,
            "SOL": 80,
            "AVAX": 30,
            "UNI": 10,
            "AAVE": 100
        }
        
        # Get base price or generate random one
        base_price = base_prices.get(asset, 50)
        
        # Add noise to simulate price movement
        return base_price * (1 + random.uniform(-0.01, 0.01))
    
    def _calculate_liquidation_price(self, entry_price, leverage, side):
        """
        Calculate liquidation price for a position.
        
        Args:
            entry_price: Entry price
            leverage: Leverage factor
            side: "long" or "short"
            
        Returns:
            Liquidation price
        """
        # Calculate price movement percentage that would trigger liquidation
        # Liquidation occurs when equity becomes zero, which happens when price moves 
        # against position by 1/leverage of the entry price, adjusted by liquidation threshold
        liquidation_pct = (1 / leverage) * LIQUIDATION_THRESHOLD
        
        if side == "long":
            # For long positions, liquidation happens on price decrease
            return entry_price * (1 - liquidation_pct)
        else:
            # For short positions, liquidation happens on price increase
            return entry_price * (1 + liquidation_pct)
    
    def _update_position_pnl(self, position):
        """
        Update PnL calculations for a position.
        
        Args:
            position: Position object to update
        """
        entry_price = position["entry_price"]
        current_price = position["current_price"]
        size_usd = position["size_usd"]
        leverage = position["leverage"]
        
        if position["side"] == "long":
            # For long positions, profit when price increases
            pnl_pct = (current_price / entry_price - 1) * 100 * leverage
            pnl_usd = size_usd * pnl_pct / 100
        else:
            # For short positions, profit when price decreases
            pnl_pct = (entry_price / current_price - 1) * 100 * leverage
            pnl_usd = size_usd * pnl_pct / 100
        
        position["unrealized_pnl"] = pnl_usd
        position["unrealized_pnl_pct"] = pnl_pct
    
    def _check_liquidation(self, position):
        """
        Check if a position should be liquidated.
        
        Args:
            position: Position to check
            
        Returns:
            True if liquidation should occur, False otherwise
        """
        side = position["side"]
        current_price = position["current_price"]
        liquidation_price = position["liquidation_price"]
        
        if side == "long":
            return current_price <= liquidation_price
        else:
            return current_price >= liquidation_price
    
    def _check_stop_loss(self, position):
        """
        Check if a position hit stop loss.
        
        Args:
            position: Position to check
            
        Returns:
            True if stop loss hit, False otherwise
        """
        side = position["side"]
        current_price = position["current_price"]
        stop_loss_price = position["stop_loss_price"]
        
        if side == "long":
            return current_price <= stop_loss_price
        else:
            return current_price >= stop_loss_price
    
    def _check_take_profit(self, position):
        """
        Check if a position hit take profit.
        
        Args:
            position: Position to check
            
        Returns:
            True if take profit hit, False otherwise
        """
        side = position["side"]
        current_price = position["current_price"]
        take_profit_price = position["take_profit_price"]
        
        if side == "long":
            return current_price >= take_profit_price
        else:
            return current_price <= take_profit_price
    
    def _liquidate_position(self, position):
        """
        Liquidate a position.
        
        Args:
            position: Position to liquidate
        """
        position["status"] = "liquidated"
        position["close_time"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        position["duration"] = self._calculate_duration(position)
        position["health"] = 0
        
        # In liquidation, we lose all the margin
        position["unrealized_pnl"] = -position["size_usd"]
        position["unrealized_pnl_pct"] = -100
        
        # Add to history
        self.position_history.append(position.copy())
        
        # Remove from active positions
        self.positions = [p for p in self.positions if p["id"] != position["id"]]
    
    def _close_position_with_reason(self, position, reason):
        """
        Close a position with a specific reason.
        
        Args:
            position: Position to close
            reason: Reason for closing (stop_loss, take_profit)
        """
        position["status"] = "closed"
        position["close_reason"] = reason
        position["close_time"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        position["duration"] = self._calculate_duration(position)
        
        # Calculate final PnL
        self._update_position_pnl(position)
        
        # Add to history
        self.position_history.append(position.copy())
        
        # Return capital + profit
        realized_pnl = position["unrealized_pnl"]
        self.capital += position["size_usd"] + realized_pnl
        
        # Remove from active positions
        self.positions = [p for p in self.positions if p["id"] != position["id"]]
    
    def _calculate_duration(self, position):
        """
        Calculate position duration in hours.
        
        Args:
            position: Position to calculate duration for
            
        Returns:
            Duration in hours
        """
        open_time = datetime.strptime(position["open_time"], "%Y-%m-%d %H:%M:%S")
        
        if position["close_time"]:
            close_time = datetime.strptime(position["close_time"], "%Y-%m-%d %H:%M:%S")
        else:
            close_time = datetime.now()
        
        duration_seconds = (close_time - open_time).total_seconds()
        return duration_seconds / 3600  # Convert to hours
    
    def _update_position_health(self, position):
        """
        Update the health metric of a position.
        
        Args:
            position: Position to update
        """
        if position["status"] != "open":
            return
        
        current_price = position["current_price"]
        liquidation_price = position["liquidation_price"]
        entry_price = position["entry_price"]
        
        if position["side"] == "long":
            price_range = entry_price - liquidation_price
            current_buffer = current_price - liquidation_price
        else:
            price_range = liquidation_price - entry_price
            current_buffer = liquidation_price - current_price
        
        # Health as percentage of buffer remaining
        if price_range > 0:
            health = (current_buffer / price_range) * 100
            health = max(0, min(100, health))
        else:
            health = 100
        
        position["health"] = health
    
    def _calculate_quantum_risk(self, asset, side, leverage):
        """
        Calculate quantum-adjusted risk for a position.
        
        Args:
            asset: Asset symbol
            side: Position side
            leverage: Leverage factor
            
        Returns:
            Risk score (0-100)
        """
        # Calculate base risk from leverage
        base_risk = leverage / MAX_LEVERAGE * 100
        
        # Get quantum market data if available
        quantum_assets = qmm.get_quantum_assets() if hasattr(qmm, 'get_quantum_assets') and 'quantum_assets' in st.session_state else {}
        market_state = qmm.get_market_state() if hasattr(qmm, 'get_market_state') and 'market_state' in st.session_state else "Superposition"
        
        # Default adjustment if quantum data not available
        adjustment = 0
        
        if asset in quantum_assets:
            asset_data = quantum_assets[asset]
            
            # Get quantum properties
            uncertainty = asset_data.get("uncertainty", 0.5)
            prob_up = asset_data.get("prob_up", 0.5)
            
            # Calculate risk adjustment based on position alignment with quantum probabilities
            if side == "long":
                # Long positions do better when price likely to go up
                alignment = prob_up
            else:
                # Short positions do better when price likely to go down
                alignment = 1 - prob_up
            
            # Higher alignment = lower risk
            alignment_adjustment = -20 * (alignment - 0.5)
            
            # Higher uncertainty = higher risk
            uncertainty_adjustment = 20 * uncertainty
            
            # Combine adjustments
            adjustment = alignment_adjustment + uncertainty_adjustment
            
            # Market state factor
            if market_state == "Superposition":
                adjustment += 10  # Higher risk in uncertain markets
            elif market_state == "Collapsed":
                adjustment -= 10  # Lower risk in certain markets
            elif market_state == "Quantum Tunneling":
                adjustment += 20  # Highest risk in tunneling markets
        
        # Apply adjustment
        risk_score = base_risk + adjustment
        
        # Ensure risk score is within bounds
        risk_score = max(0, min(100, risk_score))
        
        return risk_score
    
    def _calculate_portfolio_risk_score(self):
        """
        Calculate overall portfolio risk score.
        
        Returns:
            Risk score (0-100)
        """
        if not self.positions:
            return 0
        
        # Calculate weighted average of position risks
        total_size = sum([p["size_usd"] for p in self.positions])
        
        if total_size == 0:
            return 0
        
        weighted_risk = sum([p["quantum_adjusted_risk"] * (p["size_usd"] / total_size) for p in self.positions])
        
        # Add factor for portfolio concentration
        assets = set([p["asset"] for p in self.positions])
        concentration_factor = max(0, 20 - len(assets) * 5)  # More assets = lower risk
        
        # Add factor for capital utilization
        if self.initial_capital > 0:
            capital_utilization = 1 - (self.capital / self.initial_capital)
            utilization_factor = capital_utilization * 20
        else:
            utilization_factor = 0
        
        # Combine factors
        risk_score = weighted_risk + concentration_factor + utilization_factor
        
        # Ensure risk score is within bounds
        risk_score = max(0, min(100, risk_score))
        
        return risk_score

def calculate_optimal_leverage(asset, risk_tolerance):
    """
    Calculate optimal leverage based on asset volatility and risk tolerance.
    
    Args:
        asset: Asset symbol
        risk_tolerance: Risk tolerance (0-1)
        
    Returns:
        Optimal leverage factor
    """
    # Base leverage based on risk tolerance
    base_leverage = risk_tolerance * 5  # 0-5x range
    
    # Get asset volatility
    volatility = get_asset_volatility(asset)
    
    # Adjust leverage based on volatility
    # Higher volatility = lower leverage
    volatility_factor = 1 - (volatility / 0.1)  # Normalize against 10% volatility
    volatility_factor = max(0.2, min(1.5, volatility_factor))
    
    # Get quantum market insight if available
    optimal_quantum_leverage = 1.0
    if hasattr(qmm, 'calculate_optimal_leverage'):
        optimal_quantum_leverage = qmm.calculate_optimal_leverage()
    
    # Combine factors
    optimal_leverage = base_leverage * volatility_factor * optimal_quantum_leverage
    
    # Ensure within bounds
    optimal_leverage = max(1.0, min(MAX_LEVERAGE, optimal_leverage))
    
    return optimal_leverage

def get_asset_volatility(asset):
    """
    Get historical volatility for an asset.
    
    Args:
        asset: Asset symbol
        
    Returns:
        Volatility (standard deviation of daily returns)
    """
    # In a real implementation, this would calculate actual volatility
    # Here we're using placeholder values for demonstration
    
    volatility_map = {
        "BTC": 0.04,  # 4% daily volatility
        "ETH": 0.05,
        "LINK": 0.06,
        "SOL": 0.07,
        "AVAX": 0.06,
        "UNI": 0.08,
        "AAVE": 0.07
    }
    
    return volatility_map.get(asset, 0.05)

def calculate_portfolio_liquidation_risk(positions):
    """
    Calculate overall portfolio liquidation risk.
    
    Args:
        positions: List of positions
        
    Returns:
        Liquidation risk percentage
    """
    if not positions:
        return 0
    
    # Calculate average health across all positions
    avg_health = sum([p.get("health", 100) for p in positions]) / len(positions)
    
    # Convert to risk (100 health = 0% risk, 0 health = 100% risk)
    liquidation_risk = 100 - avg_health
    
    return liquidation_risk
