"""
MEV Protection and Prediction

This module provides protection against Maximal Extractable Value (MEV) attacks
such as front-running, sandwich attacks, and other transaction-ordering exploits.
"""

import numpy as np
import pandas as pd
import random
import time
from datetime import datetime, timedelta
import streamlit as st

# Import custom modules
import wallet_manager as wm
import quantum_market_model as qmm

# Constants
PRIVATE_RELAYERS = ["Flashbots", "Eden Network", "Bloxroute", "MiningDAO"]
PROTECTED_NETWORKS = ["Ethereum", "Arbitrum", "Optimism", "Polygon"]
MEV_TYPE_WEIGHTS = {
    "front_running": 0.4,
    "sandwich_attack": 0.3,
    "back_running": 0.2,
    "liquidation": 0.1
}

def update_protection_settings(enabled, protection_level, use_private_txs, use_slippage, use_timing):
    """
    Update MEV protection settings
    
    Args:
        enabled: Whether MEV protection is enabled
        protection_level: Protection level (Basic, Standard, Advanced, Maximum)
        use_private_txs: Whether to use private transactions
        use_slippage: Whether to use dynamic slippage protection
        use_timing: Whether to use transaction timing optimization
        
    Returns:
        Updated settings
    """
    # Store settings in session state
    st.session_state.mev_protection_active = enabled
    st.session_state.mev_protection_level = protection_level
    st.session_state.mev_use_private_txs = use_private_txs
    st.session_state.mev_use_slippage = use_slippage
    st.session_state.mev_use_timing = use_timing
    
    # Calculate gas prices based on protection level
    gas_multiplier = {
        "Basic": 1.0,
        "Standard": 1.2,
        "Advanced": 1.5,
        "Maximum": 2.0
    }.get(protection_level, 1.0)
    
    # Select relayer based on protection level
    if protection_level == "Basic":
        relayer = None  # No private relayer for basic protection
    elif protection_level == "Standard":
        relayer = random.choice(PRIVATE_RELAYERS[:2])
    elif protection_level == "Advanced":
        relayer = random.choice(PRIVATE_RELAYERS[:3])
    else:  # Maximum
        relayer = random.choice(PRIVATE_RELAYERS)
    
    # Calculate protection efficiency based on settings
    protection_efficiency = 50  # Base value
    
    if use_private_txs:
        protection_efficiency += 25
    
    if use_slippage:
        protection_efficiency += 15
    
    if use_timing:
        protection_efficiency += 10
    
    # Adjust by protection level
    level_bonus = {
        "Basic": 0,
        "Standard": 5,
        "Advanced": 10,
        "Maximum": 15
    }.get(protection_level, 0)
    
    protection_efficiency += level_bonus
    
    # Cap at 95% (never 100% perfect)
    protection_efficiency = min(95, protection_efficiency)
    
    # Store additional calculated values
    st.session_state.mev_gas_multiplier = gas_multiplier
    st.session_state.mev_selected_relayer = relayer
    st.session_state.mev_protection_efficiency = protection_efficiency
    
    return {
        "enabled": enabled,
        "protection_level": protection_level,
        "gas_multiplier": gas_multiplier,
        "selected_relayer": relayer,
        "protection_efficiency": protection_efficiency
    }

def get_recent_mev_activity():
    """
    Get recent MEV activity on the blockchain
    
    Returns:
        List of recent MEV activities
    """
    # In a real implementation, this would query an MEV monitoring API
    # Here we're generating mock data for demonstration
    
    mev_activities = []
    
    # Generate some random MEV activities
    now = datetime.now()
    
    for i in range(10):
        # Random timestamp within the last 24 hours
        timestamp = now - timedelta(hours=random.uniform(0, 24))
        
        # Select random MEV type
        mev_type = random.choices(
            list(MEV_TYPE_WEIGHTS.keys()),
            weights=list(MEV_TYPE_WEIGHTS.values())
        )[0]
        
        # Calculate profit based on type
        if mev_type == "front_running":
            profit = random.uniform(0.01, 0.5)
        elif mev_type == "sandwich_attack":
            profit = random.uniform(0.05, 2.0)
        elif mev_type == "back_running":
            profit = random.uniform(0.01, 0.3)
        else:  # liquidation
            profit = random.uniform(1.0, 10.0)
        
        # Generate random token pair
        tokens = ["ETH", "USDC", "USDT", "DAI", "WBTC", "LINK", "UNI"]
        token1 = random.choice(tokens)
        token2 = random.choice([t for t in tokens if t != token1])
        token_pair = f"{token1}/{token2}"
        
        # Random DEX
        dex = random.choice(["Uniswap V3", "Uniswap V2", "Sushiswap", "Curve", "Balancer"])
        
        # Random tx hash
        tx_hash = "0x" + "".join(random.choices("0123456789abcdef", k=64))
        
        mev_activities.append({
            "timestamp": timestamp.strftime("%Y-%m-%d %H:%M:%S"),
            "type": mev_type,
            "profit_eth": profit,
            "profit_usd": profit * 3000,  # Assuming 1 ETH = $3000
            "token_pair": token_pair,
            "dex": dex,
            "tx_hash": tx_hash,
            "detected": random.choice([True, False]),
            "protected": random.random() < 0.7  # 70% chance of being protected
        })
    
    # Sort by timestamp (most recent first)
    mev_activities = sorted(mev_activities, key=lambda x: x["timestamp"], reverse=True)
    
    return mev_activities

def assess_transaction_risk(tx_type, token_pair, tx_size, urgency):
    """
    Assess MEV risk for a potential transaction
    
    Args:
        tx_type: Type of transaction
        token_pair: Token pair
        tx_size: Transaction size in USD
        urgency: Transaction urgency
        
    Returns:
        Risk assessment
    """
    # Base risk score
    risk_score = 50
    
    # Adjust based on transaction type
    type_risk = {
        "Swap": 50,
        "Add Liquidity": 30,
        "Remove Liquidity": 40,
        "Flash Swap": 70,
        "Cross-chain Swap": 60
    }
    risk_score = type_risk.get(tx_type, risk_score)
    
    # Adjust based on token pair
    tokens = token_pair.split("/")
    
    # Higher risk for popular tokens due to more MEV activity
    popular_tokens = ["ETH", "USDC", "USDT", "WBTC"]
    token_risk_factor = sum([1 for token in tokens if token in popular_tokens]) * 10
    risk_score += token_risk_factor
    
    # Adjust based on transaction size
    # Larger transactions are more profitable for MEV extractors
    size_factor = min(30, tx_size / 5000)  # Max +30 for large transactions
    risk_score += size_factor
    
    # Adjust based on urgency
    # More urgent transactions are more vulnerable
    urgency_factor = {
        "Low": -10,
        "Medium": 0,
        "High": 10,
        "Urgent": 20
    }
    risk_score += urgency_factor.get(urgency, 0)
    
    # Adjust based on current market state if quantum model available
    if hasattr(qmm, 'get_market_state') and 'market_state' in st.session_state:
        market_state = st.session_state.market_state
        
        if market_state == "Superposition":
            risk_score += 5  # Higher risk in uncertain markets
        elif market_state == "Collapsed":
            risk_score -= 5  # Lower risk in certain markets
        elif market_state == "Quantum Tunneling":
            risk_score += 10  # Higher risk in tunneling markets
    
    # Get current network congestion
    congestion = get_network_congestion()
    
    # Adjust based on congestion
    # Higher congestion = higher MEV risk
    congestion_factor = congestion / 2  # 0-100 scale to 0-50 factor
    risk_score += congestion_factor
    
    # Ensure risk score is within bounds
    risk_score = max(0, min(100, risk_score))
    
    # Generate risk factors
    risk_factors = {
        "Transaction Type": f"{type_risk.get(tx_type, 50)}/100",
        "Token Pair Risk": f"{token_risk_factor + 50}/100",
        "Size Factor": f"{int(size_factor + 50)}/100",
        "Network Congestion": f"{congestion}/100"
    }
    
    # Generate recommendations
    recommendations = generate_protection_recommendations(
        risk_score, tx_type, token_pair, tx_size, urgency, congestion)
    
    return {
        "risk_score": int(risk_score),
        "risk_factors": risk_factors,
        "recommendations": recommendations
    }

def get_network_congestion():
    """
    Get current network congestion level
    
    Returns:
        Congestion level (0-100)
    """
    # In a real implementation, this would query gas APIs
    # Here we're generating a random value for demonstration
    
    # Base congestion with daily cycle
    hour_of_day = datetime.now().hour
    
    # Network is typically more congested during business hours
    base_congestion = 40
    if 8 <= hour_of_day <= 20:
        base_congestion = 60
    
    # Add random factor
    congestion = base_congestion + random.uniform(-20, 20)
    
    # Ensure congestion is within bounds
    congestion = max(0, min(100, congestion))
    
    return congestion

def generate_protection_recommendations(risk_score, tx_type, token_pair, tx_size, urgency, congestion):
    """
    Generate recommendations for MEV protection
    
    Args:
        risk_score: Risk score
        tx_type: Transaction type
        token_pair: Token pair
        tx_size: Transaction size
        urgency: Transaction urgency
        congestion: Network congestion
        
    Returns:
        List of recommendations
    """
    recommendations = []
    
    # Base recommendations based on risk score
    if risk_score < 30:
        recommendations.append("Standard gas price should be sufficient for this transaction")
    elif risk_score < 60:
        recommendations.append("Use moderate MEV protection with private transactions")
    else:
        recommendations.append("Use maximum MEV protection with dedicated private relayers")
    
    # Transaction type specific recommendations
    if tx_type == "Swap":
        recommendations.append("Set appropriate slippage tolerance based on pair liquidity")
        
        if risk_score > 50:
            recommendations.append("Consider splitting large swaps into smaller transactions")
    
    elif tx_type == "Add Liquidity" or tx_type == "Remove Liquidity":
        recommendations.append("Monitor pool reserves before submitting to avoid manipulation")
    
    elif tx_type == "Flash Swap":
        recommendations.append("Implement strict minimum output requirements")
        recommendations.append("Use private relayers to avoid front-running")
    
    # Token pair specific recommendations
    if "ETH" in token_pair:
        recommendations.append("ETH pairs face higher MEV activity, consider higher gas price")
    
    if any(token in token_pair for token in ["USDC", "USDT", "DAI"]):
        recommendations.append("Stablecoin pairs are common MEV targets, verify exchange rates carefully")
    
    # Transaction size recommendations
    if tx_size > 10000:
        recommendations.append("Very large transaction - consider using time-weighted average pricing (TWAP)")
        recommendations.append("Split transaction across multiple blocks to reduce MEV exposure")
    
    # Urgency recommendations
    if urgency == "Urgent":
        recommendations.append("For urgent transactions, prioritize MEV protection over gas costs")
    elif urgency == "Low":
        recommendations.append("Consider waiting for lower network congestion to reduce MEV risk and gas costs")
    
    # Congestion-based recommendations
    if congestion > 70:
        recommendations.append("Network is highly congested - MEV risk is elevated")
        recommendations.append("Consider delaying non-urgent transactions")
    
    # Protection-level recommendations
    if risk_score < 30:
        protection_level = "Basic"
    elif risk_score < 60:
        protection_level = "Standard"
    elif risk_score < 80:
        protection_level = "Advanced"
    else:
        protection_level = "Maximum"
    
    recommendations.append(f"Recommended protection level: {protection_level}")
    
    return recommendations

def protect_transaction(tx_data, protection_level="Standard"):
    """
    Apply MEV protection to a transaction
    
    Args:
        tx_data: Transaction data
        protection_level: Protection level
        
    Returns:
        Protected transaction data
    """
    # Get protection settings
    if not st.session_state.get('mev_protection_active', False):
        return tx_data
    
    # Apply various protection techniques based on settings
    protected_tx = tx_data.copy()
    
    # 1. Apply gas price adjustment
    gas_multiplier = st.session_state.get('mev_gas_multiplier', 1.0)
    
    if 'gasPrice' in protected_tx:
        protected_tx['gasPrice'] = int(protected_tx['gasPrice'] * gas_multiplier)
    
    # 2. Add private transaction fields if enabled
    if st.session_state.get('mev_use_private_txs', False):
        relayer = st.session_state.get('mev_selected_relayer')
        
        if relayer:
            protected_tx['privateTransaction'] = True
            protected_tx['relayer'] = relayer
    
    # 3. Adjust slippage if enabled
    if st.session_state.get('mev_use_slippage', False) and 'slippage' in protected_tx:
        # Dynamic slippage based on protection level and network conditions
        congestion = get_network_congestion()
        base_slippage = protected_tx['slippage']
        
        # Adjust slippage based on congestion and protection level
        level_factor = {
            "Basic": 1.0,
            "Standard": 1.5,
            "Advanced": 2.0,
            "Maximum": 2.5
        }.get(protection_level, 1.0)
        
        congestion_factor = 1.0 + (congestion / 200)  # 0-1.5 range
        
        adjusted_slippage = base_slippage * level_factor * congestion_factor
        
        # Cap at 50% to prevent extreme values
        protected_tx['slippage'] = min(50.0, adjusted_slippage)
    
    # 4. Add timing optimization if enabled
    if st.session_state.get('mev_use_timing', False):
        # Calculate optimal submission time based on block timing
        current_block = random.randint(15000000, 16000000)  # Placeholder
        
        # In a real implementation, we would calculate optimal timing
        # Here we're just adding a placeholder
        protected_tx['optimizedTiming'] = True
        protected_tx['targetBlock'] = current_block + 2
    
    return protected_tx

def simulate_mev_protection(protected=True):
    """
    Simulate the effect of MEV protection on a transaction
    
    Args:
        protected: Whether protection is applied
        
    Returns:
        Simulation results
    """
    # Generate a mock transaction
    tx = {
        "type": random.choice(["Swap", "Add Liquidity", "Remove Liquidity"]),
        "amount": random.uniform(100, 10000),
        "token_pair": random.choice(["ETH/USDC", "ETH/USDT", "WBTC/ETH"]),
        "gas_price": random.uniform(30, 100),  # Gwei
        "slippage": random.uniform(0.5, 5.0)  # Percentage
    }
    
    # Calculate baseline values
    baseline_gas_cost = tx["gas_price"] * 100000 / 1e9 * 3000  # Assuming 100k gas units, ETH at $3000
    baseline_execution_time = random.uniform(10, 60)  # Seconds
    
    # If protected, apply protection
    if protected:
        protection_level = st.session_state.get('mev_protection_level', "Standard")
        protection_efficiency = st.session_state.get('mev_protection_efficiency', 80)
        
        # Calculate protection effects
        gas_multiplier = st.session_state.get('mev_gas_multiplier', 1.2)
        
        protected_gas_cost = baseline_gas_cost * gas_multiplier
        
        # MEV opportunity reduction
        mev_risk_reduction = protection_efficiency / 100
        
        # Time impact (private transactions might take longer)
        if protection_level in ["Advanced", "Maximum"]:
            time_multiplier = random.uniform(1.0, 1.5)
        else:
            time_multiplier = random.uniform(0.9, 1.2)
        
        protected_execution_time = baseline_execution_time * time_multiplier
        
        # Success probability improvement
        baseline_success_prob = 0.95
        protected_success_prob = min(0.99, baseline_success_prob + (1 - baseline_success_prob) * mev_risk_reduction)
        
        # MEV exposure reduction
        baseline_mev_exposure = random.uniform(0.1, 5.0) * tx["amount"] / 100  # 0.1-5% of tx amount
        protected_mev_exposure = baseline_mev_exposure * (1 - mev_risk_reduction)
        
        return {
            "transaction": tx,
            "baseline": {
                "gas_cost_usd": baseline_gas_cost,
                "execution_time_seconds": baseline_execution_time,
                "success_probability": baseline_success_prob,
                "mev_exposure_usd": baseline_mev_exposure
            },
            "protected": {
                "gas_cost_usd": protected_gas_cost,
                "execution_time_seconds": protected_execution_time,
                "success_probability": protected_success_prob,
                "mev_exposure_usd": protected_mev_exposure,
                "protection_level": protection_level,
                "protection_efficiency": protection_efficiency
            },
            "savings": {
                "mev_savings_usd": baseline_mev_exposure - protected_mev_exposure,
                "additional_gas_cost_usd": protected_gas_cost - baseline_gas_cost,
                "net_benefit_usd": (baseline_mev_exposure - protected_mev_exposure) - (protected_gas_cost - baseline_gas_cost)
            }
        }
    else:
        # Return just baseline metrics
        return {
            "transaction": tx,
            "baseline": {
                "gas_cost_usd": baseline_gas_cost,
                "execution_time_seconds": baseline_execution_time,
                "success_probability": 0.95,
                "mev_exposure_usd": random.uniform(0.1, 5.0) * tx["amount"] / 100
            }
        }

def get_mev_statistics():
    """
    Get statistics about MEV activity
    
    Returns:
        MEV statistics
    """
    # In a real implementation, this would query MEV monitoring APIs
    # Here we're generating mock data for demonstration
    
    return {
        "total_mev_last_24h_eth": random.uniform(50, 200),
        "total_mev_last_24h_usd": random.uniform(150000, 600000),
        "sandwich_attacks_24h": random.randint(500, 2000),
        "front_running_24h": random.randint(1000, 5000),
        "average_profit_per_attack_eth": random.uniform(0.05, 0.5),
        "largest_mev_extraction_eth": random.uniform(5, 20),
        "protected_transactions_24h": random.randint(10000, 50000),
        "estimated_savings_eth": random.uniform(10, 50)
    }
