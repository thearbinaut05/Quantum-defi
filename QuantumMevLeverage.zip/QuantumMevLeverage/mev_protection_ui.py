"""
MEV Protection UI

This module provides the user interface components for advanced MEV protection
features, including transaction protection, MEV monitoring, and risk assessment.
"""

import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
import time
from datetime import datetime, timedelta
import random
import json
import hashlib

# Import custom modules
import mev_protection as mev
import wallet_manager as wm
from attached_assets.wallet_connect import CREATOR_ADDRESS

# MEV Protection Constants
PROTECTION_LEVELS = ["Basic", "Standard", "Advanced", "Maximum"]
PROTECTION_FEATURES = ["Private Transactions", "Dynamic Slippage", "Timing Optimization"]

def render_mev_dashboard():
    """Render the MEV protection dashboard"""
    st.header("🛡️ Advanced MEV Protection")
    
    st.write("""
    ### Protect Your Transactions from MEV Attacks
    
    Maximal Extractable Value (MEV) refers to the profit that can be extracted by reordering, 
    including, or censoring transactions within blocks. Our advanced protection system defends 
    your transactions from common MEV attacks like front-running and sandwich attacks.
    """)
    
    # Initialize session state for MEV protection settings
    if 'mev_protection_active' not in st.session_state:
        st.session_state.mev_protection_active = True
    
    if 'mev_protection_level' not in st.session_state:
        st.session_state.mev_protection_level = "Standard"
    
    if 'mev_use_private_txs' not in st.session_state:
        st.session_state.mev_use_private_txs = True
    
    if 'mev_use_slippage' not in st.session_state:
        st.session_state.mev_use_slippage = True
    
    if 'mev_use_timing' not in st.session_state:
        st.session_state.mev_use_timing = False
    
    if 'mev_gas_multiplier' not in st.session_state:
        st.session_state.mev_gas_multiplier = 1.2
        
    if 'mev_selected_relayer' not in st.session_state:
        st.session_state.mev_selected_relayer = "Flashbots"
        
    if 'mev_protection_efficiency' not in st.session_state:
        st.session_state.mev_protection_efficiency = 80
    
    # Create columns for the protection settings
    col1, col2 = st.columns([2, 3])
    
    with col1:
        st.subheader("Protection Settings")
        
        # MEV Protection toggle
        protection_active = st.toggle(
            "Enable MEV Protection", 
            value=st.session_state.mev_protection_active,
            help="Activates advanced MEV protection for all transactions"
        )
        
        # Protection level selection
        protection_level = st.selectbox(
            "Protection Level",
            options=PROTECTION_LEVELS,
            index=PROTECTION_LEVELS.index(st.session_state.mev_protection_level),
            help="Higher protection levels provide better security but may incur higher gas costs"
        )
        
        # Protection features
        st.write("**Protection Features:**")
        
        use_private_txs = st.checkbox(
            "Use Private Transactions", 
            value=st.session_state.mev_use_private_txs,
            help="Send transactions through private relayers to avoid public mempool exposure"
        )
        
        use_slippage = st.checkbox(
            "Dynamic Slippage Protection", 
            value=st.session_state.mev_use_slippage,
            help="Automatically adjust slippage tolerance based on market conditions"
        )
        
        use_timing = st.checkbox(
            "Transaction Timing Optimization", 
            value=st.session_state.mev_use_timing,
            help="Optimize transaction submission timing to reduce MEV exposure"
        )
        
        # Update button
        if st.button("Update Protection Settings"):
            # Update settings using the MEV protection module
            updated_settings = mev.update_protection_settings(
                protection_active,
                protection_level,
                use_private_txs,
                use_slippage,
                use_timing
            )
            
            st.success("MEV protection settings updated successfully!")
            
            # Show the new settings
            st.json(updated_settings)
    
    with col2:
        st.subheader("Protection Status")
        
        # Create metrics for protection efficiency
        col_a, col_b, col_c = st.columns(3)
        
        with col_a:
            efficiency = st.session_state.mev_protection_efficiency
            st.metric(
                "Protection Efficiency", 
                f"{efficiency}%",
                help="Higher values indicate stronger protection against MEV attacks"
            )
        
        with col_b:
            relayer = st.session_state.mev_selected_relayer or "None"
            st.metric(
                "Selected Relayer", 
                relayer,
                help="Private transaction relayer used for protected transactions"
            )
        
        with col_c:
            gas_factor = st.session_state.mev_gas_multiplier
            st.metric(
                "Gas Price Multiplier", 
                f"{gas_factor}x",
                help="Higher values may increase transaction costs but provide better protection"
            )
        
        # Show network congestion
        congestion = mev.get_network_congestion()
        
        # Create a gauge chart for network congestion
        fig = go.Figure(go.Indicator(
            mode="gauge+number",
            value=congestion,
            title={"text": "Network Congestion"},
            domain={"x": [0, 1], "y": [0, 1]},
            gauge={
                "axis": {"range": [0, 100]},
                "bar": {"color": "darkblue"},
                "steps": [
                    {"range": [0, 30], "color": "green"},
                    {"range": [30, 70], "color": "yellow"},
                    {"range": [70, 100], "color": "red"}
                ],
                "threshold": {
                    "line": {"color": "red", "width": 4},
                    "thickness": 0.75,
                    "value": congestion
                }
            }
        ))
        
        fig.update_layout(height=250, margin=dict(l=10, r=10, t=50, b=10))
        st.plotly_chart(fig, use_container_width=True)
        
        # Add explanatory text
        if congestion < 30:
            st.info("Network congestion is low. MEV risk is reduced.")
        elif congestion < 70:
            st.warning("Moderate network congestion. Consider standard MEV protection.")
        else:
            st.error("High network congestion! Maximum MEV protection recommended.")

def render_mev_activity_monitor():
    """Render the MEV activity monitoring section"""
    st.subheader("MEV Activity Monitor")
    
    # Get recent MEV activity data
    mev_activities = mev.get_recent_mev_activity()
    
    # Convert to DataFrame for easier display
    df = pd.DataFrame(mev_activities)
    
    # Calculate summary metrics
    total_profit_eth = df["profit_eth"].sum()
    total_profit_usd = df["profit_usd"].sum()
    total_detected = df["detected"].sum()
    total_protected = df["protected"].sum()
    
    # Display metrics
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.metric("Total MEV Activity", f"{len(df)}")
    
    with col2:
        st.metric("Total Value Extracted", f"${total_profit_usd:.2f}")
    
    with col3:
        st.metric("Detected Attacks", f"{total_detected}")
    
    with col4:
        protection_rate = (total_protected / len(df)) * 100 if len(df) > 0 else 0
        st.metric("Protection Rate", f"{protection_rate:.1f}%")
    
    # Plot MEV activity by type
    try:
        # Group by type and calculate profit
        type_profit = df.groupby("type")["profit_usd"].sum().reset_index()
        
        # Create bar chart
        fig = px.bar(
            type_profit, 
            x="type", 
            y="profit_usd", 
            color="type",
            labels={"profit_usd": "Value Extracted (USD)", "type": "MEV Type"},
            title="Value Extracted by MEV Type"
        )
        
        fig.update_layout(xaxis_title="MEV Type", yaxis_title="Value (USD)")
        st.plotly_chart(fig, use_container_width=True)
    except Exception as e:
        st.error(f"Error creating MEV activity chart: {str(e)}")
    
    # Display recent MEV activities
    st.subheader("Recent MEV Activity")
    
    # Format the DataFrame for display
    display_df = df.copy()
    display_df["profit_eth"] = display_df["profit_eth"].apply(lambda x: f"{x:.4f} ETH")
    display_df["profit_usd"] = display_df["profit_usd"].apply(lambda x: f"${x:.2f}")
    display_df["detected"] = display_df["detected"].apply(lambda x: "✅" if x else "❌")
    display_df["protected"] = display_df["protected"].apply(lambda x: "✅" if x else "❌")
    
    st.dataframe(
        display_df,
        column_config={
            "timestamp": "Time",
            "type": "Attack Type",
            "profit_eth": "Profit (ETH)",
            "profit_usd": "Profit (USD)",
            "token_pair": "Token Pair",
            "dex": "DEX",
            "tx_hash": st.column_config.LinkColumn("Transaction", display_text="View"),
            "detected": "Detected",
            "protected": "Protected"
        },
        hide_index=True
    )

def render_risk_assessment_tool():
    """Render the transaction risk assessment tool"""
    st.subheader("Transaction Risk Assessment")
    
    st.write("""
    Assess the MEV risk of your transaction before executing it. 
    This tool helps you understand potential risks and provides 
    recommendations to protect your transaction.
    """)
    
    # Input form for transaction details
    with st.form("risk_assessment_form"):
        # Transaction type
        tx_type = st.selectbox(
            "Transaction Type",
            options=["Swap", "Add Liquidity", "Remove Liquidity", "Flash Swap", "Cross-chain Swap"]
        )
        
        # Token pair
        token_options = ["ETH", "WBTC", "USDC", "USDT", "DAI", "LINK", "UNI", "AAVE"]
        col1, col2 = st.columns(2)
        
        with col1:
            token1 = st.selectbox("Token 1", options=token_options)
        
        with col2:
            filtered_tokens = [t for t in token_options if t != token1]
            token2 = st.selectbox("Token 2", options=filtered_tokens)
        
        token_pair = f"{token1}/{token2}"
        
        # Transaction size
        tx_size = st.slider(
            "Transaction Size (USD)",
            min_value=100,
            max_value=100000,
            value=1000,
            step=100
        )
        
        # Transaction urgency
        urgency = st.select_slider(
            "Transaction Urgency",
            options=["Low", "Medium", "High", "Urgent"]
        )
        
        # Submit button
        submit = st.form_submit_button("Assess Risk")
    
    # Process form submission
    if submit:
        # Show a spinner while "calculating"
        with st.spinner("Analyzing transaction risk..."):
            time.sleep(1)  # Simulate calculation time
            
            # Get risk assessment
            risk_assessment = mev.assess_transaction_risk(tx_type, token_pair, tx_size, urgency)
            
            # Display risk score with gauge
            risk_score = risk_assessment["risk_score"]
            
            fig = go.Figure(go.Indicator(
                mode="gauge+number",
                value=risk_score,
                title={"text": "MEV Risk Score"},
                domain={"x": [0, 1], "y": [0, 1]},
                gauge={
                    "axis": {"range": [0, 100]},
                    "bar": {"color": "darkblue"},
                    "steps": [
                        {"range": [0, 30], "color": "green"},
                        {"range": [30, 70], "color": "yellow"},
                        {"range": [70, 100], "color": "red"}
                    ],
                    "threshold": {
                        "line": {"color": "red", "width": 4},
                        "thickness": 0.75,
                        "value": risk_score
                    }
                }
            ))
            
            fig.update_layout(height=250, margin=dict(l=10, r=10, t=50, b=10))
            st.plotly_chart(fig, use_container_width=True)
            
            # Risk interpretation
            if risk_score < 30:
                st.success("Low Risk: This transaction has minimal MEV exposure")
            elif risk_score < 60:
                st.warning("Moderate Risk: This transaction may be targeted by MEV extractors")
            else:
                st.error("High Risk: This transaction is likely to be targeted by MEV extractors")
            
            # Display risk factors
            st.subheader("Risk Factors")
            
            risk_factors = risk_assessment["risk_factors"]
            for factor, value in risk_factors.items():
                st.write(f"**{factor}:** {value}")
            
            # Display recommendations
            st.subheader("Protection Recommendations")
            
            recommendations = risk_assessment["recommendations"]
            for i, recommendation in enumerate(recommendations):
                st.write(f"{i+1}. {recommendation}")
            
            # Show apply protection button
            if st.button("Apply Recommended Protection"):
                # Update protection settings based on recommendations
                recommended_level = recommendations[-1].split(": ")[-1]
                
                use_private = "private transactions" in " ".join(recommendations).lower()
                use_slippage = "slippage" in " ".join(recommendations).lower()
                use_timing = "timing" in " ".join(recommendations).lower() or "twap" in " ".join(recommendations).lower()
                
                # Update settings
                updated_settings = mev.update_protection_settings(
                    True,
                    recommended_level,
                    use_private,
                    use_slippage,
                    use_timing
                )
                
                st.success("Protection settings updated based on recommendations!")
                st.json(updated_settings)

def render_flashswap_mev_protection():
    """
    Render MEV protection specifically for flash swaps in the auto-trading interface
    This is a simplified version focused on the auto-trading features
    """
    if not st.session_state.get('wallet_connected', False):
        return
    
    # Check if auto trading is enabled
    if not st.session_state.get('auto_trading_enabled', False):
        return
    
    st.subheader("🛡️ Flash Swap MEV Protection")
    
    col1, col2 = st.columns(2)
    
    with col1:
        # Toggle MEV protection for auto-trading
        protection_active = st.toggle(
            "Enable MEV Protection", 
            value=st.session_state.get('mev_protection_active', True),
            help="Protect auto-executed flash swaps from MEV attacks"
        )
        
        # If toggled, update the setting
        if protection_active != st.session_state.get('mev_protection_active', True):
            st.session_state.mev_protection_active = protection_active
            if protection_active:
                st.success("MEV protection enabled for all flash swaps")
            else:
                st.warning("MEV protection disabled for flash swaps")
        
        # Protection level for flash swaps
        protection_level = st.select_slider(
            "MEV Protection Level",
            options=PROTECTION_LEVELS,
            value=st.session_state.get('mev_protection_level', "Standard"),
            help="Higher levels provide better protection with higher gas costs"
        )
        
        # If changed, update the setting
        if protection_level != st.session_state.get('mev_protection_level', "Standard"):
            st.session_state.mev_protection_level = protection_level
            
            # Apply settings update
            mev.update_protection_settings(
                protection_active,
                protection_level,
                st.session_state.get('mev_use_private_txs', True),
                st.session_state.get('mev_use_slippage', True),
                st.session_state.get('mev_use_timing', False)
            )
            
            st.success(f"MEV protection level updated to {protection_level}")
    
    with col2:
        # Show current protection status
        protection_efficiency = st.session_state.get('mev_protection_efficiency', 80)
        
        fig = go.Figure(go.Indicator(
            mode="gauge+number",
            value=protection_efficiency,
            title={"text": "Protection Efficiency"},
            domain={"x": [0, 1], "y": [0, 1]},
            gauge={
                "axis": {"range": [0, 100]},
                "bar": {"color": "royalblue"},
                "steps": [
                    {"range": [0, 50], "color": "lightgray"},
                    {"range": [50, 75], "color": "gray"},
                    {"range": [75, 100], "color": "darkblue"}
                ],
                "threshold": {
                    "line": {"color": "green", "width": 4},
                    "thickness": 0.75,
                    "value": protection_efficiency
                }
            }
        ))
        
        fig.update_layout(height=200, margin=dict(l=10, r=10, t=30, b=10))
        st.plotly_chart(fig, use_container_width=True)
    
    # Show attack prevention stats
    if 'mev_attacks_prevented' not in st.session_state:
        st.session_state.mev_attacks_prevented = 0
        
    if 'mev_value_protected' not in st.session_state:
        st.session_state.mev_value_protected = 0.0
    
    # Update stats based on number of transactions (for simulation)
    if 'wallet_transactions' in st.session_state and st.session_state.wallet_transactions:
        num_txs = len(st.session_state.wallet_transactions)
        protection_rate = protection_efficiency / 100
        
        # Simulate MEV attack prevention
        st.session_state.mev_attacks_prevented = int(num_txs * 0.3 * protection_rate)
        
        # Calculate protected value based on transaction profits
        total_profit = st.session_state.get('total_profit', 0)
        potential_mev_loss = total_profit * 0.4  # 40% of profit could be lost to MEV
        st.session_state.mev_value_protected = potential_mev_loss * protection_rate
    
    # Display attack prevention metrics
    col1, col2 = st.columns(2)
    
    with col1:
        st.metric("MEV Attacks Prevented", f"{st.session_state.mev_attacks_prevented}")
    
    with col2:
        st.metric("Value Protected", f"${st.session_state.mev_value_protected:.2f}")
    
    # Show brief description
    st.info("""
        MEV protection secures your flash swaps from front-running, sandwich attacks, and other MEV exploits.
        Higher protection levels use private transaction relayers and optimized slippage settings.
    """)
    
    # Add advanced MEV protection button
    if st.button("Show Advanced MEV Protection Settings"):
        st.session_state.show_advanced_mev = True
        st.rerun()

def enhance_transaction_with_mev_protection(transaction_data):
    """
    Enhance a transaction with MEV protection
    
    Args:
        transaction_data: The transaction to protect
        
    Returns:
        Protected transaction data
    """
    # Skip if MEV protection is not active
    if not st.session_state.get('mev_protection_active', False):
        return transaction_data
    
    # Get protection level
    protection_level = st.session_state.get('mev_protection_level', "Standard")
    
    # Apply protection
    protected_tx = mev.protect_transaction(transaction_data, protection_level)
    
    # Simulate MEV attack protection
    # In a real implementation, this would be part of the transaction execution
    protection_efficiency = st.session_state.get('mev_protection_efficiency', 80)
    was_protected = random.random() < (protection_efficiency / 100)
    
    if was_protected:
        # Update MEV attack prevention stats
        if 'mev_attacks_prevented' in st.session_state:
            st.session_state.mev_attacks_prevented += 1
            
        # Calculate value saved
        tx_value = transaction_data.get('amount', 0)
        potential_mev_loss = tx_value * random.uniform(0.005, 0.03)  # 0.5-3% potential loss
        
        if 'mev_value_protected' in st.session_state:
            st.session_state.mev_value_protected += potential_mev_loss
    
    # Add MEV protection metadata to transaction for record-keeping
    protected_tx['mev_protected'] = True
    protected_tx['protection_level'] = protection_level
    protected_tx['relayer'] = st.session_state.get('mev_selected_relayer', None)
    
    return protected_tx

def generate_mev_attack_simulation():
    """
    Generate a simulated MEV attack for educational purposes
    
    Returns:
        Dictionary with attack details
    """
    # Generate random attack parameters
    attack_types = ["front_running", "sandwich_attack", "back_running", "liquidation"]
    attack_type = random.choice(attack_types)
    
    # Generate a random token pair
    tokens = ["ETH", "USDC", "USDT", "DAI", "WBTC", "LINK", "UNI"]
    token1 = random.choice(tokens)
    token2 = random.choice([t for t in tokens if t != token1])
    token_pair = f"{token1}/{token2}"
    
    # Generate random transaction amounts
    user_amount = random.uniform(1000, 10000)
    
    # Calculate attack profit based on attack type
    if attack_type == "front_running":
        profit_pct = random.uniform(0.2, 1.0)
        
    elif attack_type == "sandwich_attack":
        profit_pct = random.uniform(0.5, 2.0)
        
    elif attack_type == "back_running":
        profit_pct = random.uniform(0.1, 0.7)
        
    else:  # liquidation
        profit_pct = random.uniform(3.0, 10.0)
    
    profit_amount = user_amount * (profit_pct / 100)
    
    # Calculate gas costs
    gas_price = random.randint(30, 100)  # Gwei
    gas_limit = random.randint(100000, 300000)
    gas_cost_eth = (gas_price * gas_limit) / 1e9
    gas_cost_usd = gas_cost_eth * 3000  # Assuming 1 ETH = $3000
    
    # Calculate net profit
    net_profit = profit_amount - gas_cost_usd
    
    # Determine if attack would be profitable
    is_profitable = net_profit > 0
    
    # Generate random transactions for the attack
    tx_data = f"mev-{attack_type}-{token_pair}-{datetime.now().isoformat()}"
    tx_hash = hashlib.sha256(tx_data.encode()).hexdigest()
    
    # Generate attack transaction
    attack_tx = {
        "hash": tx_hash,
        "type": attack_type,
        "token_pair": token_pair,
        "user_amount": user_amount,
        "profit_pct": profit_pct,
        "profit_amount": profit_amount,
        "gas_cost_eth": gas_cost_eth,
        "gas_cost_usd": gas_cost_usd,
        "net_profit": net_profit,
        "is_profitable": is_profitable,
        "timestamp": datetime.now().isoformat(),
        "attacker": "0x" + "".join(random.choices("0123456789abcdef", k=40)),
        "victim": "0x" + "".join(random.choices("0123456789abcdef", k=40)),
        "dex": random.choice(["Uniswap V3", "Uniswap V2", "Sushiswap", "Curve", "Balancer"]),
    }
    
    return attack_tx

def render_mev_education():
    """Render educational content about MEV"""
    st.subheader("Understanding MEV (Maximal Extractable Value)")
    
    st.write("""
    ### What is MEV?
    
    Maximal Extractable Value (MEV) refers to the maximum value that can be extracted 
    from block production in excess of the standard block reward and gas fees. It represents 
    profit opportunities available to miners (or validators) and other participants who can 
    influence transaction ordering within blocks.
    
    ### Common MEV Attack Types
    """)
    
    # Create tabs for different attack types
    attack_tabs = st.tabs([
        "Front-Running", 
        "Sandwich Attacks", 
        "Back-Running", 
        "Liquidations"
    ])
    
    with attack_tabs[0]:
        st.write("""
        **Front-Running** occurs when a trader or bot observes a pending transaction 
        in the mempool and submits their own transaction with a higher gas price, 
        ensuring it gets processed first. This lets them capitalize on the price 
        impact of the original transaction.
        
        **Example:** A trader spots a large pending swap that will increase the price 
        of a token. They quickly buy that token before the large swap executes, then 
        sell at the higher price after the large swap is processed, profiting from the 
        price difference.
        """)
        
        # Generate a front-running simulation
        if st.button("Simulate Front-Running Attack", key="sim_frontrun"):
            with st.spinner("Simulating attack..."):
                time.sleep(1)
                attack = generate_mev_attack_simulation()
                attack["type"] = "front_running"
                
                # Display the simulation
                st.subheader("Front-Running Attack Simulation")
                
                col1, col2, col3 = st.columns(3)
                with col1:
                    st.metric("User Transaction", f"${attack['user_amount']:.2f}")
                with col2:
                    st.metric("MEV Profit", f"${attack['profit_amount']:.2f}")
                with col3:
                    st.metric("Gas Cost", f"${attack['gas_cost_usd']:.2f}")
                
                # Show the attack flow
                st.write("**Attack Flow:**")
                st.code(f"""
1. User submits swap: {attack['token_pair']} for ${attack['user_amount']:.2f}
2. MEV bot sees transaction in mempool
3. Bot front-runs with higher gas price: {attack['gas_price']} Gwei
4. Bot executes same trade BEFORE user
5. User transaction executes, moving price
6. Bot sells at new price for ${attack['profit_amount']:.2f} profit
                """)
                
                # Show how MEV protection would prevent this
                st.info("""
                **How MEV Protection Prevents This:**
                
                1. Private transactions (via Flashbots) hide your transaction from the public mempool
                2. Optimized slippage settings protect you from price impact
                3. Transaction timing adjustments avoid high MEV activity periods
                """)
    
    with attack_tabs[1]:
        st.write("""
        **Sandwich Attacks** involve placing two transactions around a target transaction. 
        First, the attacker front-runs the target by buying the asset, then they back-run by 
        selling after the target transaction executes. This exploits the price impact of the 
        target transaction.
        
        **Example:** A trader observes a pending swap from ETH to USDC. They first buy the 
        target token, forcing the victim's transaction to execute at a worse price, then 
        immediately sell the token after the victim's transaction completes.
        """)
        
        # Generate a sandwich attack simulation
        if st.button("Simulate Sandwich Attack", key="sim_sandwich"):
            with st.spinner("Simulating attack..."):
                time.sleep(1)
                attack = generate_mev_attack_simulation()
                attack["type"] = "sandwich_attack"
                
                # Display the simulation
                st.subheader("Sandwich Attack Simulation")
                
                col1, col2, col3 = st.columns(3)
                with col1:
                    st.metric("User Transaction", f"${attack['user_amount']:.2f}")
                with col2:
                    st.metric("MEV Profit", f"${attack['profit_amount']:.2f}")
                with col3:
                    st.metric("Gas Cost", f"${attack['gas_cost_usd']:.2f}")
                
                # Show the attack flow
                st.write("**Attack Flow:**")
                st.code(f"""
1. User submits swap: {attack['token_pair']} for ${attack['user_amount']:.2f}
2. MEV bot sees transaction in mempool
3. Bot executes BUY transaction BEFORE user (front-run)
4. User transaction executes at worse price due to front-run
5. Bot executes SELL transaction AFTER user (back-run)
6. Bot profits ${attack['profit_amount']:.2f} from price difference
                """)
                
                # Show how MEV protection would prevent this
                st.info("""
                **How MEV Protection Prevents This:**
                
                1. Private transactions keep your intent hidden from attackers
                2. Dynamic slippage protection ensures you get a fair price
                3. Specialized gas pricing makes sandwich attacks unprofitable
                """)
    
    with attack_tabs[2]:
        st.write("""
        **Back-Running** occurs when a trader places their transaction immediately after a 
        target transaction. This is commonly used to capitalize on arbitrage opportunities 
        created by large trades or liquidations.
        
        **Example:** After a large swap creates a price discrepancy between exchanges, a 
        back-runner executes an arbitrage trade to profit from the temporary price difference.
        """)
        
        # Generate a back-running simulation
        if st.button("Simulate Back-Running Attack", key="sim_backrun"):
            with st.spinner("Simulating attack..."):
                time.sleep(1)
                attack = generate_mev_attack_simulation()
                attack["type"] = "back_running"
                
                # Display the simulation
                st.subheader("Back-Running Attack Simulation")
                
                col1, col2, col3 = st.columns(3)
                with col1:
                    st.metric("User Transaction", f"${attack['user_amount']:.2f}")
                with col2:
                    st.metric("MEV Profit", f"${attack['profit_amount']:.2f}")
                with col3:
                    st.metric("Gas Cost", f"${attack['gas_cost_usd']:.2f}")
                
                # Show the attack flow
                st.write("**Attack Flow:**")
                st.code(f"""
1. User submits large swap: {attack['token_pair']} for ${attack['user_amount']:.2f}
2. User transaction creates price discrepancy
3. MEV bot detects opportunity and back-runs the transaction
4. Bot executes arbitrage between exchanges
5. Price discrepancy is eliminated
6. Bot profits ${attack['profit_amount']:.2f} from the arbitrage
                """)
                
                # Show how MEV protection would impact this
                st.info("""
                **How MEV Protection Addresses This:**
                
                Back-running is generally less harmful to users than other MEV forms.
                Our advanced MEV system actually uses back-running strategies to
                ENHANCE your returns through arbitrage opportunities.
                """)
    
    with attack_tabs[3]:
        st.write("""
        **Liquidations** involve MEV extractors competing to liquidate undercollateralized 
        positions in lending protocols. Bots monitor positions and race to submit liquidation 
        transactions as soon as positions become eligible.
        
        **Example:** A borrower's collateral value drops below the required threshold on a 
        lending platform. MEV bots compete to liquidate the position and collect the 
        liquidation bonus.
        """)
        
        # Generate a liquidation simulation
        if st.button("Simulate Liquidation MEV", key="sim_liquidation"):
            with st.spinner("Simulating attack..."):
                time.sleep(1)
                attack = generate_mev_attack_simulation()
                attack["type"] = "liquidation"
                
                # Use higher amounts for liquidations
                attack["user_amount"] = attack["user_amount"] * 5
                attack["profit_amount"] = attack["profit_amount"] * 5
                
                # Display the simulation
                st.subheader("Liquidation MEV Simulation")
                
                col1, col2, col3 = st.columns(3)
                with col1:
                    st.metric("Collateral Value", f"${attack['user_amount']:.2f}")
                with col2:
                    st.metric("Liquidation Bonus", f"${attack['profit_amount']:.2f}")
                with col3:
                    st.metric("Gas Cost", f"${attack['gas_cost_usd']:.2f}")
                
                # Show the attack flow
                st.write("**Liquidation Flow:**")
                st.code(f"""
1. Borrower's position on lending platform falls below health factor
2. Position becomes eligible for liquidation
3. Multiple MEV bots compete to liquidate position
4. Winning bot receives ${attack['profit_amount']:.2f} liquidation bonus
5. Borrower loses collateral + liquidation penalty
                """)
                
                # Show how MEV protection would impact this
                st.info("""
                **How Our System Protects You:**
                
                1. Automatic collateral management prevents liquidations
                2. Advanced health factor monitoring with early warnings
                3. Intelligent rebalancing of collateral during market volatility
                """)
    
    # Add a system architecture diagram
    st.subheader("MEV Protection System Architecture")
    
    st.write("""
    Our MEV protection system uses a multi-layered approach to defend your transactions
    from various attack vectors while also capturing beneficial MEV opportunities.
    """)
    
    # Create a simple architecture visualization
    st.code("""
    +------------------------+         +------------------------+
    |                        |         |                        |
    |  Transaction Request   |-------->|  MEV Risk Assessment   |
    |                        |         |                        |
    +------------------------+         +------------------------+
                |                                 |
                v                                 v
    +------------------------+         +------------------------+
    |                        |         |                        |
    |  Protection Strategy   |<------->|  Network Monitoring    |
    |  Selection             |         |  & Congestion Analysis |
    |                        |         |                        |
    +------------------------+         +------------------------+
                |
                v
    +------------------------+         +------------------------+
    |                        |         |                        |
    |  Private Transaction   |-------->|  Private Relayer       |
    |  Bundling              |         |  (Flashbots, Eden, etc)|
    |                        |         |                        |
    +------------------------+         +------------------------+
                                                |
                                                v
    +------------------------+         +------------------------+
    |                        |         |                        |
    |  Post-Transaction      |<--------|  Blockchain            |
    |  Analysis & Reporting  |         |  Confirmation          |
    |                        |         |                        |
    +------------------------+         +------------------------+
    """)
    
    # Show current protection status
    if st.session_state.get('mev_protection_active', False):
        st.success(f"""
        MEV Protection Status: ACTIVE
        
        Current Protection Level: {st.session_state.get('mev_protection_level', 'Standard')}
        Current Efficiency: {st.session_state.get('mev_protection_efficiency', 80)}%
        Current Relayer: {st.session_state.get('mev_selected_relayer', 'None')}
        """)
    else:
        st.warning("MEV Protection Status: INACTIVE")