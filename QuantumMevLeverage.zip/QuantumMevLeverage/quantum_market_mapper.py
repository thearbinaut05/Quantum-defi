import numpy as np
import pandas as pd
import time
from datetime import datetime, timedelta
import random
import streamlit as st
from scipy.linalg import eigh

# Import local modules for data fetching
import crypto_data
import utils

class QuantumMarketMapper:
    """
    Maps cryptocurrency market data into a quantum state representation
    for enhanced pattern recognition and prediction capabilities.
    
    Uses quantum-inspired algorithms to model market dynamics as quantum states
    and performs quantum operations to extract insights about future price movements.
    """
    
    def __init__(self, assets, lookback_days=30, quantum_circuit_depth=3):
        """
        Initialize the quantum market mapper
        
        Args:
            assets: List of cryptocurrency symbols to track
            lookback_days: Historical data period to consider
            quantum_circuit_depth: Complexity of quantum circuit simulation
        """
        self.assets = assets
        self.lookback_days = lookback_days
        self.quantum_circuit_depth = quantum_circuit_depth
        
        # Quantum state representation
        self.quantum_state = {}
        self.density_matrix = None
        self.eigenvalues = None
        self.eigenvectors = None
        
        # Historical state tracking
        self.state_history = []
        
        # Performance metrics
        self.prediction_accuracy = 0.0
        self.quantum_advantage = 0.0
        
        # Last update timestamp
        self.last_updated = None
        
        # Initialize market state
        self.update_market_state(assets)
    
    def update_market_state(self, assets=None):
        """
        Update the quantum market state representation
        
        Args:
            assets: Optional list of assets to update, defaults to all tracked assets
        """
        if assets is None:
            assets = self.assets
        
        # Fetch historical data for selected assets
        market_data = {}
        for asset in assets:
            try:
                # Fetch historical price data
                historical_data = crypto_data.get_historical_data(asset, days=self.lookback_days)
                
                if historical_data is None or historical_data.empty:
                    # Use simulated data for demonstration if real data not available
                    historical_data = self._generate_simulated_data(asset)
                
                market_data[asset] = historical_data
            except Exception as e:
                st.error(f"Error fetching data for {asset}: {str(e)}")
                market_data[asset] = self._generate_simulated_data(asset)
        
        # Compute quantum state representation
        self._compute_quantum_state(market_data)
        
        # Update timestamp
        self.last_updated = datetime.now()
    
    def _generate_simulated_data(self, asset):
        """
        Generate simulated price data for demonstration purposes
        
        Args:
            asset: Asset symbol to simulate data for
            
        Returns:
            DataFrame with simulated historical data
        """
        # Start with a base price based on the asset
        if asset == 'BTC':
            base_price = 35000
            volatility = 0.03
        elif asset == 'ETH':
            base_price = 2000
            volatility = 0.04
        elif asset == 'LINK':
            base_price = 7
            volatility = 0.05
        else:
            base_price = 10
            volatility = 0.04
        
        # Generate dates
        end_date = datetime.now()
        start_date = end_date - timedelta(days=self.lookback_days)
        dates = pd.date_range(start=start_date, end=end_date, freq='D')
        
        # Generate prices using geometric Brownian motion
        price_data = []
        current_price = base_price
        
        for _ in range(len(dates)):
            # Random price movement with drift
            daily_return = np.random.normal(0.001, volatility)
            current_price = current_price * (1 + daily_return)
            price_data.append(current_price)
        
        # Create DataFrame
        df = pd.DataFrame({
            'close': price_data,
            'open': [p * (1 - random.uniform(0, 0.01)) for p in price_data],
            'high': [p * (1 + random.uniform(0, 0.02)) for p in price_data],
            'low': [p * (1 - random.uniform(0, 0.02)) for p in price_data],
            'volume': [base_price * 1000 * (1 + random.uniform(-0.5, 0.5)) for _ in price_data]
        }, index=dates)
        
        # Add technical indicators
        df['sma_7'] = df['close'].rolling(window=7).mean()
        df['ema_14'] = df['close'].ewm(span=14).mean()
        df['rsi_14'] = self._calculate_rsi(df['close'], 14)
        df['volatility'] = df['close'].pct_change().rolling(window=7).std()
        
        return df
    
    def _calculate_rsi(self, prices, window=14):
        """
        Calculate RSI technical indicator
        
        Args:
            prices: Series of prices
            window: RSI window length
            
        Returns:
            Series with RSI values
        """
        # Calculate price changes
        delta = prices.diff()
        
        # Separate gains and losses
        gain = delta.copy()
        loss = delta.copy()
        gain[gain < 0] = 0
        loss[loss > 0] = 0
        loss = -loss
        
        # Calculate average gain and loss
        avg_gain = gain.rolling(window=window).mean()
        avg_loss = loss.rolling(window=window).mean()
        
        # Calculate RS and RSI
        rs = avg_gain / avg_loss
        rsi = 100 - (100 / (1 + rs))
        
        return rsi
    
    def _compute_quantum_state(self, market_data):
        """
        Compute the quantum state representation of market data
        
        Args:
            market_data: Dictionary of DataFrames with historical market data
        """
        # Initialize quantum state
        self.quantum_state = {}
        
        # Process each asset
        for asset, data in market_data.items():
            # Skip if data is empty
            if data is None or data.empty:
                continue
            
            # Extract relevant features
            try:
                # Use most recent data points
                recent_data = data.iloc[-30:] if len(data) > 30 else data
                
                # Calculate normalized price changes (returns)
                returns = recent_data['close'].pct_change().fillna(0).values
                
                # Calculate volatility
                volatility = returns.std()
                
                # Calculate momentum (using exponential moving average crossovers)
                if 'ema_14' in recent_data.columns and 'sma_7' in recent_data.columns:
                    ema_cross = (recent_data['ema_14'].iloc[-1] > recent_data['sma_7'].iloc[-1]).astype(int)
                else:
                    ema_cross = 0
                
                # Calculate RSI (momentum indicator)
                if 'rsi_14' in recent_data.columns:
                    rsi = recent_data['rsi_14'].iloc[-1] / 100  # Normalize to 0-1
                else:
                    rsi = 0.5
                
                # Price levels
                current_price = recent_data['close'].iloc[-1]
                price_high_ratio = current_price / recent_data['high'].max()
                price_low_ratio = current_price / recent_data['low'].min()
                
                # Volume strength
                if 'volume' in recent_data.columns:
                    volume_ratio = recent_data['volume'].iloc[-1] / recent_data['volume'].mean()
                else:
                    volume_ratio = 1.0
                
                # Create quantum state features
                # These values represent "amplitudes" in our quantum-inspired model
                quantum_features = {
                    'returns': returns[-min(10, len(returns)):],  # Last 10 returns
                    'volatility': volatility,
                    'momentum': ema_cross,
                    'rsi': rsi,
                    'price_high_ratio': price_high_ratio,
                    'price_low_ratio': price_low_ratio,
                    'volume_ratio': volume_ratio,
                    'current_price': current_price
                }
                
                # Store quantum state for this asset
                self.quantum_state[asset] = quantum_features
                
            except Exception as e:
                st.error(f"Error computing quantum state for {asset}: {str(e)}")
        
        # Compute the density matrix representation (correlation matrix)
        self._compute_density_matrix()
        
        # Add to history
        self.state_history.append({
            'timestamp': datetime.now(),
            'quantum_state': self.quantum_state.copy(),
            'density_matrix': self.density_matrix.copy() if self.density_matrix is not None else None
        })
        
        # Limit history size
        if len(self.state_history) > 100:
            self.state_history = self.state_history[-100:]
    
    def _compute_density_matrix(self):
        """
        Compute density matrix representation of the market state
        (represents the correlation structure between assets)
        """
        # Check if we have enough assets to create a matrix
        assets_with_data = list(self.quantum_state.keys())
        if len(assets_with_data) < 2:
            self.density_matrix = None
            return
        
        # Create a correlation matrix based on returns
        n = len(assets_with_data)
        matrix = np.zeros((n, n))
        
        for i, asset1 in enumerate(assets_with_data):
            for j, asset2 in enumerate(assets_with_data):
                # Get last common returns
                returns1 = self.quantum_state[asset1]['returns']
                returns2 = self.quantum_state[asset2]['returns']
                
                # Calculate correlation
                if i == j:
                    correlation = 1.0
                else:
                    # Use minimum length
                    min_len = min(len(returns1), len(returns2))
                    if min_len > 1:
                        # Calculate correlation coefficient
                        correlation = np.corrcoef(returns1[-min_len:], returns2[-min_len:])[0, 1]
                        
                        # Handle NaN values
                        if np.isnan(correlation):
                            correlation = 0.0
                    else:
                        correlation = 0.0
                
                matrix[i, j] = correlation
        
        # Ensure the matrix is positive semi-definite (required for a valid density matrix)
        # by finding the nearest positive semi-definite matrix
        matrix = self._nearest_psd(matrix)
        
        # Normalize to trace = 1 (quantum density matrix requirement)
        trace = np.trace(matrix)
        if trace > 0:
            matrix = matrix / trace
        
        self.density_matrix = matrix
        
        # Calculate eigendecomposition
        self._calculate_eigendecomposition()
    
    def _nearest_psd(self, matrix):
        """
        Find the nearest positive semi-definite matrix to the input matrix
        
        Args:
            matrix: Input matrix
            
        Returns:
            Nearest positive semi-definite matrix
        """
        # Symmetrize
        B = (matrix + matrix.T) / 2
        
        # Calculate eigenvalues and eigenvectors
        eigvals, eigvecs = np.linalg.eigh(B)
        
        # Set negative eigenvalues to small positive value
        eigvals = np.maximum(eigvals, 1e-10)
        
        # Reconstruct the matrix
        return eigvecs.dot(np.diag(eigvals)).dot(eigvecs.T)
    
    def _calculate_eigendecomposition(self):
        """
        Calculate eigenvalues and eigenvectors of the density matrix
        """
        if self.density_matrix is not None:
            try:
                # Calculate eigenvalues and eigenvectors
                eigenvalues, eigenvectors = eigh(self.density_matrix)
                
                # Sort in descending order
                idx = eigenvalues.argsort()[::-1]
                eigenvalues = eigenvalues[idx]
                eigenvectors = eigenvectors[:, idx]
                
                self.eigenvalues = eigenvalues
                self.eigenvectors = eigenvectors
            except Exception as e:
                st.error(f"Error calculating eigendecomposition: {str(e)}")
                self.eigenvalues = None
                self.eigenvectors = None
        else:
            self.eigenvalues = None
            self.eigenvectors = None
    
    def predict_price_movements(self, assets=None, time_horizon=24):
        """
        Predict price movements based on the quantum state representation
        
        Args:
            assets: List of assets to predict prices for (defaults to all)
            time_horizon: Time horizon for prediction in hours
            
        Returns:
            Dictionary of predictions for each asset
        """
        if assets is None:
            assets = list(self.quantum_state.keys())
        
        predictions = {}
        
        for asset in assets:
            if asset not in self.quantum_state:
                continue
            
            try:
                # Get quantum state features
                state = self.quantum_state[asset]
                
                # Quantum-inspired prediction algorithm
                # 1. Calculate expected return based on momentum and RSI
                momentum_signal = 1 if state['momentum'] > 0 else -1
                rsi_signal = 1 if state['rsi'] < 0.3 else (-1 if state['rsi'] > 0.7 else 0)
                
                # 2. Consider recent returns trend
                recent_returns = state['returns']
                returns_trend = np.mean(recent_returns) if len(recent_returns) > 0 else 0
                
                # 3. Apply quantum interference effect (combine signals with phase relationships)
                # This simulates quantum interference where probability amplitudes can add or cancel
                interference_factor = 0.5 + 0.5 * np.cos(np.pi * state['rsi'])
                
                # 4. Calculate predicted direction and magnitude
                base_direction = momentum_signal * 0.3 + rsi_signal * 0.3 + np.sign(returns_trend) * 0.4
                direction = base_direction * interference_factor
                
                # 5. Apply quantum entanglement effect (if available)
                # This considers correlations between assets from the density matrix
                entanglement_factor = 1.0
                if self.eigenvalues is not None and self.eigenvectors is not None:
                    asset_idx = list(self.quantum_state.keys()).index(asset) if asset in self.quantum_state else -1
                    if asset_idx >= 0 and asset_idx < len(self.eigenvectors):
                        # Use first eigenvector (market mode) contribution
                        market_exposure = abs(self.eigenvectors[asset_idx, 0])
                        market_direction = np.sign(self.eigenvectors[asset_idx, 0])
                        
                        # Apply entanglement effect
                        entanglement_factor = 1.0 + market_exposure * market_direction * 0.5
                
                # 6. Calculate expected return
                volatility_scale = 1.0 + state['volatility'] * 10  # Scale by volatility
                expected_hourly_return = direction * 0.001 * volatility_scale * entanglement_factor
                expected_return = expected_hourly_return * time_horizon
                
                # 7. Calculate confidence based on quantum state purity
                # Purer states (less entropy) give higher confidence
                entropy_factor = state['volatility'] * 5
                confidence = max(0.3, min(0.9, 1.0 - entropy_factor))
                
                # Store prediction
                predictions[asset] = {
                    'direction': direction,
                    'expected_return': expected_return * 100,  # Convert to percentage
                    'confidence': confidence,
                    'time_horizon': time_horizon
                }
                
            except Exception as e:
                st.error(f"Error predicting price movement for {asset}: {str(e)}")
        
        return predictions
    
    def get_market_eigenvalues(self):
        """
        Get the market eigenvalues and eigenvectors
        
        Returns:
            Dictionary with eigenvalues and eigenvectors
        """
        if self.eigenvalues is None or self.eigenvectors is None:
            return None
        
        # Get asset names
        assets = list(self.quantum_state.keys())
        
        # Format eigenvalues
        formatted_eigenvalues = [{
            'value': float(val),
            'explained_variance': float(val) / sum(self.eigenvalues),
            'eigenvector': {
                asset: float(self.eigenvectors[i, j]) 
                for i, asset in enumerate(assets)
            }
        } for j, val in enumerate(self.eigenvalues)]
        
        return {
            'eigenvalues': formatted_eigenvalues,
            'assets': assets,
            'timestamp': datetime.now().isoformat()
        }
    
    def get_entanglement_measure(self, asset1, asset2):
        """
        Calculate quantum entanglement measure between two assets
        
        Args:
            asset1: First asset symbol
            asset2: Second asset symbol
            
        Returns:
            Entanglement measure (0-1 scale)
        """
        if asset1 not in self.quantum_state or asset2 not in self.quantum_state:
            return 0
        
        if self.density_matrix is None:
            return 0
        
        try:
            # Get indices in density matrix
            assets = list(self.quantum_state.keys())
            idx1 = assets.index(asset1)
            idx2 = assets.index(asset2)
            
            # Get the correlation value
            correlation = abs(self.density_matrix[idx1, idx2])
            
            # Apply non-linear transformation to emphasize strong correlations
            entanglement = correlation ** 0.5
            
            return float(entanglement)
        except Exception as e:
            st.error(f"Error calculating entanglement: {str(e)}")
            return 0
