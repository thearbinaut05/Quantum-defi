"""
Quantum Market Model

This module provides quantum-inspired market modeling functions for simulating
and predicting cryptocurrency market movements using quantum mechanics principles.
"""

import streamlit as st
import numpy as np
import pandas as pd
import random
from datetime import datetime, timedelta

# Creator's Ethereum address for receiving all profits
CREATOR_ADDRESS = "0xE2Cb20b711b2406167601a22c391E773313DA335"

# Quantum states for different market conditions
QUANTUM_STATES = {
    "BULL": 0,      # Bullish market state
    "BEAR": 1,      # Bearish market state 
    "SIDEWAYS": 2,  # Sideways market state
    "VOLATILE": 3   # Volatile market state
}

# Quantum superposition constants
MAX_COHERENCE = 0.9  # Maximum coherence level
BASE_DECOHERENCE_RATE = 0.05  # Base rate of decoherence per time step

class QuantumAsset:
    """Represents a cryptocurrency asset using quantum-inspired properties"""
    
    def __init__(self, symbol, current_price, volatility=0.05, quantum_state=None):
        """
        Initialize a quantum asset
        
        Args:
            symbol: Asset symbol
            current_price: Current price in USD
            volatility: Base volatility (standard deviation of price movements)
            quantum_state: Initial quantum state (if None, will be in superposition)
        """
        self.symbol = symbol
        self.current_price = current_price
        self.volatility = volatility
        
        # Quantum properties
        self.state_vector = np.zeros(len(QUANTUM_STATES))
        
        if quantum_state is None:
            # Initialize in superposition of states
            self.state_vector = np.random.random(len(QUANTUM_STATES))
            self.state_vector = self.state_vector / np.sum(self.state_vector)  # Normalize
        else:
            # Initialize in specified state
            self.state_vector[quantum_state] = 1.0
        
        # Quantum entanglement coefficients (with other assets)
        self.entanglement = {}
        
        # Price history
        self.price_history = []
        
        # Coherence (quantum property representing price stability)
        self.coherence = random.uniform(0.4, MAX_COHERENCE)
        
        # Last updated
        self.last_updated = datetime.now()
    
    def get_state(self):
        """Get the current quantum state"""
        # Return the most probable state
        return np.argmax(self.state_vector)
    
    def get_state_probabilities(self):
        """Get the probabilities of each state"""
        return self.state_vector
    
    def apply_market_operator(self, operator_matrix):
        """
        Apply a quantum operator to modify the state
        
        Args:
            operator_matrix: The operator to apply (matrix)
        """
        # Apply the operator
        self.state_vector = np.dot(operator_matrix, self.state_vector)
        
        # Normalize if needed
        norm = np.sum(self.state_vector)
        if norm > 0:
            self.state_vector = self.state_vector / norm
    
    def update_price(self, time_delta=None, market_momentum=0):
        """
        Update the price based on quantum state
        
        Args:
            time_delta: Time delta in seconds since last update
            market_momentum: Overall market momentum (-1 to 1)
            
        Returns:
            New price
        """
        # Calculate time factor
        if time_delta is None:
            now = datetime.now()
            time_delta = (now - self.last_updated).total_seconds()
            self.last_updated = now
        
        # Apply decoherence (quantum noise) based on time passed
        self._apply_decoherence(time_delta)
        
        # Get movement parameters based on quantum state
        bull_prob = self.state_vector[QUANTUM_STATES["BULL"]]
        bear_prob = self.state_vector[QUANTUM_STATES["BEAR"]]
        sideways_prob = self.state_vector[QUANTUM_STATES["SIDEWAYS"]]
        volatile_prob = self.state_vector[QUANTUM_STATES["VOLATILE"]]
        
        # Calculate base price change
        drift = (bull_prob - bear_prob) * 0.01  # -0.01 to 0.01
        
        # Add market momentum
        drift += market_momentum * 0.005  # Additional -0.005 to 0.005
        
        # Volatility adjustment
        vol_factor = 1.0 + (volatile_prob * 2.0) - (sideways_prob * 0.8)
        effective_volatility = self.volatility * vol_factor
        
        # Generate random price movement
        # Using a skewed normal distribution based on quantum states
        noise = np.random.normal(drift, effective_volatility)
        
        # Calculate new price with noise
        price_change_pct = drift + noise
        new_price = self.current_price * (1 + price_change_pct)
        
        # Ensure price is positive
        new_price = max(0.000001, new_price)
        
        # Update price
        self.price_history.append((datetime.now(), self.current_price))
        self.current_price = new_price
        
        return new_price
    
    def _apply_decoherence(self, time_delta):
        """
        Apply quantum decoherence to the state vector
        
        Args:
            time_delta: Time delta in seconds
        """
        # Decoherence rate depends on time passed
        decoherence_amount = BASE_DECOHERENCE_RATE * (time_delta / 3600)  # Scale by hours
        
        # Limit decoherence
        decoherence_amount = min(0.5, decoherence_amount)
        
        # Apply decoherence - mix with a random state vector
        if decoherence_amount > 0:
            random_state = np.random.random(len(QUANTUM_STATES))
            random_state = random_state / np.sum(random_state)
            
            self.state_vector = (1 - decoherence_amount) * self.state_vector + decoherence_amount * random_state
            
            # Normalize
            self.state_vector = self.state_vector / np.sum(self.state_vector)
            
            # Update coherence
            self.coherence = max(0.1, self.coherence - (decoherence_amount * 0.2))
    
    def apply_event(self, event_type, magnitude=1.0):
        """
        Apply a market event to the quantum state
        
        Args:
            event_type: Type of event (string)
            magnitude: Event magnitude (0 to 1)
        """
        # Different events have different effects on quantum states
        if event_type == "positive_news":
            # Positive news increases bull state probability
            operator = np.eye(len(QUANTUM_STATES))
            operator[QUANTUM_STATES["BULL"], QUANTUM_STATES["BULL"]] += magnitude * 0.3
            operator[QUANTUM_STATES["BEAR"], QUANTUM_STATES["BEAR"]] -= magnitude * 0.2
            
        elif event_type == "negative_news":
            # Negative news increases bear state probability
            operator = np.eye(len(QUANTUM_STATES))
            operator[QUANTUM_STATES["BEAR"], QUANTUM_STATES["BEAR"]] += magnitude * 0.3
            operator[QUANTUM_STATES["BULL"], QUANTUM_STATES["BULL"]] -= magnitude * 0.2
            
        elif event_type == "market_shock":
            # Market shock increases volatile state probability
            operator = np.eye(len(QUANTUM_STATES))
            operator[QUANTUM_STATES["VOLATILE"], QUANTUM_STATES["VOLATILE"]] += magnitude * 0.5
            operator[QUANTUM_STATES["SIDEWAYS"], QUANTUM_STATES["SIDEWAYS"]] -= magnitude * 0.3
            
        elif event_type == "stabilization":
            # Stabilization increases sideways state probability
            operator = np.eye(len(QUANTUM_STATES))
            operator[QUANTUM_STATES["SIDEWAYS"], QUANTUM_STATES["SIDEWAYS"]] += magnitude * 0.4
            operator[QUANTUM_STATES["VOLATILE"], QUANTUM_STATES["VOLATILE"]] -= magnitude * 0.3
            
        else:
            # Unknown event, use identity operator
            operator = np.eye(len(QUANTUM_STATES))
        
        # Apply the operator
        self.apply_market_operator(operator)
        
        # Adjust coherence based on event
        if event_type == "market_shock":
            self.coherence = max(0.1, self.coherence - (magnitude * 0.3))
        elif event_type == "stabilization":
            self.coherence = min(MAX_COHERENCE, self.coherence + (magnitude * 0.2))

class QuantumMarketModel:
    """Manages quantum assets and their interactions"""
    
    def __init__(self):
        """Initialize the quantum market model"""
        self.assets = {}
        self.market_state = np.zeros(len(QUANTUM_STATES))
        self.market_state = np.random.random(len(QUANTUM_STATES))
        self.market_state = self.market_state / np.sum(self.market_state)
        self.market_coherence = random.uniform(0.5, MAX_COHERENCE)
        self.last_updated = datetime.now()
        
        # Market events queue
        self.events_queue = []
        
        # Market sentiment (ranges from -1 to 1)
        self.market_sentiment = random.uniform(-0.3, 0.3)
        
        # Entanglement matrix between assets
        self.entanglement_matrix = None
    
    def add_asset(self, symbol, current_price, volatility=0.05, quantum_state=None):
        """
        Add a new asset to the model
        
        Args:
            symbol: Asset symbol
            current_price: Current price in USD
            volatility: Base volatility
            quantum_state: Initial quantum state
            
        Returns:
            The added asset
        """
        asset = QuantumAsset(
            symbol=symbol,
            current_price=current_price,
            volatility=volatility,
            quantum_state=quantum_state
        )
        
        self.assets[symbol] = asset
        
        # Update entanglement matrix
        self._update_entanglement_matrix()
        
        return asset
    
    def get_asset(self, symbol):
        """
        Get an asset by symbol
        
        Args:
            symbol: Asset symbol
            
        Returns:
            QuantumAsset or None if not found
        """
        return self.assets.get(symbol)
    
    def queue_event(self, event_type, affected_assets=None, magnitude=1.0, delay=0):
        """
        Queue a market event to be applied
        
        Args:
            event_type: Type of event
            affected_assets: List of affected asset symbols (None for all)
            magnitude: Event magnitude (0 to 1)
            delay: Delay in seconds before applying
        """
        event = {
            "type": event_type,
            "assets": affected_assets,
            "magnitude": magnitude,
            "apply_time": datetime.now() + timedelta(seconds=delay)
        }
        
        self.events_queue.append(event)
    
    def update(self):
        """
        Update all assets and process events
        
        Returns:
            Dict with update statistics
        """
        # Process queued events
        self._process_events()
        
        # Update market state
        now = datetime.now()
        time_delta = (now - self.last_updated).total_seconds()
        self.last_updated = now
        
        # Apply decoherence to market state
        self._apply_market_decoherence(time_delta)
        
        # Calculate market momentum from sentiment and state
        bull_prob = self.market_state[QUANTUM_STATES["BULL"]]
        bear_prob = self.market_state[QUANTUM_STATES["BEAR"]]
        market_momentum = (bull_prob - bear_prob) * self.market_sentiment
        
        # Update each asset
        updated_assets = {}
        
        for symbol, asset in self.assets.items():
            # Apply entanglement effects from other assets
            self._apply_entanglement(asset)
            
            # Update the asset
            new_price = asset.update_price(time_delta, market_momentum)
            
            updated_assets[symbol] = {
                "old_price": asset.price_history[-1][1] if asset.price_history else 0,
                "new_price": new_price,
                "change_pct": ((new_price / asset.price_history[-1][1]) - 1) * 100 if asset.price_history else 0,
                "state": asset.get_state(),
                "coherence": asset.coherence
            }
        
        # Feedback from assets to market state
        self._update_market_state_from_assets()
        
        return {
            "updated_assets": updated_assets,
            "market_state": self.market_state,
            "market_coherence": self.market_coherence,
            "market_sentiment": self.market_sentiment,
            "time_delta": time_delta
        }
    
    def _process_events(self):
        """Process all events in the queue that are due"""
        now = datetime.now()
        remaining_events = []
        
        for event in self.events_queue:
            if event["apply_time"] <= now:
                # Apply this event
                affected_assets = event["assets"] or list(self.assets.keys())
                
                for symbol in affected_assets:
                    if symbol in self.assets:
                        self.assets[symbol].apply_event(event["type"], event["magnitude"])
                
                # Also affect market state
                self._apply_event_to_market(event["type"], event["magnitude"])
            else:
                # Keep this event for later
                remaining_events.append(event)
        
        # Update queue
        self.events_queue = remaining_events
    
    def _update_entanglement_matrix(self):
        """Update the entanglement matrix between assets"""
        n_assets = len(self.assets)
        if n_assets == 0:
            self.entanglement_matrix = None
            return
        
        # Initialize matrix if needed
        if self.entanglement_matrix is None or self.entanglement_matrix.shape[0] != n_assets:
            self.entanglement_matrix = np.eye(n_assets)
            
            # Add random entanglement between assets
            assets_list = list(self.assets.keys())
            for i in range(n_assets):
                for j in range(i+1, n_assets):
                    # Entanglement is symmetric
                    value = random.uniform(0.1, 0.5)
                    self.entanglement_matrix[i, j] = value
                    self.entanglement_matrix[j, i] = value
    
    def _apply_entanglement(self, asset):
        """
        Apply entanglement effects from other assets
        
        Args:
            asset: The asset to update
        """
        if self.entanglement_matrix is None:
            return
        
        assets_list = list(self.assets.keys())
        if asset.symbol not in assets_list:
            return
        
        # Find the index of this asset
        asset_idx = assets_list.index(asset.symbol)
        
        # Create a mixed state based on entanglement
        mixed_state = np.zeros_like(asset.state_vector)
        
        for i, other_symbol in enumerate(assets_list):
            if i != asset_idx:
                other_asset = self.assets[other_symbol]
                entanglement_strength = self.entanglement_matrix[asset_idx, i]
                
                # Mix the states based on entanglement strength
                mixed_state += entanglement_strength * other_asset.state_vector
        
        # Normalize the mixed state
        if np.sum(mixed_state) > 0:
            mixed_state = mixed_state / np.sum(mixed_state)
            
            # Apply the mixed state with a small weight
            asset.state_vector = 0.8 * asset.state_vector + 0.2 * mixed_state
            
            # Normalize again
            asset.state_vector = asset.state_vector / np.sum(asset.state_vector)
    
    def _apply_market_decoherence(self, time_delta):
        """
        Apply decoherence to the market state
        
        Args:
            time_delta: Time delta in seconds
        """
        # Decoherence rate depends on time passed
        decoherence_amount = BASE_DECOHERENCE_RATE * (time_delta / 3600) * 0.5  # Less than for assets
        
        # Limit decoherence
        decoherence_amount = min(0.3, decoherence_amount)
        
        # Apply decoherence - mix with a random state vector
        if decoherence_amount > 0:
            random_state = np.random.random(len(QUANTUM_STATES))
            random_state = random_state / np.sum(random_state)
            
            self.market_state = (1 - decoherence_amount) * self.market_state + decoherence_amount * random_state
            
            # Normalize
            self.market_state = self.market_state / np.sum(self.market_state)
            
            # Update coherence
            self.market_coherence = max(0.1, self.market_coherence - (decoherence_amount * 0.2))
            
            # Slightly drift sentiment
            self.market_sentiment += random.uniform(-0.05, 0.05)
            self.market_sentiment = max(-1.0, min(1.0, self.market_sentiment))
    
    def _apply_event_to_market(self, event_type, magnitude):
        """
        Apply an event to the market state
        
        Args:
            event_type: Type of event
            magnitude: Event magnitude
        """
        # Different events have different effects on market state
        if event_type == "positive_news":
            # Positive news increases bull market probability
            self.market_state[QUANTUM_STATES["BULL"]] += magnitude * 0.2
            self.market_state[QUANTUM_STATES["BEAR"]] -= magnitude * 0.1
            self.market_sentiment += magnitude * 0.2
            
        elif event_type == "negative_news":
            # Negative news increases bear market probability
            self.market_state[QUANTUM_STATES["BEAR"]] += magnitude * 0.2
            self.market_state[QUANTUM_STATES["BULL"]] -= magnitude * 0.1
            self.market_sentiment -= magnitude * 0.2
            
        elif event_type == "market_shock":
            # Market shock increases volatile market probability
            self.market_state[QUANTUM_STATES["VOLATILE"]] += magnitude * 0.3
            self.market_state[QUANTUM_STATES["SIDEWAYS"]] -= magnitude * 0.2
            self.market_coherence = max(0.1, self.market_coherence - (magnitude * 0.3))
            
        elif event_type == "stabilization":
            # Stabilization increases sideways market probability
            self.market_state[QUANTUM_STATES["SIDEWAYS"]] += magnitude * 0.3
            self.market_state[QUANTUM_STATES["VOLATILE"]] -= magnitude * 0.2
            self.market_coherence = min(MAX_COHERENCE, self.market_coherence + (magnitude * 0.2))
        
        # Normalize market state
        self.market_state = np.maximum(0, self.market_state)  # Ensure non-negative
        if np.sum(self.market_state) > 0:
            self.market_state = self.market_state / np.sum(self.market_state)
            
        # Clamp sentiment
        self.market_sentiment = max(-1.0, min(1.0, self.market_sentiment))
    
    def _update_market_state_from_assets(self):
        """Update market state based on individual assets"""
        if not self.assets:
            return
        
        # Compute average state vector weighted by price
        total_price = sum(asset.current_price for asset in self.assets.values())
        if total_price == 0:
            return
        
        avg_state = np.zeros_like(self.market_state)
        for asset in self.assets.values():
            weight = asset.current_price / total_price
            avg_state += weight * asset.state_vector
        
        # Mix market state with average asset state
        self.market_state = 0.9 * self.market_state + 0.1 * avg_state
        
        # Normalize
        self.market_state = self.market_state / np.sum(self.market_state)
        
        # Update market coherence based on asset coherence
        avg_coherence = np.mean([asset.coherence for asset in self.assets.values()])
        self.market_coherence = 0.9 * self.market_coherence + 0.1 * avg_coherence

# Global market model instance
_market_model = None

def get_market_model():
    """
    Get the global market model instance
    
    Returns:
        QuantumMarketModel instance
    """
    global _market_model
    
    if _market_model is None:
        _market_model = QuantumMarketModel()
        
        # Add some default assets
        _market_model.add_asset("ETH", 3000.0, 0.03)
        _market_model.add_asset("BTC", 60000.0, 0.025)
        _market_model.add_asset("LINK", 12.0, 0.04)
        _market_model.add_asset("UNI", 5.0, 0.05)
        _market_model.add_asset("AAVE", 80.0, 0.045)
        
        # Initial update
        _market_model.update()
    
    return _market_model

def update_quantum_market_model():
    """
    Update the quantum market model
    
    Returns:
        Update statistics
    """
    model = get_market_model()
    return model.update()

def get_market_state():
    """
    Get the current market state
    
    Returns:
        Dict with market state information
    """
    model = get_market_model()
    
    # Get state probabilities
    state_probs = {}
    for state_name, state_idx in QUANTUM_STATES.items():
        state_probs[state_name] = model.market_state[state_idx]
    
    # Get most probable state
    most_probable_state = max(state_probs.items(), key=lambda x: x[1])[0]
    
    return {
        "state_probabilities": state_probs,
        "most_probable_state": most_probable_state,
        "coherence": model.market_coherence,
        "sentiment": model.market_sentiment,
        "last_updated": model.last_updated.isoformat()
    }

def get_quantum_assets():
    """
    Get information about all assets in the model
    
    Returns:
        List of asset information dicts
    """
    model = get_market_model()
    
    assets_info = []
    for symbol, asset in model.assets.items():
        # Get state probabilities
        state_probs = {}
        for state_name, state_idx in QUANTUM_STATES.items():
            state_probs[state_name] = asset.state_vector[state_idx]
        
        # Get most probable state
        most_probable_state = max(state_probs.items(), key=lambda x: x[1])[0]
        
        # Get recent price changes
        price_history = asset.price_history[-10:] if asset.price_history else []
        price_changes = []
        
        for i in range(1, len(price_history)):
            prev_time, prev_price = price_history[i-1]
            curr_time, curr_price = price_history[i]
            change_pct = ((curr_price / prev_price) - 1) * 100
            price_changes.append({
                "timestamp": curr_time.isoformat(),
                "price": curr_price,
                "change_pct": change_pct
            })
        
        # Recent change
        recent_change_pct = 0
        if len(price_history) > 1:
            first_time, first_price = price_history[0]
            last_time, last_price = price_history[-1]
            recent_change_pct = ((last_price / first_price) - 1) * 100
        
        # Add to assets info
        assets_info.append({
            "symbol": symbol,
            "current_price": asset.current_price,
            "volatility": asset.volatility,
            "state_probabilities": state_probs,
            "most_probable_state": most_probable_state,
            "coherence": asset.coherence,
            "recent_change_pct": recent_change_pct,
            "price_changes": price_changes,
            "last_updated": asset.last_updated.isoformat()
        })
    
    return assets_info

def simulate_market_event(event_type, affected_assets=None, magnitude=1.0, delay=0):
    """
    Simulate a market event
    
    Args:
        event_type: Type of event ("positive_news", "negative_news", "market_shock", "stabilization")
        affected_assets: List of affected asset symbols (None for all)
        magnitude: Event magnitude (0 to 1)
        delay: Delay in seconds before applying
        
    Returns:
        Event details
    """
    model = get_market_model()
    model.queue_event(event_type, affected_assets, magnitude, delay)
    
    return {
        "event_type": event_type,
        "affected_assets": affected_assets,
        "magnitude": magnitude,
        "delay": delay,
        "queued_at": datetime.now().isoformat(),
        "will_apply_at": (datetime.now() + timedelta(seconds=delay)).isoformat()
    }

def predict_price_movement(symbol, time_horizon_hours=24):
    """
    Predict price movement based on quantum state
    
    Args:
        symbol: Asset symbol
        time_horizon_hours: Time horizon for prediction in hours
        
    Returns:
        Prediction dict
    """
    model = get_market_model()
    asset = model.get_asset(symbol)
    
    if asset is None:
        return {
            "error": f"Asset {symbol} not found",
            "timestamp": datetime.now().isoformat()
        }
    
    # Get state probabilities
    bull_prob = asset.state_vector[QUANTUM_STATES["BULL"]]
    bear_prob = asset.state_vector[QUANTUM_STATES["BEAR"]]
    sideways_prob = asset.state_vector[QUANTUM_STATES["SIDEWAYS"]]
    volatile_prob = asset.state_vector[QUANTUM_STATES["VOLATILE"]]
    
    # Base drift depends on bull vs bear probability
    base_drift = (bull_prob - bear_prob) * 0.1 * time_horizon_hours
    
    # Adjust for market sentiment
    base_drift += model.market_sentiment * 0.05 * time_horizon_hours
    
    # Calculate expected volatility
    expected_volatility = asset.volatility * (1.0 + volatile_prob - sideways_prob) * np.sqrt(time_horizon_hours / 24)
    
    # Calculate prediction intervals
    predicted_price = asset.current_price * (1 + base_drift)
    lower_bound_90 = asset.current_price * (1 + base_drift - 1.645 * expected_volatility)
    upper_bound_90 = asset.current_price * (1 + base_drift + 1.645 * expected_volatility)
    
    # Most likely direction
    if base_drift > 0.02:
        direction = "Strongly Bullish"
    elif base_drift > 0:
        direction = "Mildly Bullish"
    elif base_drift < -0.02:
        direction = "Strongly Bearish"
    elif base_drift < 0:
        direction = "Mildly Bearish"
    else:
        direction = "Sideways"
    
    # Confidence score
    confidence = 0.5 + (asset.coherence * 0.5) - (volatile_prob * 0.2)
    
    return {
        "symbol": symbol,
        "current_price": asset.current_price,
        "time_horizon_hours": time_horizon_hours,
        "predicted_price": predicted_price,
        "lower_bound_90": lower_bound_90,
        "upper_bound_90": upper_bound_90,
        "expected_volatility": expected_volatility,
        "direction": direction,
        "base_drift": base_drift,
        "confidence": confidence,
        "quantum_coherence": asset.coherence,
        "timestamp": datetime.now().isoformat(),
        "creator_address": CREATOR_ADDRESS
    }