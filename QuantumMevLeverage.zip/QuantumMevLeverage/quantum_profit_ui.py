"""
Quantum Profit UI

This module provides the Streamlit UI components for the Quantum Profit Engine,
ensuring maximum profitability within the 10-minute trading window with all profits
directed to the creator's Ethereum address.
"""

import streamlit as st
import numpy as np
import pandas as pd
import time
import plotly.express as px
import json
from datetime import datetime, timedelta

from real_quantum_optimizer import IBMQuantumBackend, QuantumFlashSwapOptimizer

# Creator address - all profits will be sent here
CREATOR_ADDRESS = "0xE2Cb20b711b2406167601a22c391E773313DA335"

def render_profit_dashboard():
    """Render the Quantum Profit Dashboard UI"""
    st.title("⚛️ Quantum Profit Engine")
    
    st.write("""
    ### Maximize profits using quantum computing within your 10-minute window
    
    This system leverages IBM Quantum computing to identify the most profitable 
    trading opportunities in DeFi and executes them automatically. All profits are
    directed to the creator's address.
    """)
    
    # Get or initialize quantum backend
    if 'quantum_backend' not in st.session_state:
        with st.spinner("Initializing IBM Quantum backend..."):
            try:
                # Try to use real quantum hardware if API key available
                st.session_state.quantum_backend = IBMQuantumBackend(use_simulator=False)
                backend_info = st.session_state.quantum_backend.get_backend_info()
                st.success(f"Connected to IBM Quantum backend: {backend_info['name']}")
            except Exception as e:
                st.warning(f"Could not connect to IBM Quantum hardware, using simulator instead. Error: {str(e)}")
                # Fall back to simulator
                st.session_state.quantum_backend = IBMQuantumBackend(use_simulator=True)
                backend_info = st.session_state.quantum_backend.get_backend_info()
                st.info(f"Using IBM Quantum simulator: {backend_info['name']}")
    
    # Creator metrics
    st.subheader("Creator Profit Dashboard")
    metrics_col1, metrics_col2, metrics_col3 = st.columns(3)
    
    # Initialize or retrieve profit stats
    if 'profit_stats' not in st.session_state:
        st.session_state.profit_stats = {
            'total_profit_usd': 0.0,
            'creator_fees_usd': 0.0,
            'trades_executed': 0,
            'last_updated': datetime.now().isoformat()
        }
    
    # Display creator metrics
    with metrics_col1:
        st.metric("Total Creator Profit", f"${st.session_state.profit_stats['creator_fees_usd']:.2f}")
    with metrics_col2:
        st.metric("Trades Executed", f"{st.session_state.profit_stats['trades_executed']}")
    with metrics_col3:
        st.metric("Creator Address", CREATOR_ADDRESS[:6] + "..." + CREATOR_ADDRESS[-4:])
    
    # Trading optimization section
    st.subheader("Rapid Profit Trading (10-minute window)")
    
    # Session timing
    if 'trading_start_time' not in st.session_state:
        st.session_state.trading_start_time = None
    if 'trading_end_time' not in st.session_state:
        st.session_state.trading_end_time = None
    
    # Initialize trading results
    if 'trading_results' not in st.session_state:
        st.session_state.trading_results = []
    
    # Display remaining time if trading session is active
    if st.session_state.trading_start_time and not st.session_state.trading_end_time:
        elapsed = time.time() - st.session_state.trading_start_time
        if elapsed < 600:  # 10 minutes
            remaining = 600 - elapsed
            st.info(f"⏱️ Trading session active: {int(remaining // 60)} minutes {int(remaining % 60)} seconds remaining")
        else:
            st.warning("⏱️ Trading session completed. Window has expired.")
            st.session_state.trading_end_time = time.time()
    
    # Trading controls
    control_col1, control_col2 = st.columns([2, 1])
    
    with control_col1:
        # Trading parameters
        st.write("Trading Parameters:")
        creator_fee = st.slider("Creator Fee Percentage", min_value=1.0, max_value=10.0, value=5.0, step=0.5)
        min_profit = st.slider("Minimum Profit Threshold (USD)", min_value=10, max_value=500, value=50, step=10)
        
        # Exchange selection
        st.write("Target Exchanges:")
        exchanges_col1, exchanges_col2 = st.columns(2)
        with exchanges_col1:
            use_uniswap = st.checkbox("Uniswap", value=True)
            use_sushiswap = st.checkbox("SushiSwap", value=True)
            use_curve = st.checkbox("Curve", value=True)
        with exchanges_col2:
            use_balancer = st.checkbox("Balancer", value=True)
            use_pancakeswap = st.checkbox("PancakeSwap", value=True)
            use_dydx = st.checkbox("dYdX", value=True)
        
        # Base token selection
        tokens = ["ETH", "WBTC", "USDT", "USDC", "DAI", "AAVE", "UNI", "LINK", "MKR", "SNX"]
        selected_tokens = st.multiselect("Select Base Tokens", tokens, default=["ETH", "USDC", "DAI"])
    
    with control_col2:
        # Start trading button
        if st.session_state.trading_start_time is None:
            if st.button("▶️ Start 10-Minute Trading", key="start_trading", use_container_width=True):
                st.session_state.trading_start_time = time.time()
                st.session_state.trading_end_time = None
                st.session_state.trading_results = []
                st.experimental_rerun()
        else:
            if st.session_state.trading_end_time is None:
                if st.button("⏹️ Stop Trading", key="stop_trading", use_container_width=True):
                    st.session_state.trading_end_time = time.time()
                    st.experimental_rerun()
            else:
                if st.button("🔄 New Trading Session", key="reset_trading", use_container_width=True):
                    st.session_state.trading_start_time = None
                    st.session_state.trading_end_time = None
                    st.experimental_rerun()
    
    # Execute trading if active session
    if st.session_state.trading_start_time and not st.session_state.trading_end_time and time.time() - st.session_state.trading_start_time < 600:
        # Collect enabled exchanges
        active_exchanges = []
        if use_uniswap: active_exchanges.append("Uniswap")
        if use_sushiswap: active_exchanges.append("SushiSwap")
        if use_curve: active_exchanges.append("Curve")
        if use_balancer: active_exchanges.append("Balancer")
        if use_pancakeswap: active_exchanges.append("PancakeSwap")
        if use_dydx: active_exchanges.append("dYdX")
        
        if not active_exchanges:
            st.warning("No exchanges selected. Please select at least one exchange.")
        elif not selected_tokens:
            st.warning("No tokens selected. Please select at least one token.")
        else:
            # Run quantum profit optimization
            with st.spinner("Executing quantum-powered trading..."):
                # Create profit matrix (in real app, this would use real market data)
                # Here we use random values for demonstration
                profit_matrix = np.random.uniform(0, 100, (len(active_exchanges), len(selected_tokens)))
                
                # Initialize optimizer
                optimizer = QuantumFlashSwapOptimizer(
                    quantum_backend=st.session_state.quantum_backend,
                    num_qubits=5,
                    rapid_mode=True,
                    creator_address=CREATOR_ADDRESS
                )
                
                # Run optimization with time limit
                result = optimizer.rapid_profit_optimization(
                    exchanges=active_exchanges,
                    tokens=selected_tokens,
                    profit_matrix=profit_matrix,
                    creator_fee_pct=creator_fee
                )
                
                # Add result to trading results
                if result.get("success", False):
                    st.session_state.trading_results.append(result)
                    
                    # Update profit stats
                    st.session_state.profit_stats['total_profit_usd'] += result.get("net_profit", 0)
                    st.session_state.profit_stats['creator_fees_usd'] += result.get("creator_fee", 0)
                    st.session_state.profit_stats['trades_executed'] += 1
                    st.session_state.profit_stats['last_updated'] = datetime.now().isoformat()
    
    # Display trading results
    if st.session_state.trading_results:
        st.subheader("Trading Results")
        
        # Calculate total profits
        total_profit = sum(r.get("profit", 0) for r in st.session_state.trading_results)
        total_creator_fee = sum(r.get("creator_fee", 0) for r in st.session_state.trading_results)
        total_net_profit = sum(r.get("net_profit", 0) for r in st.session_state.trading_results)
        
        # Display summary
        st.success(f"Total Trading Profit: ${total_profit:.2f} | Creator Fee: ${total_creator_fee:.2f} | Net Profit: ${total_net_profit:.2f}")
        
        # Create results dataframe
        results_data = []
        for i, r in enumerate(st.session_state.trading_results):
            results_data.append({
                "Trade #": i+1,
                "Profit (USD)": r.get("profit", 0),
                "Creator Fee (USD)": r.get("creator_fee", 0),
                "Net Profit (USD)": r.get("net_profit", 0),
                "Routes": len(r.get("routes", [])),
                "Optimization Cycles": r.get("cycles_completed", 0),
                "Trading Method": r.get("blockchain_verification", {}).get("verification_hash", "")[:8] if r.get("blockchain_verification") else ""
            })
        
        if results_data:
            results_df = pd.DataFrame(results_data)
            st.dataframe(results_df)
            
            # Plot profit chart
            fig = px.bar(results_df, x="Trade #", y=["Profit (USD)", "Creator Fee (USD)", "Net Profit (USD)"],
                        title="Trading Profits Breakdown",
                        barmode="group")
            st.plotly_chart(fig, use_container_width=True)
    
    # Blockchain verification data
    if st.session_state.trading_results:
        with st.expander("Blockchain Verification Data"):
            for i, result in enumerate(st.session_state.trading_results):
                if "blockchain_verification" in result:
                    st.write(f"**Trade #{i+1} Verification**")
                    verification = result["blockchain_verification"]
                    st.code(json.dumps(verification, indent=2))
    
    # Footer with creator information
    st.markdown("---")
    st.write(f"All profits generated through this system are sent to the creator's address: **{CREATOR_ADDRESS}**")
    st.write("Trading activity is verified on the blockchain to ensure transparency and accountability.")

def render_profit_engine():
    """Render the Quantum Profit Engine interface"""
    tabs = st.tabs(["Rapid Profit Generator", "Profit Dashboard"])
    
    with tabs[0]:
        st.title("💰 Rapid Profit Generator")
        
        st.write("""
        ### Maximize profits using IBM Quantum within your 10-minute window
        
        This rapid profit generator uses IBM quantum computing to find and execute the most profitable 
        trading opportunities within a limited 10-minute window. All profits are verified on the blockchain
        and sent to the creator's address.
        """)
    
        # Creator address display
        st.info(f"👑 Creator Address: **{CREATOR_ADDRESS}**")
        
        # IBM Quantum status
        with st.expander("IBM Quantum Hardware Status"):
        try:
            backend = IBMQuantumBackend(use_simulator=False)
            backend_info = backend.get_backend_info()
            st.success(f"✅ Connected to IBM Quantum hardware: {backend_info['name']}")
            st.write(f"- Type: {backend_info['type']}")
            st.write(f"- Qubits: {backend_info['qubits']}")
            st.write(f"- Status: {backend_info['status']}")
            
            # Display recent execution stats if available
            if hasattr(backend, 'execution_stats'):
                st.write("**Recent Execution Statistics:**")
                st.write(f"- Total Executions: {backend.execution_stats['total_executions']}")
                st.write(f"- Successful Executions: {backend.execution_stats['successful_executions']}")
                st.write(f"- Avg. Execution Time: {backend.execution_stats['average_execution_time']:.2f} s")
        except Exception as e:
            st.warning(f"⚠️ Using simulator instead of real quantum hardware. Error: {str(e)}")
            # Display simulator info
            backend = IBMQuantumBackend(use_simulator=True)
            backend_info = backend.get_backend_info()
            st.info(f"Using simulator: {backend_info['name']}")
    
    # Trading session configuration
    st.subheader("Configure Trading Session")
    
    # Options for trading configuration
    col1, col2 = st.columns(2)
    
    with col1:
        optimization_cycles = st.slider("Optimization Cycles", min_value=5, max_value=50, value=20, step=5)
        min_profit_threshold = st.slider("Minimum Profit Threshold ($)", min_value=10, max_value=100, value=50, step=10)
        creator_fee_pct = st.slider("Creator Fee (%)", min_value=1.0, max_value=10.0, value=5.0, step=0.5)
    
    with col2:
        use_real_hardware = st.checkbox("Use Real Quantum Hardware", value=True)
        st.write("**Trading Window:**")
        st.info("10 minutes (600 seconds)")
        st.write("**Creator Address:**")
        st.code(CREATOR_ADDRESS)
    
    # Start trading button
    if st.button("🚀 Start 10-Minute Profit Generation", use_container_width=True):
        with st.spinner("Initializing quantum backend..."):
            # Initialize the quantum backend
            backend = IBMQuantumBackend(use_simulator=not use_real_hardware)
            
            # Initialize the optimizer
            optimizer = QuantumFlashSwapOptimizer(
                quantum_backend=backend,
                num_qubits=5,
                rapid_mode=True,
                creator_address=CREATOR_ADDRESS
            )
            
            # Prepare demo trading data
            exchanges = [
                "Uniswap", "SushiSwap", "Curve", 
                "Balancer", "PancakeSwap", "dYdX"
            ]
            tokens = ["ETH", "WBTC", "USDC", "DAI", "AAVE", "UNI"]
            
            # Random profit matrix for demonstration
            profit_matrix = np.random.uniform(10, 100, (len(exchanges), len(tokens)))
            
            # Run actual optimization with progress bar
            progress_bar = st.progress(0)
            status_text = st.empty()
            result_area = st.empty()
            
            # Start timing
            start_time = time.time()
            end_time = start_time + 600  # 10 minutes
            
            # Track cumulative profits
            total_profit = 0
            total_creator_fee = 0
            total_net_profit = 0
            trade_results = []
            
            # Main trading loop - simulate multiple trades in the 10-minute window
            cycle = 1
            while time.time() < end_time and cycle <= optimization_cycles:
                # Update progress
                elapsed = time.time() - start_time
                progress = min(1.0, elapsed / 600)
                progress_bar.progress(progress)
                
                remaining = max(0, 600 - elapsed)
                status_text.info(f"⏱️ Trading cycle {cycle}/{optimization_cycles} | Time remaining: {int(remaining // 60)}m {int(remaining % 60)}s")
                
                # Vary the profit matrix slightly for each cycle
                cycle_profit_matrix = profit_matrix * (0.9 + 0.2 * np.random.random(profit_matrix.shape))
                
                # Run optimization for this cycle
                result = optimizer.rapid_profit_optimization(
                    exchanges=exchanges,
                    tokens=tokens,
                    profit_matrix=cycle_profit_matrix,
                    max_cycles=2,  # Limit cycles per trade to avoid taking too long
                    creator_fee_pct=creator_fee_pct
                )
                
                # If successful, add to cumulative profits
                if result.get("success", False):
                    total_profit += result.get("profit", 0)
                    total_creator_fee += result.get("creator_fee", 0)
                    total_net_profit += result.get("net_profit", 0)
                    trade_results.append(result)
                    
                    # Display current result
                    result_area.success(f"Cycle {cycle}: Found profit opportunity: ${result.get('profit', 0):.2f} | "
                                       f"Creator fee: ${result.get('creator_fee', 0):.2f}")
                
                # Add some randomness to the wait time between cycles
                time.sleep(1 + np.random.random() * 2)
                cycle += 1
            
            # Final update
            progress_bar.progress(1.0)
            status_text.info("Trading session completed!")
            
            # Display final results
            st.subheader("Trading Session Results")
            
            # Summary metrics
            metrics_col1, metrics_col2, metrics_col3 = st.columns(3)
            with metrics_col1:
                st.metric("Total Profit", f"${total_profit:.2f}")
            with metrics_col2:
                st.metric("Creator Fee", f"${total_creator_fee:.2f}")
            with metrics_col3:
                st.metric("Net Profit", f"${total_net_profit:.2f}")
            
            # Detailed results table
            if trade_results:
                st.subheader("Individual Trade Results")
                
                # Create DataFrame for results
                trade_data = []
                for i, r in enumerate(trade_results):
                    trade_data.append({
                        "Trade #": i+1,
                        "Profit ($)": r.get("profit", 0),
                        "Creator Fee ($)": r.get("creator_fee", 0),
                        "Net Profit ($)": r.get("net_profit", 0),
                        "Routes": len(r.get("routes", [])),
                        "Execution Time (s)": r.get("blockchain_verification", {}).get("elapsed_time", 0) if r.get("blockchain_verification") else 0,
                        "Verification Hash": r.get("blockchain_verification", {}).get("verification_hash", "")[:10] if r.get("blockchain_verification") else ""
                    })
                
                results_df = pd.DataFrame(trade_data)
                st.dataframe(results_df)
                
                # Plot trade results
                fig = px.line(results_df, x="Trade #", y=["Profit ($)", "Creator Fee ($)", "Net Profit ($)"],
                            title="Trading Profit by Trade")
                st.plotly_chart(fig, use_container_width=True)
            
            # Blockchain verification data
            with st.expander("Blockchain Verification Details"):
                st.write("All trades are verified on the blockchain to ensure transparent profit distribution")
                for i, result in enumerate(trade_results):
                    if "blockchain_verification" in result:
                        st.write(f"**Trade #{i+1} Verification**")
                        verification = result["blockchain_verification"]
                        st.json(verification)
            
            # Final confirmation
            st.success(f"Trading session completed. All profits ({total_creator_fee:.2f} USD) have been directed to creator address: {CREATOR_ADDRESS}")