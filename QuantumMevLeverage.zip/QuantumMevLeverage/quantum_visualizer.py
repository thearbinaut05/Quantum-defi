"""
Quantum Market Visualizer

This module provides visualization functions for quantum market states,
entanglement patterns, and other quantum-inspired financial visualizations.
"""

import streamlit as st
import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import random
from datetime import datetime, timedelta

# Creator's Ethereum address for receiving all profits
CREATOR_ADDRESS = "0xE2Cb20b711b2406167601a22c391E773313DA335"

# Market state visualization functions
def plot_quantum_probabilities():
    """Plot the quantum probability distribution of market states"""
    # Generate quantum-inspired probabilities for different assets
    assets = ["ETH", "BTC", "LINK", "UNI", "AAVE", "SNX", "YFI", "COMP", "MKR", "SUSHI"]
    states = ["Bullish", "Bearish", "Sideways", "Volatile"]
    
    # Generate random probability data weighted toward recent data
    if 'quantum_prob_data' not in st.session_state:
        data = []
        for asset in assets:
            row = {}
            row['asset'] = asset
            total_prob = 0
            for i, state in enumerate(states[:-1]):
                # Weight probabilities based on asset number (simulating correlation)
                base_prob = 0.1 + 0.15 * np.sin(assets.index(asset) / len(assets) * np.pi * 2)
                prob = max(0.05, min(0.8, base_prob + random.uniform(-0.1, 0.1)))
                total_prob += prob
                row[state] = prob
            # Last state gets the remainder to ensure probabilities sum to 1
            row[states[-1]] = 1 - total_prob
            data.append(row)
        
        st.session_state.quantum_prob_data = pd.DataFrame(data)
    
    # Display the heatmap
    fig = px.imshow(
        st.session_state.quantum_prob_data.set_index('asset')[states],
        labels=dict(x="Market State", y="Asset", color="Probability"),
        x=states,
        y=assets,
        color_continuous_scale="Viridis",
        title="Quantum Market State Probabilities"
    )
    
    # Add annotations with probability values
    for i, asset in enumerate(assets):
        for j, state in enumerate(states):
            value = st.session_state.quantum_prob_data.loc[i, state]
            fig.add_annotation(
                x=state,
                y=asset,
                text=f"{value:.2f}",
                showarrow=False,
                font=dict(color="white" if value > 0.3 else "black")
            )
    
    fig.update_layout(height=500)
    st.plotly_chart(fig, use_container_width=True)

def plot_entanglement_map():
    """Plot the entanglement map between different assets"""
    # Generate random entanglement data for visualization
    assets = ["ETH", "BTC", "LINK", "UNI", "AAVE", "SNX", "YFI", "COMP", "MKR", "SUSHI"]
    n_assets = len(assets)
    
    # Create entanglement matrix if it doesn't exist
    if 'entanglement_matrix' not in st.session_state:
        np.random.seed(42)  # For reproducibility
        # Generate a symmetric matrix with values between 0 and 1
        entanglement = np.zeros((n_assets, n_assets))
        for i in range(n_assets):
            for j in range(i, n_assets):
                if i == j:
                    entanglement[i, j] = 1.0  # Perfect self-entanglement
                else:
                    # Correlations between similar types of assets
                    base_value = 0.2 + 0.6 * np.exp(-abs(i - j) / 3)
                    variation = random.uniform(-0.1, 0.1)
                    entanglement[i, j] = max(0, min(1, base_value + variation))
                    entanglement[j, i] = entanglement[i, j]  # Symmetric matrix
        
        st.session_state.entanglement_matrix = entanglement
    
    # Create heatmap
    fig = px.imshow(
        st.session_state.entanglement_matrix,
        labels=dict(x="Asset", y="Asset", color="Entanglement"),
        x=assets,
        y=assets,
        color_continuous_scale="Viridis",
        title="Quantum Entanglement Map"
    )
    
    # Add annotations with entanglement values
    for i in range(n_assets):
        for j in range(n_assets):
            value = st.session_state.entanglement_matrix[i, j]
            fig.add_annotation(
                x=assets[j],
                y=assets[i],
                text=f"{value:.2f}",
                showarrow=False,
                font=dict(color="white" if value > 0.3 else "black")
            )
    
    fig.update_layout(height=500)
    st.plotly_chart(fig, use_container_width=True)

def plot_position_risk():
    """Plot the position risk matrix based on quantum probabilities"""
    # Generate risk data for different position sizes and assets
    assets = ["ETH", "BTC", "LINK", "UNI", "AAVE"]
    position_sizes = ["Small", "Medium", "Large", "Max"]
    
    # Generate risk matrix if it doesn't exist
    if 'position_risk_matrix' not in st.session_state:
        risk_data = []
        
        for asset in assets:
            row = {}
            row['asset'] = asset
            
            # Base risk factors differ by asset volatility
            base_risks = {
                "ETH": 0.4,
                "BTC": 0.35,
                "LINK": 0.55,
                "UNI": 0.6,
                "AAVE": 0.5
            }
            
            # Size multipliers increase risk with position size
            size_multipliers = {
                "Small": 0.5,
                "Medium": 1.0,
                "Large": 1.8,
                "Max": 3.0
            }
            
            # Calculate risk for each position size
            for size in position_sizes:
                base_risk = base_risks.get(asset, 0.5)
                multiplier = size_multipliers.get(size, 1.0)
                # Add some random variation
                variation = random.uniform(-0.1, 0.1)
                risk = min(1.0, max(0.1, base_risk * multiplier + variation))
                row[size] = risk
            
            risk_data.append(row)
        
        st.session_state.position_risk_matrix = pd.DataFrame(risk_data)
    
    # Display the heatmap
    fig = px.imshow(
        st.session_state.position_risk_matrix.set_index('asset')[position_sizes],
        labels=dict(x="Position Size", y="Asset", color="Risk Level"),
        x=position_sizes,
        y=assets,
        color_continuous_scale="Reds",
        title="Quantum Position Risk Matrix"
    )
    
    # Add annotations with risk values
    for i, asset in enumerate(assets):
        for j, size in enumerate(position_sizes):
            value = st.session_state.position_risk_matrix.loc[i, size]
            fig.add_annotation(
                x=size,
                y=asset,
                text=f"{value:.2f}",
                showarrow=False,
                font=dict(color="white" if value > 0.4 else "black")
            )
    
    fig.update_layout(height=400)
    st.plotly_chart(fig, use_container_width=True)

def plot_entanglement_heatmap():
    """Plot the entanglement heatmap for visualization"""
    # Similar to entanglement_map but with different formatting
    plot_entanglement_map()

def plot_coherence_timeline():
    """Plot the quantum coherence over time"""
    # Generate coherence timeline data
    dates = [datetime.now() - timedelta(days=i) for i in range(30, 0, -1)]
    
    # Generate coherence data if it doesn't exist
    if 'coherence_timeline' not in st.session_state:
        # Base coherence with some weekly periodicity and trend
        base_coherence = [0.5 + 0.1 * np.sin(i / 7 * np.pi) + i / 100 for i in range(30)]
        # Add some random noise
        coherence = [max(0.1, min(0.9, c + random.uniform(-0.05, 0.05))) for c in base_coherence]
        
        # Generate volume data (correlated with coherence changes)
        base_volume = [50 + 10 * abs(coherence[i] - coherence[i-1] if i > 0 else 0) for i in range(30)]
        volume = [v + random.uniform(-5, 5) for v in base_volume]
        
        st.session_state.coherence_timeline = {
            'dates': dates,
            'coherence': coherence,
            'volume': volume
        }
    
    # Create figure with secondary y-axis
    fig = go.Figure()
    
    # Add coherence line
    fig.add_trace(go.Scatter(
        x=st.session_state.coherence_timeline['dates'],
        y=st.session_state.coherence_timeline['coherence'],
        name="Quantum Coherence",
        line=dict(color='rgb(0, 255, 100)', width=2)
    ))
    
    # Add volume bars on secondary y-axis
    fig.add_trace(go.Bar(
        x=st.session_state.coherence_timeline['dates'],
        y=st.session_state.coherence_timeline['volume'],
        name="Market Volume",
        opacity=0.3,
        marker=dict(color='rgb(158, 158, 225)')
    ))
    
    # Set titles and layout
    fig.update_layout(
        title="Quantum Market Coherence Timeline",
        xaxis_title="Date",
        yaxis_title="Coherence",
        hovermode="x unified",
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1),
        height=400
    )
    
    st.plotly_chart(fig, use_container_width=True)

# Performance visualization functions
def plot_flash_swap_performance():
    """Plot flash swap performance by exchange"""
    # Generate flash swap performance data
    exchanges = ["Uniswap V3", "Uniswap V2", "SushiSwap", "Curve", "Balancer"]
    
    # Generate performance data if it doesn't exist
    if 'flash_swap_performance' not in st.session_state:
        # Different base profits for different exchanges
        base_profits = {
            "Uniswap V3": 350,
            "Uniswap V2": 200,
            "SushiSwap": 280,
            "Curve": 420,
            "Balancer": 180
        }
        
        # Generate data with some random variation
        profits = [base_profits.get(exchange, 200) + random.uniform(-50, 50) for exchange in exchanges]
        counts = [random.randint(5, 20) for _ in exchanges]
        
        st.session_state.flash_swap_performance = {
            'exchange': exchanges,
            'profit': profits,
            'count': counts
        }
    
    # Create dataframe
    df = pd.DataFrame({
        'exchange': st.session_state.flash_swap_performance['exchange'],
        'profit': st.session_state.flash_swap_performance['profit'],
        'count': st.session_state.flash_swap_performance['count']
    })
    
    # Create bar chart
    fig = px.bar(
        df, 
        x='exchange', 
        y='profit', 
        title='Flash Swap Profit by Exchange',
        labels={'profit': 'Total Profit (USD)', 'exchange': 'Exchange', 'count': 'Number of Swaps'},
        color='count',
        color_continuous_scale='Viridis',
        text='profit'
    )
    
    fig.update_traces(texttemplate='$%{text:.2f}', textposition='outside')
    fig.update_layout(height=400)
    
    st.plotly_chart(fig, use_container_width=True)

def plot_arbitrage_performance():
    """Plot arbitrage performance by type"""
    # Generate arbitrage performance data
    arb_types = ['Simple', 'Triangular', 'Quantum (2-path)', 'Quantum (3-path)', 'Quantum (4-path)']
    
    # Generate performance data if it doesn't exist
    if 'arbitrage_performance' not in st.session_state:
        # Different base profits for different arbitrage types
        base_profits = {
            'Simple': 150,
            'Triangular': 220,
            'Quantum (2-path)': 280,
            'Quantum (3-path)': 350,
            'Quantum (4-path)': 420
        }
        
        # Generate data with some random variation
        profits = [base_profits.get(arb_type, 200) + random.uniform(-30, 50) for arb_type in arb_types]
        counts = [random.randint(3, 15) for _ in arb_types]
        
        st.session_state.arbitrage_performance = {
            'arbitrage_type': arb_types,
            'profit': profits,
            'count': counts
        }
    
    # Create dataframe
    df = pd.DataFrame({
        'arbitrage_type': st.session_state.arbitrage_performance['arbitrage_type'],
        'profit': st.session_state.arbitrage_performance['profit'],
        'count': st.session_state.arbitrage_performance['count']
    })
    
    # Create bar chart
    fig = px.bar(
        df, 
        x='arbitrage_type', 
        y='profit', 
        title='Arbitrage Profit by Type',
        labels={'profit': 'Total Profit (USD)', 'arbitrage_type': 'Arbitrage Type', 'count': 'Number of Trades'},
        color='count',
        color_continuous_scale='Viridis',
        text='profit'
    )
    
    fig.update_traces(texttemplate='$%{text:.2f}', textposition='outside')
    fig.update_layout(height=400)
    
    st.plotly_chart(fig, use_container_width=True)

def plot_leverage_optimization_heatmap():
    """Plot leverage optimization heatmap"""
    # Generate leverage optimization data
    assets = ["ETH", "BTC", "LINK", "UNI", "AAVE"]
    leverage_levels = ["1x", "2x", "3x", "5x", "10x"]
    
    # Generate optimization data if it doesn't exist
    if 'leverage_optimization' not in st.session_state:
        # Create matrix of expected returns for different leverage levels
        data = []
        
        for asset in assets:
            row = {}
            row['asset'] = asset
            
            # Base returns differ by asset
            base_returns = {
                "ETH": 0.08,
                "BTC": 0.06,
                "LINK": 0.10,
                "UNI": 0.12,
                "AAVE": 0.09
            }
            
            # Leverage efficiency factors (diminishing returns at higher leverage)
            leverage_efficiency = {
                "1x": 1.0,
                "2x": 0.95,
                "3x": 0.85,
                "5x": 0.7,
                "10x": 0.5
            }
            
            # Calculate expected return for each leverage level
            for level in leverage_levels:
                base_return = base_returns.get(asset, 0.07)
                leverage_value = float(level.replace('x', ''))
                efficiency = leverage_efficiency.get(level, 1.0)
                
                # Expected return formula with some random variation
                variation = random.uniform(-0.02, 0.02)
                expected_return = base_return * leverage_value * efficiency + variation
                
                row[level] = expected_return
            
            data.append(row)
        
        st.session_state.leverage_optimization = pd.DataFrame(data)
    
    # Display the heatmap
    fig = px.imshow(
        st.session_state.leverage_optimization.set_index('asset')[leverage_levels],
        labels=dict(x="Leverage Level", y="Asset", color="Expected Return"),
        x=leverage_levels,
        y=assets,
        color_continuous_scale="RdYlGn",
        title="Quantum Leverage Optimization Matrix"
    )
    
    # Add annotations with return values
    for i, asset in enumerate(assets):
        for j, level in enumerate(leverage_levels):
            value = st.session_state.leverage_optimization.loc[i, level]
            fig.add_annotation(
                x=level,
                y=asset,
                text=f"{value:.2f}",
                showarrow=False,
                font=dict(color="black")
            )
    
    fig.update_layout(height=400)
    st.plotly_chart(fig, use_container_width=True)

def plot_mev_activity():
    """Plot MEV activity timeline"""
    # Generate MEV activity data
    days = 14
    dates = [datetime.now() - timedelta(days=i) for i in range(days, 0, -1)]
    
    # Generate MEV data if it doesn't exist
    if 'mev_activity' not in st.session_state:
        # Base values with some periodicity
        base_sandwiches = [10 + 5 * np.sin(i / 3 * np.pi) for i in range(days)]
        base_frontrunning = [15 + 8 * np.cos(i / 4 * np.pi) for i in range(days)]
        base_backrunning = [8 + 3 * np.sin(i / 2 * np.pi + 1) for i in range(days)]
        
        # Add some random variation
        sandwiches = [max(0, int(v + random.uniform(-3, 3))) for v in base_sandwiches]
        frontrunning = [max(0, int(v + random.uniform(-4, 4))) for v in base_frontrunning]
        backrunning = [max(0, int(v + random.uniform(-2, 2))) for v in base_backrunning]
        
        # Calculate protection percentage (how many we protected)
        protection_pct = [random.uniform(0.6, 0.9) for _ in range(days)]
        
        st.session_state.mev_activity = {
            'dates': dates,
            'sandwiches': sandwiches,
            'frontrunning': frontrunning,
            'backrunning': backrunning,
            'protection_pct': protection_pct
        }
    
    # Create figure
    fig = go.Figure()
    
    # Add traces for each MEV type
    fig.add_trace(go.Scatter(
        x=st.session_state.mev_activity['dates'],
        y=st.session_state.mev_activity['sandwiches'],
        name="Sandwich Attacks",
        mode='lines+markers'
    ))
    
    fig.add_trace(go.Scatter(
        x=st.session_state.mev_activity['dates'],
        y=st.session_state.mev_activity['frontrunning'],
        name="Frontrunning",
        mode='lines+markers'
    ))
    
    fig.add_trace(go.Scatter(
        x=st.session_state.mev_activity['dates'],
        y=st.session_state.mev_activity['backrunning'],
        name="Backrunning",
        mode='lines+markers'
    ))
    
    # Add protection percentage line on secondary y-axis
    fig.add_trace(go.Scatter(
        x=st.session_state.mev_activity['dates'],
        y=[p * 100 for p in st.session_state.mev_activity['protection_pct']],
        name="Protection Success %",
        mode='lines+markers',
        line=dict(color='rgb(0, 255, 0)', width=3),
        yaxis="y2"
    ))
    
    # Set up the layout with two y-axes
    fig.update_layout(
        title="MEV Activity and Protection",
        xaxis_title="Date",
        yaxis_title="Number of Attacks",
        yaxis2=dict(
            title="Protection Success %",
            titlefont=dict(color="rgb(0, 255, 0)"),
            tickfont=dict(color="rgb(0, 255, 0)"),
            overlaying="y",
            side="right",
            range=[0, 100]
        ),
        hovermode="x unified",
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1),
        height=400
    )
    
    st.plotly_chart(fig, use_container_width=True)

def plot_portfolio_allocation():
    """Plot current portfolio allocation"""
    # Generate portfolio allocation data
    assets = ["ETH", "BTC", "LINK", "UNI", "AAVE", "SNX", "USDT", "USDC"]
    
    # Generate allocation data if it doesn't exist
    if 'portfolio_allocation' not in st.session_state:
        # Generate random allocation weights that sum to 1
        raw_weights = [random.uniform(0.5, 10) for _ in assets]
        total_weight = sum(raw_weights)
        weights = [w / total_weight for w in raw_weights]
        
        # Calculate USD values based on weights and a total portfolio value
        total_value = random.uniform(100000, 500000)
        values = [w * total_value for w in weights]
        
        st.session_state.portfolio_allocation = {
            'asset': assets,
            'weight': weights,
            'value': values
        }
    
    # Create pie chart
    fig = px.pie(
        names=st.session_state.portfolio_allocation['asset'],
        values=st.session_state.portfolio_allocation['value'],
        title='Current Portfolio Allocation',
        hover_data=['asset'],
        labels={'asset': 'Asset', 'value': 'Value (USD)'},
        color_discrete_sequence=px.colors.qualitative.Plotly
    )
    
    fig.update_traces(textposition='inside', textinfo='percent+label')
    fig.update_layout(height=500)
    
    st.plotly_chart(fig, use_container_width=True)

def plot_optimized_portfolio():
    """Plot optimized portfolio allocation"""
    # Generate optimized portfolio allocation data
    assets = ["ETH", "BTC", "LINK", "UNI", "AAVE", "SNX", "USDT", "USDC"]
    
    # Generate allocation data if it doesn't exist
    if 'optimized_allocation' not in st.session_state:
        # Generate random allocation weights that sum to 1
        raw_weights = [random.uniform(0.5, 10) for _ in assets]
        total_weight = sum(raw_weights)
        weights = [w / total_weight for w in raw_weights]
        
        # Calculate USD values based on weights and a total portfolio value
        total_value = random.uniform(100000, 500000)
        values = [w * total_value for w in weights]
        
        # For comparison with current portfolio
        original = st.session_state.portfolio_allocation['weight'] if 'portfolio_allocation' in st.session_state else [1/len(assets)] * len(assets)
        
        # Calculate change percentage
        changes = [(weights[i] - original[i]) / original[i] * 100 if original[i] > 0 else 0 for i in range(len(assets))]
        
        st.session_state.optimized_allocation = {
            'asset': assets,
            'weight': weights,
            'value': values,
            'change': changes
        }
    
    # Create comparison bar chart
    df = pd.DataFrame({
        'asset': st.session_state.optimized_allocation['asset'],
        'Current': [w * 100 for w in st.session_state.portfolio_allocation['weight']] if 'portfolio_allocation' in st.session_state else [100/len(assets)] * len(assets),
        'Optimized': [w * 100 for w in st.session_state.optimized_allocation['weight']],
        'change': st.session_state.optimized_allocation['change']
    })
    
    # Create grouped bar chart
    fig = go.Figure()
    
    fig.add_trace(go.Bar(
        x=df['asset'],
        y=df['Current'],
        name='Current Allocation',
        marker_color='lightblue'
    ))
    
    fig.add_trace(go.Bar(
        x=df['asset'],
        y=df['Optimized'],
        name='Quantum Optimized',
        marker_color='darkblue'
    ))
    
    # Update layout
    fig.update_layout(
        title='Portfolio Allocation Comparison',
        xaxis_title='Asset',
        yaxis_title='Allocation (%)',
        barmode='group',
        height=400
    )
    
    st.plotly_chart(fig, use_container_width=True)
    
    # Show change summary
    improvement = random.uniform(5, 15)
    risk_reduction = random.uniform(10, 30)
    
    col1, col2 = st.columns(2)
    with col1:
        st.metric("Expected Return Improvement", f"+{improvement:.2f}%")
    with col2:
        st.metric("Risk Reduction", f"-{risk_reduction:.2f}%")