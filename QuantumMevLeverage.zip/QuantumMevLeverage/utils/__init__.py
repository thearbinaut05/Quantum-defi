"""
Utility functions for the Quantum DeFi Protocol
"""

import numpy as np
import pandas as pd
from datetime import datetime, timedelta
import time
import requests
import json
import streamlit as st

def calculate_sharpe_ratio(returns, risk_free_rate=0.01, periods_per_year=365):
    """
    Calculate the Sharpe ratio of a return series
    
    Args:
        returns: Pandas Series or NumPy array of returns
        risk_free_rate: Annual risk-free rate
        periods_per_year: Number of periods in a year (365 for daily, 252 for trading days)
        
    Returns:
        Sharpe ratio
    """
    # Convert annual risk-free rate to per-period rate
    rf_per_period = (1 + risk_free_rate) ** (1 / periods_per_year) - 1
    
    # Calculate excess returns
    excess_returns = returns - rf_per_period
    
    # Calculate Sharpe ratio
    sharpe = np.sqrt(periods_per_year) * excess_returns.mean() / excess_returns.std()
    
    return sharpe

def calculate_sortino_ratio(returns, risk_free_rate=0.01, periods_per_year=365):
    """
    Calculate the Sortino ratio of a return series
    
    Args:
        returns: Pandas Series or NumPy array of returns
        risk_free_rate: Annual risk-free rate
        periods_per_year: Number of periods in a year (365 for daily, 252 for trading days)
        
    Returns:
        Sortino ratio
    """
    # Convert annual risk-free rate to per-period rate
    rf_per_period = (1 + risk_free_rate) ** (1 / periods_per_year) - 1
    
    # Calculate excess returns
    excess_returns = returns - rf_per_period
    
    # Calculate downside deviation (only negative returns contribute)
    downside_returns = excess_returns[excess_returns < 0]
    downside_deviation = np.sqrt(np.sum(downside_returns ** 2) / len(returns))
    
    # Avoid division by zero
    if downside_deviation == 0:
        return np.nan
    
    # Calculate Sortino ratio
    sortino = np.sqrt(periods_per_year) * excess_returns.mean() / downside_deviation
    
    return sortino

def calculate_max_drawdown(returns):
    """
    Calculate the maximum drawdown of a return series
    
    Args:
        returns: Pandas Series or NumPy array of returns
        
    Returns:
        Maximum drawdown as a positive percentage (0-1)
    """
    # Calculate cumulative returns
    cum_returns = (1 + returns).cumprod()
    
    # Calculate running maximum
    running_max = cum_returns.cummax()
    
    # Calculate drawdown
    drawdown = (cum_returns / running_max) - 1
    
    # Get maximum drawdown
    max_drawdown = drawdown.min()
    
    return -max_drawdown  # Return as positive number

def format_address(address, chars=4):
    """
    Format an Ethereum address for display
    
    Args:
        address: Ethereum address as string
        chars: Number of characters to show at start and end
        
    Returns:
        Formatted address string
    """
    if not address:
        return ""
    
    return f"{address[:chars]}...{address[-chars:]}"

def format_number(num, precision=2):
    """
    Format a number with appropriate suffix (K, M, B)
    
    Args:
        num: Number to format
        precision: Number of decimal places
        
    Returns:
        Formatted number as string
    """
    if num is None:
        return "N/A"
    
    if abs(num) >= 1e9:
        return f"{num / 1e9:.{precision}f}B"
    elif abs(num) >= 1e6:
        return f"{num / 1e6:.{precision}f}M"
    elif abs(num) >= 1e3:
        return f"{num / 1e3:.{precision}f}K"
    else:
        return f"{num:.{precision}f}"

def calculate_fibonacci_levels(high_price, low_price):
    """
    Calculate Fibonacci retracement levels
    
    Args:
        high_price: Highest price in the range
        low_price: Lowest price in the range
        
    Returns:
        Dictionary of Fibonacci levels
    """
    price_range = high_price - low_price
    
    fibonacci_levels = {
        '0': low_price,
        '0.236': low_price + 0.236 * price_range,
        '0.382': low_price + 0.382 * price_range,
        '0.5': low_price + 0.5 * price_range,
        '0.618': low_price + 0.618 * price_range,
        '0.786': low_price + 0.786 * price_range,
        '1': high_price
    }
    
    return fibonacci_levels

def calculate_quantum_entropy(data_series):
    """
    Calculate quantum-inspired entropy measure for a data series
    
    Args:
        data_series: Pandas Series or NumPy array of values
        
    Returns:
        Quantum entropy value
    """
    # Normalize data to 0-1 range
    if len(data_series) == 0:
        return 0
    
    min_val = min(data_series)
    max_val = max(data_series)
    
    if max_val == min_val:
        return 0
    
    normalized = [(x - min_val) / (max_val - min_val) for x in data_series]
    
    # Calculate probabilities (quantum amplitudes squared)
    sum_squared = sum([x * x for x in normalized])
    
    if sum_squared == 0:
        return 0
    
    probabilities = [(x * x) / sum_squared for x in normalized]
    
    # Calculate Shannon entropy
    entropy = -sum([p * np.log2(p) if p > 0 else 0 for p in probabilities])
    
    return entropy

def format_currency(amount):
    """Format a monetary amount with appropriate prefix"""
    if abs(amount) >= 1_000_000:
        return f"${amount/1_000_000:.2f}M"
    elif abs(amount) >= 1_000:
        return f"${amount/1_000:.2f}K"
    else:
        return f"${amount:.2f}"