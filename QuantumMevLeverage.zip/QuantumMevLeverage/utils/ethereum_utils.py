"""
Ethereum Blockchain Utilities

This module provides utilities for interacting with the Ethereum blockchain network
through Infura API.
"""

import os
import json
import requests
from web3 import Web3
from eth_account import Account

# Define supported networks for easy configuration
NETWORKS = {
    "mainnet": {
        "name": "Ethereum Mainnet",
        "chain_id": 1,
        "infura_network": "mainnet"
    },
    "goerli": {
        "name": "Goerli Testnet",
        "chain_id": 5,
        "infura_network": "goerli"
    },
    "sepolia": {
        "name": "Sepolia Testnet",
        "chain_id": 11155111,
        "infura_network": "sepolia"
    }
}

# ABI for ERC20 token contract (only methods we need)
ERC20_ABI = [
    {
        "constant": True,
        "inputs": [{"name": "owner", "type": "address"}],
        "name": "balanceOf",
        "outputs": [{"name": "", "type": "uint256"}],
        "payable": False,
        "stateMutability": "view",
        "type": "function"
    },
    {
        "constant": True,
        "inputs": [],
        "name": "decimals",
        "outputs": [{"name": "", "type": "uint8"}],
        "payable": False,
        "stateMutability": "view",
        "type": "function"
    },
    {
        "constant": True,
        "inputs": [],
        "name": "symbol",
        "outputs": [{"name": "", "type": "string"}],
        "payable": False,
        "stateMutability": "view",
        "type": "function"
    }
]

def get_web3_connection(network="mainnet"):
    """
    Get a Web3 connection to Ethereum network via Infura
    
    Args:
        network: Network to connect to (mainnet, goerli, sepolia)
        
    Returns:
        Web3 connection object
    """
    # Get network info
    network_info = NETWORKS.get(network, NETWORKS["mainnet"])
    
    # Get Infura API key from environment variables
    infura_api_key = os.environ.get("INFURA_API_KEY")
    
    if infura_api_key:
        provider_url = f"https://{network_info['infura_network']}.infura.io/v3/{infura_api_key}"
    else:
        # Fallback to public endpoint (not recommended for production)
        provider_url = f"https://{network_info['infura_network']}.infura.io/v3/"
    
    # Create connection
    w3 = Web3(Web3.HTTPProvider(provider_url))
    
    return w3

def get_eth_balance(address, w3=None, network="mainnet"):
    """
    Get ETH balance for an address
    
    Args:
        address: Ethereum address
        w3: Web3 connection (optional)
        network: Network to use (if w3 not provided)
        
    Returns:
        Balance in ETH
    """
    if w3 is None:
        w3 = get_web3_connection(network)
    
    try:
        # Check if address is valid
        if not w3.is_address(address):
            return 0
        
        # Get balance in wei
        balance_wei = w3.eth.get_balance(address)
        
        # Convert to ETH
        balance_eth = w3.from_wei(balance_wei, 'ether')
        
        return balance_eth
    except Exception as e:
        print(f"Error getting ETH balance: {str(e)}")
        return 0
    
def get_token_balance(token_address, wallet_address, w3=None, network="mainnet"):
    """
    Get ERC20 token balance for an address
    
    Args:
        token_address: ERC20 token contract address
        wallet_address: Wallet address to check balance for
        w3: Web3 connection (optional)
        network: Network to use (if w3 not provided)
        
    Returns:
        Dict with token balance, symbol, and decimals
    """
    if w3 is None:
        w3 = get_web3_connection(network)
    
    try:
        # Check if addresses are valid
        if not w3.is_address(token_address) or not w3.is_address(wallet_address):
            return {"balance": 0, "symbol": "UNKNOWN", "decimals": 18}
        
        # Create contract instance
        token_contract = w3.eth.contract(address=token_address, abi=ERC20_ABI)
        
        # Get token info
        try:
            symbol = token_contract.functions.symbol().call()
        except:
            symbol = "UNKNOWN"
        
        try:
            decimals = token_contract.functions.decimals().call()
        except:
            decimals = 18
        
        # Get raw balance
        raw_balance = token_contract.functions.balanceOf(wallet_address).call()
        
        # Format balance using decimals
        balance = raw_balance / (10 ** decimals)
        
        return {
            "balance": balance,
            "symbol": symbol,
            "decimals": decimals,
            "raw_balance": raw_balance
        }
    except Exception as e:
        print(f"Error getting token balance: {str(e)}")
        return {"balance": 0, "symbol": "ERROR", "decimals": 18}

def get_gas_price(w3=None, network="mainnet"):
    """
    Get current gas price
    
    Args:
        w3: Web3 connection (optional)
        network: Network to use (if w3 not provided)
        
    Returns:
        Dict with gas prices in Gwei
    """
    if w3 is None:
        w3 = get_web3_connection(network)
    
    try:
        # Get basic gas price
        gas_price_wei = w3.eth.gas_price
        gas_price_gwei = w3.from_wei(gas_price_wei, 'gwei')
        
        # For EIP-1559 compatible networks, get fee suggestions
        try:
            fee_data = w3.eth.fee_history(1, 'latest', [25, 50, 75])
            base_fee = w3.from_wei(fee_data.base_fee_per_gas[-1], 'gwei')
            
            # Estimate priority fees
            priority_fees = []
            for percentile in fee_data.reward:
                if percentile:
                    priority_fees.append(w3.from_wei(percentile[0], 'gwei'))
            
            # Calculate suggested max fees
            if priority_fees:
                suggested_max_fee = base_fee * 1.25 + priority_fees[1]
            else:
                suggested_max_fee = gas_price_gwei * 1.1
            
            return {
                "gas_price_gwei": gas_price_gwei,
                "gas_price_wei": gas_price_wei,
                "base_fee_gwei": base_fee,
                "priority_fee_gwei": priority_fees[1] if len(priority_fees) > 1 else 1,
                "suggested_max_fee_gwei": suggested_max_fee
            }
        except:
            # Fallback for non-EIP-1559 networks
            return {
                "gas_price_gwei": gas_price_gwei,
                "gas_price_wei": gas_price_wei,
                "suggested_max_fee_gwei": gas_price_gwei * 1.1
            }
    except Exception as e:
        print(f"Error getting gas price: {str(e)}")
        return {"gas_price_gwei": 50, "gas_price_wei": 50000000000}

def sign_transaction(tx, private_key, w3=None, network="mainnet"):
    """
    Sign a transaction with private key
    
    Args:
        tx: Transaction dict
        private_key: Private key for signing
        w3: Web3 connection (optional)
        network: Network to use (if w3 not provided)
        
    Returns:
        Signed transaction
    """
    if w3 is None:
        w3 = get_web3_connection(network)
    
    try:
        # Create account from private key
        account = Account.from_key(private_key)
        
        # Ensure from address matches private key
        if 'from' in tx and tx['from'].lower() != account.address.lower():
            raise ValueError("Transaction 'from' address doesn't match private key")
        
        # Set the from address if not already in tx
        if 'from' not in tx:
            tx['from'] = account.address
        
        # Sign transaction
        signed_tx = w3.eth.account.sign_transaction(tx, private_key)
        
        return signed_tx
    except Exception as e:
        print(f"Error signing transaction: {str(e)}")
        return None

def send_transaction(tx_data, w3=None, network="mainnet"):
    """
    Send a raw signed transaction
    
    Args:
        tx_data: Signed transaction object or raw hex data
        w3: Web3 connection (optional)
        network: Network to use (if w3 not provided)
        
    Returns:
        Transaction hash
    """
    if w3 is None:
        w3 = get_web3_connection(network)
    
    try:
        # Handle different input types
        if hasattr(tx_data, 'rawTransaction'):
            # This is a signed transaction object
            raw_tx = tx_data.rawTransaction
        elif isinstance(tx_data, str) and tx_data.startswith('0x'):
            # This is a raw hex string
            raw_tx = tx_data
        else:
            raise ValueError("Invalid transaction data format")
        
        # Send raw transaction
        tx_hash = w3.eth.send_raw_transaction(raw_tx)
        
        return tx_hash.hex()
    except Exception as e:
        print(f"Error sending transaction: {str(e)}")
        return None

def get_transaction_receipt(tx_hash, w3=None, network="mainnet"):
    """
    Get transaction receipt
    
    Args:
        tx_hash: Transaction hash
        w3: Web3 connection (optional)
        network: Network to use (if w3 not provided)
        
    Returns:
        Transaction receipt object
    """
    if w3 is None:
        w3 = get_web3_connection(network)
    
    try:
        # Convert string hash to bytes if needed
        if isinstance(tx_hash, str):
            tx_hash = w3.to_bytes(hexstr=tx_hash)
        
        # Get receipt
        receipt = w3.eth.get_transaction_receipt(tx_hash)
        
        # Convert to dict for easier handling
        receipt_dict = dict(receipt)
        
        # Convert any bytes to hex
        for key, value in receipt_dict.items():
            if isinstance(value, bytes):
                receipt_dict[key] = value.hex()
        
        return receipt_dict
    except Exception as e:
        print(f"Error getting transaction receipt: {str(e)}")
        return None

def get_erc20_transfers(tx_hash, w3=None, network="mainnet"):
    """
    Extract ERC20 transfers from transaction receipt logs
    
    Args:
        tx_hash: Transaction hash
        w3: Web3 connection (optional)
        network: Network to use (if w3 not provided)
        
    Returns:
        List of ERC20 transfer events
    """
    if w3 is None:
        w3 = get_web3_connection(network)
    
    try:
        # Get transaction receipt
        receipt = get_transaction_receipt(tx_hash, w3, network)
        
        if not receipt or 'logs' not in receipt:
            return []
        
        # ERC20 Transfer event signature (keccak256 hash of Transfer(address,address,uint256))
        transfer_event_signature = '0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef'
        
        # Filter logs for Transfer events
        transfers = []
        for log in receipt['logs']:
            # Check if this is a Transfer event
            if log['topics'][0] == transfer_event_signature:
                # Parse the event data
                token_address = log['address']
                
                # Get token info (symbol and decimals)
                token_info = {"symbol": "UNKNOWN", "decimals": 18}
                try:
                    token_contract = w3.eth.contract(address=token_address, abi=ERC20_ABI)
                    token_info["symbol"] = token_contract.functions.symbol().call()
                    token_info["decimals"] = token_contract.functions.decimals().call()
                except:
                    pass
                
                # Parse from and to addresses
                from_address = '0x' + log['topics'][1].hex()[-40:]
                to_address = '0x' + log['topics'][2].hex()[-40:]
                
                # Parse amount
                amount_data = log['data']
                amount_hex = amount_data[2:] if amount_data.startswith('0x') else amount_data
                amount_int = int(amount_hex, 16)
                amount = amount_int / (10 ** token_info['decimals'])
                
                transfers.append({
                    'token_address': token_address,
                    'from': from_address,
                    'to': to_address,
                    'amount': amount,
                    'amount_raw': amount_int,
                    'token_symbol': token_info['symbol'],
                    'token_decimals': token_info['decimals']
                })
        
        return transfers
    except Exception as e:
        print(f"Error parsing ERC20 transfers: {str(e)}")
        return []