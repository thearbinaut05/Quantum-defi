"""
Visualization Module

This module provides functions for creating interactive visualizations
of quantum market data, trading performance, and portfolio metrics.
"""

import numpy as np
import pandas as pd
import plotly.graph_objects as go
import plotly.express as px
from datetime import datetime, timedelta
import time
import streamlit as st

# Import custom modules
import quantum_market_model as qmm

def plot_quantum_probabilities(quantum_assets):
    """
    Create a visualization of quantum probability distributions for asset price movements
    
    Args:
        quantum_assets: Dictionary of quantum asset data
        
    Returns:
        Plotly figure
    """
    # Create figure
    fig = go.Figure()
    
    # For each asset, get and plot probability distribution
    for asset_name, asset_data in quantum_assets.items():
        # Get probability distribution from quantum model
        current_price = asset_data.get("price", 1000)
        
        # Generate price range
        price_range_pct = 0.05  # 5% range
        num_points = 100
        
        # Either get real distribution from model or generate placeholder
        if hasattr(qmm, 'get_quantum_probability_distribution'):
            prices, probabilities = qmm.get_quantum_probability_distribution(
                asset_name, price_range_pct, num_points)
        else:
            # Generate placeholder distribution
            price_min = current_price * (1 - price_range_pct)
            price_max = current_price * (1 + price_range_pct)
            prices = np.linspace(price_min, price_max, num_points)
            
            # Create bimodal distribution based on up/down probabilities
            prob_up = asset_data.get("prob_up", 0.5)
            prob_down = asset_data.get("prob_down", 0.5)
            
            # Standard deviation for each peak
            std_dev = current_price * 0.01
            
            # Create two normal distributions for up/down
            up_dist = np.exp(-0.5 * ((prices - current_price * 1.02) / std_dev) ** 2)
            down_dist = np.exp(-0.5 * ((prices - current_price * 0.98) / std_dev) ** 2)
            
            # Combine distributions based on probabilities
            probabilities = prob_up * up_dist + prob_down * down_dist
            
            # Normalize to sum to 1
            probabilities = probabilities / np.sum(probabilities)
        
        # Add trace for this asset
        if prices is not None and probabilities is not None:
            fig.add_trace(go.Scatter(
                x=prices,
                y=probabilities,
                mode='lines',
                name=f"{asset_name} ({asset_data.get('state', 'Unknown')})",
                hovertemplate='Price: $%{x:.2f}<br>Probability: %{y:.4f}<extra></extra>'
            ))
    
    # Add vertical line for current price
    if quantum_assets:
        # Use first asset's price as reference
        first_asset = list(quantum_assets.values())[0]
        current_price = first_asset.get("price", 1000)
        
        fig.add_vline(
            x=current_price,
            line_width=1,
            line_dash="dash",
            line_color="gray",
            annotation_text="Current Price",
            annotation_position="top right"
        )
    
    # Update layout
    fig.update_layout(
        title="Quantum Probability Distributions for Price Movement",
        xaxis_title="Price",
        yaxis_title="Probability Density",
        legend_title="Assets",
        hovermode="x unified",
        template="plotly_white"
    )
    
    return fig

def plot_entanglement_map(entanglement_matrix):
    """
    Create a network graph visualization of asset entanglement
    
    Args:
        entanglement_matrix: Matrix of entanglement values
        
    Returns:
        Plotly figure
    """
    # Create figure
    fig = go.Figure()
    
    # Extract nodes (assets)
    assets = list(entanglement_matrix.keys())
    
    # Create positions for nodes in a circle
    num_assets = len(assets)
    radius = 1
    angles = np.linspace(0, 2 * np.pi, num_assets, endpoint=False)
    
    # Calculate node positions
    x_pos = radius * np.cos(angles)
    y_pos = radius * np.sin(angles)
    
    # Add nodes
    fig.add_trace(go.Scatter(
        x=x_pos,
        y=y_pos,
        mode='markers+text',
        marker=dict(size=20, color='lightblue'),
        text=assets,
        textposition="middle center",
        name='Assets'
    ))
    
    # Add edges for entanglement
    for i, asset1 in enumerate(assets):
        for j, asset2 in enumerate(assets):
            if i < j:  # Avoid duplicate edges
                entanglement = entanglement_matrix[asset1][asset2]
                
                # Only show edges with significant entanglement
                if entanglement > 0.3:
                    # Line width based on entanglement strength
                    width = entanglement * 5
                    
                    # Color based on entanglement strength
                    color = f'rgba(100, 100, 255, {entanglement})'
                    
                    # Add edge
                    fig.add_trace(go.Scatter(
                        x=[x_pos[i], x_pos[j]],
                        y=[y_pos[i], y_pos[j]],
                        mode='lines',
                        line=dict(width=width, color=color),
                        hoverinfo='text',
                        hovertext=f'{asset1} - {asset2}: {entanglement:.2f}',
                        showlegend=False
                    ))
    
    # Update layout
    fig.update_layout(
        title="Quantum Entanglement Network",
        showlegend=False,
        xaxis=dict(showgrid=False, zeroline=False, showticklabels=False),
        yaxis=dict(showgrid=False, zeroline=False, showticklabels=False),
        hovermode='closest',
        template="plotly_white",
        autosize=True
    )
    
    return fig

def plot_entanglement_heatmap(entanglement_matrix, selected_assets=None):
    """
    Create a heatmap visualization of asset entanglement
    
    Args:
        entanglement_matrix: Matrix of entanglement values
        selected_assets: Optional list of assets to include
        
    Returns:
        Plotly figure
    """
    # Filter assets if a selection is provided
    if selected_assets:
        assets = selected_assets
    else:
        assets = list(entanglement_matrix.keys())
    
    # Extract entanglement values
    z_values = []
    for asset1 in assets:
        row = []
        for asset2 in assets:
            if asset1 in entanglement_matrix and asset2 in entanglement_matrix[asset1]:
                row.append(entanglement_matrix[asset1][asset2])
            else:
                row.append(0)
        z_values.append(row)
    
    # Create heatmap
    fig = go.Figure(data=go.Heatmap(
        z=z_values,
        x=assets,
        y=assets,
        colorscale='Viridis',
        hoverongaps=False,
        hovertemplate='%{y} - %{x}: %{z:.2f}<extra></extra>'
    ))
    
    # Update layout
    fig.update_layout(
        title="Asset Quantum Entanglement Heatmap",
        xaxis_title="Asset",
        yaxis_title="Asset",
        template="plotly_white"
    )
    
    return fig

def plot_position_risk(positions):
    """
    Create a visualization of position risk based on quantum uncertainty
    
    Args:
        positions: List of position objects
        
    Returns:
        Plotly figure
    """
    if not positions:
        # Create empty figure with message if no positions
        fig = go.Figure()
        fig.update_layout(
            title="Position Risk Analysis",
            annotations=[dict(
                text="No open positions to display",
                showarrow=False,
                xref="paper",
                yref="paper",
                x=0.5,
                y=0.5
            )]
        )
        return fig
    
    # Extract position data
    assets = [p["asset"] for p in positions]
    leverages = [p["leverage"] for p in positions]
    
    # Calculate risk metrics
    liquidation_proximity = []
    for p in positions:
        if p["side"] == "long":
            proximity = (p["current_price"] - p["liquidation_price"]) / p["current_price"] * 100
        else:
            proximity = (p["liquidation_price"] - p["current_price"]) / p["current_price"] * 100
        liquidation_proximity.append(max(0, proximity))
    
    # Get quantum risk if available
    quantum_risks = [p.get("quantum_adjusted_risk", 50) for p in positions]
    
    # Position sizes
    position_sizes = [p["size_usd"] for p in positions]
    
    # Create bubble chart
    fig = go.Figure()
    
    # Add trace
    fig.add_trace(go.Scatter(
        x=leverages,
        y=liquidation_proximity,
        text=assets,
        mode='markers',
        marker=dict(
            size=[size/100 for size in position_sizes],
            sizemode='area',
            sizeref=2. * max(position_sizes) / (40.**2),
            sizemin=5,
            color=quantum_risks,
            colorscale='RdYlGn_r',  # Reversed so red is high risk
            colorbar=dict(
                title="Quantum Risk",
                titleside="right"
            ),
            showscale=True,
            line=dict(width=1, color='darkgray')
        ),
        hovertemplate='<b>%{text}</b><br>Leverage: %{x:.1f}x<br>Liquidation Buffer: %{y:.1f}%<br>Size: $%{marker.size:.2f}<br>Quantum Risk: %{marker.color:.0f}/100<extra></extra>'
    ))
    
    # Add safety zones
    fig.add_shape(
        type="rect",
        x0=0, y0=0,
        x1=2, y1=5,
        fillcolor="rgba(255,0,0,0.1)",
        line=dict(color="rgba(255,0,0,0.2)"),
        layer="below"
    )
    
    fig.add_shape(
        type="rect",
        x0=0, y0=5,
        x1=5, y1=10,
        fillcolor="rgba(255,165,0,0.1)",
        line=dict(color="rgba(255,165,0,0.2)"),
        layer="below"
    )
    
    fig.add_shape(
        type="rect",
        x0=0, y0=10,
        x1=10, y1=100,
        fillcolor="rgba(0,128,0,0.1)",
        line=dict(color="rgba(0,128,0,0.2)"),
        layer="below"
    )
    
    # Add annotations for risk zones
    fig.add_annotation(
        x=1, y=2.5,
        text="High Risk",
        showarrow=False,
        font=dict(color="rgba(255,0,0,0.7)")
    )
    
    fig.add_annotation(
        x=2.5, y=7.5,
        text="Medium Risk",
        showarrow=False,
        font=dict(color="rgba(255,165,0,0.7)")
    )
    
    fig.add_annotation(
        x=5, y=50,
        text="Low Risk",
        showarrow=False,
        font=dict(color="rgba(0,128,0,0.7)")
    )
    
    # Update layout
    fig.update_layout(
        title="Position Risk Based on Quantum Uncertainty",
        xaxis_title="Leverage",
        yaxis_title="Liquidation Buffer (%)",
        xaxis=dict(range=[0, max(leverages) * 1.1]),
        yaxis=dict(range=[0, max(100, max(liquidation_proximity) * 1.1)]),
        template="plotly_white"
    )
    
    return fig

def plot_coherence_timeline(dates, coherence_values):
    """
    Create a timeline visualization of quantum coherence
    
    Args:
        dates: List of dates
        coherence_values: List of coherence values
        
    Returns:
        Plotly figure
    """
    # Create figure
    fig = go.Figure()
    
    # Add coherence trace
    fig.add_trace(go.Scatter(
        x=dates,
        y=coherence_values,
        mode='lines',
        name='Coherence',
        line=dict(color='blue', width=2),
        hovertemplate='Date: %{x}<br>Coherence: %{y:.2f}<extra></extra>'
    ))
    
    # Add reference lines for coherence interpretation
    fig.add_shape(
        type="line",
        x0=dates[0],
        y0=0.7,
        x1=dates[-1],
        y1=0.7,
        line=dict(color="green", width=1, dash="dash"),
    )
    
    fig.add_shape(
        type="line",
        x0=dates[0],
        y0=0.3,
        x1=dates[-1],
        y1=0.3,
        line=dict(color="red", width=1, dash="dash"),
    )
    
    # Add annotations for coherence levels
    fig.add_annotation(
        x=dates[0],
        y=0.7,
        text="High Coherence",
        showarrow=False,
        xanchor="left",
        yanchor="bottom",
        font=dict(color="green")
    )
    
    fig.add_annotation(
        x=dates[0],
        y=0.3,
        text="Low Coherence",
        showarrow=False,
        xanchor="left",
        yanchor="top",
        font=dict(color="red")
    )
    
    # Update layout
    fig.update_layout(
        title="Market Quantum Coherence Over Time",
        xaxis_title="Date",
        yaxis_title="Coherence",
        yaxis=dict(range=[0, 1]),
        template="plotly_white"
    )
    
    return fig

def plot_flash_swap_performance(swap_history):
    """
    Create a visualization of flash swap performance over time
    
    Args:
        swap_history: List of flash swap records
        
    Returns:
        Plotly figure
    """
    if not swap_history:
        # Create empty figure with message if no history
        fig = go.Figure()
        fig.update_layout(
            title="Flash Swap Performance",
            annotations=[dict(
                text="No flash swap history to display",
                showarrow=False,
                xref="paper",
                yref="paper",
                x=0.5,
                y=0.5
            )]
        )
        return fig
    
    # Convert to dataframe
    df = pd.DataFrame(swap_history)
    
    # Sort by timestamp
    df['timestamp'] = pd.to_datetime(df['timestamp'])
    df = df.sort_values('timestamp')
    
    # Calculate cumulative profit
    df['cumulative_profit'] = df['profit_usd'].cumsum()
    
    # Create figure
    fig = go.Figure()
    
    # Add bar chart for individual profits
    fig.add_trace(go.Bar(
        x=df['timestamp'],
        y=df['profit_usd'],
        name='Profit per Swap',
        marker_color='lightgreen',
        hovertemplate='Time: %{x}<br>Profit: $%{y:.2f}<extra></extra>'
    ))
    
    # Add line chart for cumulative profit
    fig.add_trace(go.Scatter(
        x=df['timestamp'],
        y=df['cumulative_profit'],
        mode='lines+markers',
        name='Cumulative Profit',
        line=dict(color='blue', width=2),
        hovertemplate='Time: %{x}<br>Cumulative Profit: $%{y:.2f}<extra></extra>'
    ))
    
    # Update layout
    fig.update_layout(
        title="Flash Swap Performance Over Time",
        xaxis_title="Time",
        yaxis_title="Profit (USD)",
        template="plotly_white"
    )
    
    return fig

def plot_arbitrage_performance(arbitrage_history):
    """
    Create a visualization of arbitrage performance over time
    
    Args:
        arbitrage_history: List of arbitrage operation records
        
    Returns:
        Plotly figure
    """
    if not arbitrage_history:
        # Create empty figure with message if no history
        fig = go.Figure()
        fig.update_layout(
            title="Arbitrage Performance",
            annotations=[dict(
                text="No arbitrage history to display",
                showarrow=False,
                xref="paper",
                yref="paper",
                x=0.5,
                y=0.5
            )]
        )
        return fig
    
    # Convert to dataframe
    df = pd.DataFrame(arbitrage_history)
    
    # Parse timestamps if available
    timestamp_column = 'execution_time' if 'execution_time' in df.columns else 'timestamp'
    
    # Ensure column exists
    if timestamp_column not in df.columns:
        # Create placeholder timestamps
        df['timestamp'] = [datetime.now() - timedelta(hours=i) for i in range(len(df))]
        timestamp_column = 'timestamp'
    
    # Convert to datetime
    df[timestamp_column] = pd.to_datetime(df[timestamp_column])
    df = df.sort_values(timestamp_column)
    
    # Calculate cumulative profit
    profit_column = 'profit_usd'
    if profit_column not in df.columns:
        profit_column = 'profit_pct'
    
    df['cumulative_profit'] = df[profit_column].cumsum()
    
    # Create figure
    fig = go.Figure()
    
    # Add bar chart for individual profits
    fig.add_trace(go.Bar(
        x=df[timestamp_column],
        y=df[profit_column],
        name='Profit per Operation',
        marker_color='lightgreen',
        hovertemplate='Time: %{x}<br>Profit: %{y:.2f}<extra></extra>'
    ))
    
    # Add line chart for cumulative profit
    fig.add_trace(go.Scatter(
        x=df[timestamp_column],
        y=df['cumulative_profit'],
        mode='lines+markers',
        name='Cumulative Profit',
        line=dict(color='blue', width=2),
        hovertemplate='Time: %{x}<br>Cumulative Profit: %{y:.2f}<extra></extra>'
    ))
    
    # Update layout
    fig.update_layout(
        title="Arbitrage Performance Over Time",
        xaxis_title="Time",
        yaxis_title=f"Profit ({'USD' if profit_column == 'profit_usd' else '%'})",
        template="plotly_white"
    )
    
    return fig

def plot_leverage_optimization_heatmap():
    """
    Create a heatmap visualization of leverage optimization
    
    Returns:
        Plotly figure
    """
    # Generate data for the heatmap
    volatility = np.linspace(0.01, 0.10, 20)  # Daily volatility from 1% to 10%
    leverage = np.linspace(1, 10, 20)  # Leverage from 1x to 10x
    
    # Create meshgrid
    X, Y = np.meshgrid(volatility, leverage)
    
    # Calculate expected return based on leverage and volatility
    Z = np.zeros_like(X)
    
    for i in range(len(leverage)):
        for j in range(len(volatility)):
            # Higher leverage amplifies returns but increases risk of ruin with higher volatility
            # This is a simplified model that shows optimal leverage decreases as volatility increases
            expected_return = leverage[i] * 0.0005 - (leverage[i]**2) * volatility[j] * 0.01
            Z[i, j] = expected_return * 100  # Convert to percentage
    
    # Create heatmap
    fig = go.Figure(data=go.Heatmap(
        z=Z,
        x=volatility,
        y=leverage,
        colorscale='Viridis',
        hoverongaps=False,
        hovertemplate='Volatility: %{x:.2%}<br>Leverage: %{y:.1f}x<br>Expected Return: %{z:.2f}%<extra></extra>'
    ))
    
    # Find optimal leverage for each volatility level
    optimal_leverage = []
    optimal_volatility = []
    
    for j in range(len(volatility)):
        max_return_idx = np.argmax(Z[:, j])
        optimal_leverage.append(leverage[max_return_idx])
        optimal_volatility.append(volatility[j])
    
    # Add optimal leverage line
    fig.add_trace(go.Scatter(
        x=optimal_volatility,
        y=optimal_leverage,
        mode='lines',
        line=dict(color='white', width=2),
        name='Optimal Leverage'
    ))
    
    # Update layout
    fig.update_layout(
        title="Leverage Optimization by Market Volatility",
        xaxis_title="Daily Volatility",
        yaxis_title="Leverage",
        xaxis=dict(tickformat='.0%'),
        template="plotly_white"
    )
    
    return fig

def plot_mev_activity(mev_activity):
    """
    Create a visualization of MEV activity over time
    
    Args:
        mev_activity: List of MEV activity records
        
    Returns:
        Plotly figure
    """
    if not mev_activity:
        # Create empty figure with message if no activity
        fig = go.Figure()
        fig.update_layout(
            title="MEV Activity",
            annotations=[dict(
                text="No MEV activity to display",
                showarrow=False,
                xref="paper",
                yref="paper",
                x=0.5,
                y=0.5
            )]
        )
        return fig
    
    # Convert to dataframe
    df = pd.DataFrame(mev_activity)
    
    # Parse timestamps
    df['timestamp'] = pd.to_datetime(df['timestamp'])
    df = df.sort_values('timestamp')
    
    # Group by type and timestamp (hourly)
    df['hour'] = df['timestamp'].dt.floor('H')
    grouped = df.groupby(['hour', 'type']).agg({
        'profit_eth': 'sum',
        'profit_usd': 'sum',
        'type': 'count'
    }).rename(columns={'type': 'count'}).reset_index()
    
    # Pivot for stacked bar chart
    pivot_df = grouped.pivot(index='hour', columns='type', values='profit_usd').fillna(0)
    
    # Create figure
    fig = go.Figure()
    
    # Add stacked bar chart for MEV types
    for mev_type in pivot_df.columns:
        fig.add_trace(go.Bar(
            x=pivot_df.index,
            y=pivot_df[mev_type],
            name=mev_type.capitalize(),
            hovertemplate='Time: %{x}<br>Profit: $%{y:.2f}<extra></extra>'
        ))
    
    # Update layout
    fig.update_layout(
        title="MEV Activity Over Time",
        xaxis_title="Time",
        yaxis_title="Profit (USD)",
        template="plotly_white",
        barmode='stack'
    )
    
    return fig

def plot_portfolio_allocation(portfolio_assets):
    """
    Create a pie chart visualization of portfolio allocation
    
    Args:
        portfolio_assets: List of assets in the portfolio
        
    Returns:
        Plotly figure
    """
    if not portfolio_assets:
        # Create empty figure with message if no assets
        fig = go.Figure()
        fig.update_layout(
            title="Portfolio Allocation",
            annotations=[dict(
                text="No assets in portfolio",
                showarrow=False,
                xref="paper",
                yref="paper",
                x=0.5,
                y=0.5
            )]
        )
        return fig
    
    # Extract asset data
    labels = [asset["asset"] for asset in portfolio_assets]
    values = [asset["total_size_usd"] for asset in portfolio_assets]
    
    # Create pie chart
    fig = go.Figure(data=[go.Pie(
        labels=labels,
        values=values,
        textinfo='label+percent',
        hovertemplate='Asset: %{label}<br>Value: $%{value:,.2f}<br>Percentage: %{percent}<extra></extra>'
    )])
    
    # Update layout
    fig.update_layout(
        title="Portfolio Allocation",
        template="plotly_white"
    )
    
    return fig

def plot_optimized_portfolio(optimal_portfolio):
    """
    Create a visualization of optimized portfolio allocation
    
    Args:
        optimal_portfolio: Dictionary with optimal portfolio data
        
    Returns:
        Plotly figure
    """
    # Extract allocation data
    allocation = optimal_portfolio.get("allocation", {})
    
    if not allocation:
        # Create empty figure with message if no allocation
        fig = go.Figure()
        fig.update_layout(
            title="Optimized Portfolio",
            annotations=[dict(
                text="No portfolio allocation data",
                showarrow=False,
                xref="paper",
                yref="paper",
                x=0.5,
                y=0.5
            )]
        )
        return fig
    
    # Extract assets and weights
    assets = list(allocation.keys())
    weights = list(allocation.values())
    
    # Create pie chart
    fig = go.Figure(data=[go.Pie(
        labels=assets,
        values=weights,
        textinfo='label+percent',
        hovertemplate='Asset: %{label}<br>Weight: %{value:.2%}<br>Percentage: %{percent}<extra></extra>'
    )])
    
    # Update layout
    fig.update_layout(
        title="Optimized Portfolio Allocation",
        template="plotly_white"
    )
    
    return fig
