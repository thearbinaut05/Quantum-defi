"""
Wallet Manager

This module provides functionality for connecting to and interacting with
cryptocurrency wallets and blockchain networks.
"""

import streamlit as st
import json
import time
import random
from web3 import Web3
import pandas as pd
from datetime import datetime

# Constants
DEFAULT_ETHEREUM_ENDPOINT = "https://mainnet.infura.io/v3/your-api-key"
SUPPORTED_NETWORKS = {
    "mainnet": {
        "name": "Ethereum Mainnet",
        "chain_id": 1,
        "currency": "ETH",
        "explorer": "https://etherscan.io"
    },
    "sepolia": {
        "name": "Ethereum Sepolia Testnet",
        "chain_id": 11155111,
        "currency": "ETH",
        "explorer": "https://sepolia.etherscan.io"
    },
    "arbitrum": {
        "name": "Arbitrum One",
        "chain_id": 42161,
        "currency": "ETH",
        "explorer": "https://arbiscan.io"
    },
    "optimism": {
        "name": "Optimism",
        "chain_id": 10,
        "currency": "ETH",
        "explorer": "https://optimistic.etherscan.io"
    },
    "polygon": {
        "name": "Polygon",
        "chain_id": 137,
        "currency": "MATIC",
        "explorer": "https://polygonscan.com"
    }
}

# Common token addresses
COMMON_TOKENS = {
    "ETH": {
        "address": "0xEeeeeEeeeEeEeeEeEeEeeEEEeeeeEeeeeeeeEEeE",  # Placeholder for native ETH
        "name": "Ethereum",
        "symbol": "ETH",
        "decimals": 18,
        "logo": "https://cryptologos.cc/logos/ethereum-eth-logo.png"
    },
    "WETH": {
        "address": "0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2",
        "name": "Wrapped Ethereum",
        "symbol": "WETH",
        "decimals": 18,
        "logo": "https://cryptologos.cc/logos/ethereum-eth-logo.png"
    },
    "USDC": {
        "address": "0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48",
        "name": "USD Coin",
        "symbol": "USDC",
        "decimals": 6,
        "logo": "https://cryptologos.cc/logos/usd-coin-usdc-logo.png"
    },
    "USDT": {
        "address": "0xdAC17F958D2ee523a2206206994597C13D831ec7",
        "name": "Tether",
        "symbol": "USDT",
        "decimals": 6,
        "logo": "https://cryptologos.cc/logos/tether-usdt-logo.png"
    },
    "DAI": {
        "address": "0x6B175474E89094C44Da98b954EedeAC495271d0F",
        "name": "Dai Stablecoin",
        "symbol": "DAI",
        "decimals": 18,
        "logo": "https://cryptologos.cc/logos/multi-collateral-dai-dai-logo.png"
    },
    "WBTC": {
        "address": "0x2260FAC5E5542a773Aa44fBCfeDf7C193bc2C599",
        "name": "Wrapped Bitcoin",
        "symbol": "WBTC",
        "decimals": 8,
        "logo": "https://cryptologos.cc/logos/wrapped-bitcoin-wbtc-logo.png"
    },
    "LINK": {
        "address": "0x514910771AF9Ca656af840dff83E8264EcF986CA",
        "name": "Chainlink",
        "symbol": "LINK",
        "decimals": 18,
        "logo": "https://cryptologos.cc/logos/chainlink-link-logo.png"
    }
}

# Common ABIs
ERC20_ABI = [
    {
        "constant": True,
        "inputs": [],
        "name": "name",
        "outputs": [{"name": "", "type": "string"}],
        "payable": False,
        "stateMutability": "view",
        "type": "function"
    },
    {
        "constant": True,
        "inputs": [],
        "name": "symbol",
        "outputs": [{"name": "", "type": "string"}],
        "payable": False,
        "stateMutability": "view",
        "type": "function"
    },
    {
        "constant": True,
        "inputs": [],
        "name": "decimals",
        "outputs": [{"name": "", "type": "uint8"}],
        "payable": False,
        "stateMutability": "view",
        "type": "function"
    },
    {
        "constant": True,
        "inputs": [{"name": "owner", "type": "address"}],
        "name": "balanceOf",
        "outputs": [{"name": "", "type": "uint256"}],
        "payable": False,
        "stateMutability": "view",
        "type": "function"
    },
    {
        "constant": False,
        "inputs": [
            {"name": "to", "type": "address"},
            {"name": "value", "type": "uint256"}
        ],
        "name": "transfer",
        "outputs": [{"name": "", "type": "bool"}],
        "payable": False,
        "stateMutability": "nonpayable",
        "type": "function"
    },
    {
        "constant": False,
        "inputs": [
            {"name": "spender", "type": "address"},
            {"name": "value", "type": "uint256"}
        ],
        "name": "approve",
        "outputs": [{"name": "", "type": "bool"}],
        "payable": False,
        "stateMutability": "nonpayable",
        "type": "function"
    }
]

def connect_wallet():
    """
    Connect to a wallet.
    
    In a real implementation, this would connect to a real wallet like MetaMask.
    Here we're simulating the connection for demonstration.
    
    Returns:
        bool: True if connection successful, False otherwise
    """
    # Simulate wallet connection
    success = True
    
    if success:
        # Generate a random wallet address
        wallet_address = "0x" + "".join(random.choices("0123456789abcdef", k=40))
        st.session_state.wallet_address = wallet_address
        
        # Initialize wallet data
        st.session_state.wallet_chain_id = SUPPORTED_NETWORKS["mainnet"]["chain_id"]
        st.session_state.wallet_network = "mainnet"
        
        return True
    
    return False

def disconnect_wallet():
    """
    Disconnect the connected wallet.
    
    Returns:
        bool: True if disconnection successful, False otherwise
    """
    # Remove wallet data from session state
    if "wallet_address" in st.session_state:
        del st.session_state.wallet_address
    
    if "wallet_chain_id" in st.session_state:
        del st.session_state.wallet_chain_id
    
    if "wallet_network" in st.session_state:
        del st.session_state.wallet_network
    
    return True

def is_wallet_connected():
    """
    Check if a wallet is connected.
    
    Returns:
        bool: True if wallet is connected, False otherwise
    """
    return "wallet_address" in st.session_state

def get_active_account():
    """
    Get the active wallet account address.
    
    Returns:
        str: Wallet address if connected, None otherwise
    """
    return st.session_state.get("wallet_address")

def get_chain_id():
    """
    Get the current chain ID.
    
    Returns:
        int: Chain ID if available, None otherwise
    """
    return st.session_state.get("wallet_chain_id")

def get_web3_connection(network="mainnet"):
    """
    Get a Web3 connection for the specified network.
    
    Args:
        network: Network name
        
    Returns:
        Web3 instance
    """
    # Get network configuration
    network_config = SUPPORTED_NETWORKS.get(network, SUPPORTED_NETWORKS["mainnet"])
    
    # Create Web3 instance
    # In a real implementation, this would use an actual provider
    # Here we're creating a provider with a fallback in case no API key is available
    try:
        # Create Web3 instance
        web3 = Web3(Web3.HTTPProvider(DEFAULT_ETHEREUM_ENDPOINT))
        
        # Store in session state
        st.session_state.w3 = web3
        st.session_state.selected_network = network
        
        return web3
    except Exception as e:
        st.error(f"Error connecting to {network_config['name']}: {str(e)}")
        return None

def switch_network(network):
    """
    Switch to a different network.
    
    Args:
        network: Network name
        
    Returns:
        bool: True if successful, False otherwise
    """
    if network not in SUPPORTED_NETWORKS:
        st.error(f"Unsupported network: {network}")
        return False
    
    # Get network configuration
    network_config = SUPPORTED_NETWORKS[network]
    
    # Update session state
    st.session_state.wallet_chain_id = network_config["chain_id"]
    st.session_state.wallet_network = network
    
    # Reconnect Web3
    get_web3_connection(network)
    
    return True

def get_token_balance(token_symbol, address=None):
    """
    Get token balance for an address.
    
    Args:
        token_symbol: Token symbol
        address: Address to check (defaults to connected wallet)
        
    Returns:
        float: Token balance
    """
    if not address and not is_wallet_connected():
        return 0
    
    address = address or get_active_account()
    
    # Get Web3 instance
    if "w3" not in st.session_state or not st.session_state.w3:
        get_web3_connection()
    
    web3 = st.session_state.w3
    
    # Get token configuration
    token_config = COMMON_TOKENS.get(token_symbol)
    
    if not token_config:
        st.error(f"Unsupported token: {token_symbol}")
        return 0
    
    try:
        # Handle ETH separately
        if token_symbol == "ETH":
            balance_wei = web3.eth.get_balance(address)
            balance = web3.from_wei(balance_wei, "ether")
            return float(balance)
        
        # For ERC20 tokens
        token_address = token_config["address"]
        token_contract = web3.eth.contract(address=token_address, abi=ERC20_ABI)
        
        decimals = token_config["decimals"]
        balance_raw = token_contract.functions.balanceOf(address).call()
        balance = balance_raw / (10 ** decimals)
        
        return float(balance)
    except Exception as e:
        st.error(f"Error getting {token_symbol} balance: {str(e)}")
        return 0

def get_all_balances(address=None):
    """
    Get balances for all supported tokens.
    
    Args:
        address: Address to check (defaults to connected wallet)
        
    Returns:
        dict: Token balances
    """
    if not address and not is_wallet_connected():
        return {}
    
    address = address or get_active_account()
    
    # Get balances for all tokens
    balances = {}
    
    for token_symbol in COMMON_TOKENS:
        balance = get_token_balance(token_symbol, address)
        balances[token_symbol] = balance
    
    return balances

def estimate_gas_price():
    """
    Estimate current gas prices.
    
    Returns:
        dict: Gas price estimates
    """
    # Get Web3 instance
    if "w3" not in st.session_state or not st.session_state.w3:
        get_web3_connection()
    
    web3 = st.session_state.w3
    
    try:
        # Get current gas price
        gas_price_wei = web3.eth.gas_price
        gas_price_gwei = web3.from_wei(gas_price_wei, "gwei")
        
        # Calculate slow, average, and fast prices
        slow = gas_price_gwei * 0.8
        average = gas_price_gwei
        fast = gas_price_gwei * 1.2
        
        return {
            "slow": float(slow),
            "average": float(average),
            "fast": float(fast)
        }
    except Exception as e:
        st.error(f"Error estimating gas price: {str(e)}")
        return {
            "slow": 30,
            "average": 50,
            "fast": 80
        }

def sign_message(message):
    """
    Sign a message with the connected wallet.
    
    In a real implementation, this would use the actual wallet to sign.
    Here we're simulating the signature for demonstration.
    
    Args:
        message: Message to sign
        
    Returns:
        str: Signature
    """
    if not is_wallet_connected():
        st.error("Wallet not connected")
        return None
    
    # Simulate signature
    signature = "0x" + "".join(random.choices("0123456789abcdef", k=130))
    
    return signature

def send_transaction(tx_data):
    """
    Send a transaction.
    
    In a real implementation, this would broadcast to the blockchain.
    Here we're simulating the transaction for demonstration.
    
    Args:
        tx_data: Transaction data
        
    Returns:
        str: Transaction hash if successful, None otherwise
    """
    if not is_wallet_connected():
        st.error("Wallet not connected")
        return None
    
    try:
        # Simulate transaction
        tx_hash = "0x" + "".join(random.choices("0123456789abcdef", k=64))
        
        # Store transaction in history
        if "transaction_history" not in st.session_state:
            st.session_state.transaction_history = []
        
        # Add transaction to history
        st.session_state.transaction_history.append({
            "hash": tx_hash,
            "from": get_active_account(),
            "to": tx_data.get("to", "0x0000000000000000000000000000000000000000"),
            "value": tx_data.get("value", 0),
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "status": "pending"
        })
        
        return tx_hash
    except Exception as e:
        st.error(f"Error sending transaction: {str(e)}")
        return None

def get_transaction_history():
    """
    Get transaction history for the connected wallet.
    
    Returns:
        list: Transaction history
    """
    if "transaction_history" not in st.session_state:
        st.session_state.transaction_history = []
    
    return st.session_state.transaction_history

def get_transaction_receipt(tx_hash):
    """
    Get transaction receipt.
    
    In a real implementation, this would query the blockchain.
    Here we're simulating the receipt for demonstration.
    
    Args:
        tx_hash: Transaction hash
        
    Returns:
        dict: Transaction receipt
    """
    if "transaction_history" not in st.session_state:
        return None
    
    # Find transaction in history
    for tx in st.session_state.transaction_history:
        if tx["hash"] == tx_hash:
            # Simulate transaction confirmation
            if tx["status"] == "pending":
                # 90% chance of success
                if random.random() < 0.9:
                    tx["status"] = "confirmed"
                else:
                    tx["status"] = "failed"
            
            return {
                "transactionHash": tx["hash"],
                "from": tx["from"],
                "to": tx["to"],
                "value": tx["value"],
                "status": 1 if tx["status"] == "confirmed" else 0,
                "blockNumber": random.randint(10000000, 20000000),
                "blockHash": "0x" + "".join(random.choices("0123456789abcdef", k=64)),
                "timestamp": tx["timestamp"]
            }
    
    return None

def get_gas_used_by_transaction(tx_hash):
    """
    Get gas used by a transaction.
    
    Args:
        tx_hash: Transaction hash
        
    Returns:
        int: Gas used
    """
    receipt = get_transaction_receipt(tx_hash)
    
    if not receipt:
        return 0
    
    # Simulate gas used
    return random.randint(50000, 500000)

def approve_token_spend(token_symbol, spender_address, amount):
    """
    Approve token spending.
    
    Args:
        token_symbol: Token symbol
        spender_address: Address to approve
        amount: Amount to approve
        
    Returns:
        str: Transaction hash if successful, None otherwise
    """
    if not is_wallet_connected():
        st.error("Wallet not connected")
        return None
    
    # Get token configuration
    token_config = COMMON_TOKENS.get(token_symbol)
    
    if not token_config:
        st.error(f"Unsupported token: {token_symbol}")
        return None
    
    # Simulate approval transaction
    tx_data = {
        "to": token_config["address"],
        "data": f"approve({spender_address}, {amount})",
        "value": 0
    }
    
    return send_transaction(tx_data)

def get_token_allowance(token_symbol, owner_address, spender_address):
    """
    Get token allowance.
    
    Args:
        token_symbol: Token symbol
        owner_address: Token owner address
        spender_address: Spender address
        
    Returns:
        float: Token allowance
    """
    # Get Web3 instance
    if "w3" not in st.session_state or not st.session_state.w3:
        get_web3_connection()
    
    web3 = st.session_state.w3
    
    # Get token configuration
    token_config = COMMON_TOKENS.get(token_symbol)
    
    if not token_config:
        st.error(f"Unsupported token: {token_symbol}")
        return 0
    
    try:
        # For ERC20 tokens
        token_address = token_config["address"]
        token_contract = web3.eth.contract(address=token_address, abi=ERC20_ABI)
        
        decimals = token_config["decimals"]
        allowance_raw = token_contract.functions.allowance(owner_address, spender_address).call()
        allowance = allowance_raw / (10 ** decimals)
        
        return float(allowance)
    except Exception as e:
        st.error(f"Error getting {token_symbol} allowance: {str(e)}")
        return 0
