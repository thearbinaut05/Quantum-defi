"""
Web Intelligence Module for Autonomous Data Collector

This module handles web scraping and intelligence gathering from
various web sources, including news sites, forums, and social media.
"""

import trafilatura
import requests
from datetime import datetime
import time
import json
import random
import re
import os
import streamlit as st
from bs4 import BeautifulSoup
from urllib.parse import urlparse

# Web sources for financial and crypto intelligence
DEFAULT_SOURCES = {
    'news': [
        'https://cointelegraph.com/',
        'https://www.coindesk.com/',
        'https://decrypt.co/',
        'https://cryptobriefing.com/',
        'https://www.theblockcrypto.com/'
    ],
    'analysis': [
        'https://insights.glassnode.com/',
        'https://messari.io/research',
        'https://blog.chainalysis.com/'
    ],
    'forums': [
        'https://www.reddit.com/r/CryptoCurrency/',
        'https://www.reddit.com/r/ethereum/',
        'https://www.reddit.com/r/defi/'
    ]
}

# Headers for web requests
USER_AGENTS = [
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
    'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:89.0) Gecko/20100101 Firefox/89.0',
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:89.0) Gecko/20100101 Firefox/89.0'
]

# Initialize web cache
WEB_CACHE = {}
CACHE_MAX_AGE = 3600  # 1 hour in seconds
CACHE_MAX_SIZE = 50   # Maximum number of cached pages


def get_random_user_agent():
    """Get a random user agent to avoid detection"""
    return random.choice(USER_AGENTS)


def fetch_web_content(url, use_cache=True):
    """
    Fetch content from a web page with caching
    
    Args:
        url: URL to fetch
        use_cache: Whether to use cached content if available
        
    Returns:
        Extracted text content or None if failed
    """
    try:
        # Check cache first if enabled
        current_time = time.time()
        if use_cache and url in WEB_CACHE:
            cache_time, content = WEB_CACHE[url]
            if current_time - cache_time < CACHE_MAX_AGE:
                print(f"Using cached content for {url}")
                return content
        
        # Set headers with random user agent
        headers = {
            'User-Agent': get_random_user_agent(),
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1',
            'Cache-Control': 'max-age=0',
        }
        
        # Fetch the content
        response = requests.get(url, headers=headers, timeout=10)
        
        if response.status_code == 200:
            # Use trafilatura for better content extraction
            downloaded = response.text
            extracted_text = trafilatura.extract(downloaded)
            
            if not extracted_text or len(extracted_text) < 100:
                # Fallback to BeautifulSoup if trafilatura fails
                soup = BeautifulSoup(response.text, 'html.parser')
                
                # Remove script and style elements
                for script_or_style in soup(['script', 'style', 'header', 'footer', 'nav']):
                    script_or_style.decompose()
                
                # Get text
                text = soup.get_text(separator='\n')
                
                # Clean up text
                lines = (line.strip() for line in text.splitlines())
                chunks = (phrase.strip() for line in lines for phrase in line.split("  "))
                extracted_text = '\n'.join(chunk for chunk in chunks if chunk)
            
            # Update cache
            if use_cache:
                # Manage cache size
                if len(WEB_CACHE) >= CACHE_MAX_SIZE:
                    # Remove oldest entry
                    oldest_url = min(WEB_CACHE.keys(), key=lambda k: WEB_CACHE[k][0])
                    del WEB_CACHE[oldest_url]
                
                WEB_CACHE[url] = (current_time, extracted_text)
            
            return extracted_text
        else:
            print(f"Failed to fetch {url}: HTTP {response.status_code}")
            return None
    
    except Exception as e:
        print(f"Error fetching {url}: {str(e)}")
        return None


def fetch_multiple_sources(category=None, max_sources=3, use_cache=True):
    """
    Fetch content from multiple sources
    
    Args:
        category: Category of sources to fetch (news, analysis, forums, or None for random)
        max_sources: Maximum number of sources to fetch
        use_cache: Whether to use cache
        
    Returns:
        Dictionary of source URLs and their content
    """
    results = {}
    
    # Select sources
    if category and category in DEFAULT_SOURCES:
        sources = DEFAULT_SOURCES[category]
    else:
        # Randomly select from all categories
        all_sources = []
        for cat_sources in DEFAULT_SOURCES.values():
            all_sources.extend(cat_sources)
        sources = all_sources
    
    # Randomly sample sources
    selected_sources = random.sample(sources, min(max_sources, len(sources)))
    
    # Fetch content from each source
    for url in selected_sources:
        content = fetch_web_content(url, use_cache)
        if content:
            results[url] = {
                'content': content,
                'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                'category': get_source_category(url)
            }
    
    return results


def get_source_category(url):
    """
    Determine category of a source URL
    
    Args:
        url: Source URL
        
    Returns:
        Category string
    """
    for category, urls in DEFAULT_SOURCES.items():
        for source_url in urls:
            if url_match(url, source_url):
                return category
    
    # Determine based on domain
    domain = urlparse(url).netloc
    
    if 'reddit' in domain:
        return 'social'
    elif any(x in domain for x in ['news', 'blog', 'decrypt', 'cointelegraph', 'coindesk']):
        return 'news'
    elif any(x in domain for x in ['research', 'insights', 'analysis']):
        return 'analysis'
    elif any(x in domain for x in ['forum', 'community', 'talk']):
        return 'forums'
    
    return 'unknown'


def url_match(url1, url2):
    """Check if URLs match (ignoring protocol and trailing slashes)"""
    u1 = urlparse(url1)
    u2 = urlparse(url2)
    
    # Compare netloc (domain) and path
    return u1.netloc == u2.netloc and u1.path.rstrip('/') == u2.path.rstrip('/')


def extract_crypto_mentions(text):
    """
    Extract cryptocurrency mentions from text
    
    Args:
        text: Text to analyze
        
    Returns:
        Dictionary of cryptocurrency mentions and their counts
    """
    # Common cryptocurrency names and tickers
    crypto_patterns = {
        'bitcoin': ['bitcoin', 'btc', 'xbt'],
        'ethereum': ['ethereum', 'eth', 'ether'],
        'ripple': ['ripple', 'xrp'],
        'litecoin': ['litecoin', 'ltc'],
        'cardano': ['cardano', 'ada'],
        'polkadot': ['polkadot', 'dot'],
        'solana': ['solana', 'sol'],
        'dogecoin': ['dogecoin', 'doge'],
        'chainlink': ['chainlink', 'link'],
        'uniswap': ['uniswap', 'uni'],
        'polygon': ['polygon', 'matic'],
        'avalanche': ['avalanche', 'avax'],
        'binance coin': ['binance coin', 'bnb', 'binance'],
        'tether': ['tether', 'usdt'],
        'usd coin': ['usd coin', 'usdc'],
        'dai': ['dai']
    }
    
    mentions = {}
    
    # Convert text to lowercase for case-insensitive matching
    text_lower = text.lower()
    
    for crypto, patterns in crypto_patterns.items():
        count = 0
        for pattern in patterns:
            # Count occurrences of pattern as whole word
            count += len(re.findall(r'\b' + re.escape(pattern) + r'\b', text_lower))
        
        if count > 0:
            mentions[crypto] = count
    
    return mentions


def extract_sentiment_keywords(text):
    """
    Extract sentiment-related keywords from text
    
    Args:
        text: Text to analyze
        
    Returns:
        Dictionary of sentiment keywords and their counts
    """
    sentiment_keywords = {
        'positive': [
            'bullish', 'surge', 'rally', 'gain', 'rise', 'soar', 'growth', 'profit', 
            'upturn', 'uptrend', 'positive', 'opportunity', 'optimistic', 'breakthrough',
            'outperform', 'recovery', 'upside', 'strong', 'strength', 'enthusiastic'
        ],
        'negative': [
            'bearish', 'crash', 'fall', 'drop', 'decline', 'plummet', 'loss', 
            'downturn', 'downtrend', 'negative', 'risk', 'pessimistic', 'underperform',
            'correction', 'weak', 'weakness', 'struggle', 'tumble', 'slump', 'failure'
        ],
        'neutral': [
            'consolidation', 'stable', 'steady', 'hold', 'unchanged', 'flat', 
            'sideways', 'ranging', 'stabilize', 'maintain', 'expect', 'monitor',
            'observation', 'analysis', 'research', 'report', 'study', 'outlook'
        ]
    }
    
    results = {'positive': 0, 'negative': 0, 'neutral': 0, 'keywords': {}}
    
    # Convert text to lowercase for case-insensitive matching
    text_lower = text.lower()
    
    for sentiment, keywords in sentiment_keywords.items():
        for keyword in keywords:
            # Count occurrences of keyword as whole word
            count = len(re.findall(r'\b' + re.escape(keyword) + r'\b', text_lower))
            
            if count > 0:
                results[sentiment] += count
                results['keywords'][keyword] = count
    
    return results


def analyze_web_content(content, url=None):
    """
    Analyze web content for cryptocurrency intelligence
    
    Args:
        content: Text content to analyze
        url: Original URL (optional)
        
    Returns:
        Analysis results dictionary
    """
    if not content or len(content) < 100:
        return None
    
    # Initialize analysis result
    analysis = {
        'url': url,
        'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        'length': len(content),
        'crypto_mentions': {},
        'sentiment': {},
        'summary': ''
    }
    
    # Extract cryptocurrency mentions
    analysis['crypto_mentions'] = extract_crypto_mentions(content)
    
    # Extract sentiment keywords
    sentiment_data = extract_sentiment_keywords(content)
    analysis['sentiment'] = {
        'positive_count': sentiment_data['positive'],
        'negative_count': sentiment_data['negative'],
        'neutral_count': sentiment_data['neutral'],
        'keywords': sentiment_data['keywords']
    }
    
    # Calculate overall sentiment score (-1 to 1)
    total_sentiment = sentiment_data['positive'] + sentiment_data['negative'] + sentiment_data['neutral']
    if total_sentiment > 0:
        analysis['sentiment']['score'] = (sentiment_data['positive'] - sentiment_data['negative']) / total_sentiment
    else:
        analysis['sentiment']['score'] = 0
    
    # Create simple summary
    tokens = content.split()
    if len(tokens) > 100:
        # Take first 2 sentences
        first_sentences = re.findall(r'([^.!?]+[.!?])', content)
        if first_sentences and len(first_sentences) >= 2:
            analysis['summary'] = first_sentences[0].strip() + ' ' + first_sentences[1].strip()
        else:
            analysis['summary'] = ' '.join(tokens[:50]) + '...'
    else:
        analysis['summary'] = content
    
    return analysis


def clear_cache():
    """Clear the web content cache"""
    global WEB_CACHE
    WEB_CACHE = {}
    return True


def get_latest_crypto_news(max_sources=3):
    """
    Get and analyze latest cryptocurrency news
    
    Args:
        max_sources: Maximum number of sources to fetch
        
    Returns:
        List of analyzed news content
    """
    # Fetch from news sources
    news_content = fetch_multiple_sources('news', max_sources)
    
    results = []
    for url, data in news_content.items():
        analysis = analyze_web_content(data['content'], url)
        if analysis:
            results.append(analysis)
    
    return results


def get_crypto_research(max_sources=2):
    """
    Get and analyze cryptocurrency research and analysis
    
    Args:
        max_sources: Maximum number of sources to fetch
        
    Returns:
        List of analyzed research content
    """
    # Fetch from analysis sources
    research_content = fetch_multiple_sources('analysis', max_sources)
    
    results = []
    for url, data in research_content.items():
        analysis = analyze_web_content(data['content'], url)
        if analysis:
            results.append(analysis)
    
    return results


def get_social_sentiment(max_sources=3):
    """
    Get and analyze cryptocurrency sentiment from social media
    
    Args:
        max_sources: Maximum number of sources to fetch
        
    Returns:
        List of analyzed social content
    """
    # Fetch from forum sources
    social_content = fetch_multiple_sources('forums', max_sources)
    
    results = []
    for url, data in social_content.items():
        analysis = analyze_web_content(data['content'], url)
        if analysis:
            results.append(analysis)
    
    return results


def run_intelligence_gathering():
    """
    Run a complete intelligence gathering cycle
    
    Returns:
        Combined intelligence results
    """
    results = {
        'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        'news': get_latest_crypto_news(2),
        'research': get_crypto_research(1),
        'social': get_social_sentiment(2),
        'summary': {}
    }
    
    # Create summary of all mentions and sentiment
    all_mentions = {}
    total_positive = 0
    total_negative = 0
    total_neutral = 0
    
    # Process all sources
    for category in ['news', 'research', 'social']:
        for item in results[category]:
            # Combine crypto mentions
            for crypto, count in item['crypto_mentions'].items():
                if crypto in all_mentions:
                    all_mentions[crypto] += count
                else:
                    all_mentions[crypto] = count
            
            # Combine sentiment
            total_positive += item['sentiment']['positive_count']
            total_negative += item['sentiment']['negative_count']
            total_neutral += item['sentiment']['neutral_count']
    
    # Sort mentions by count
    sorted_mentions = sorted(all_mentions.items(), key=lambda x: x[1], reverse=True)
    
    # Calculate overall sentiment
    total_sentiment = total_positive + total_negative + total_neutral
    if total_sentiment > 0:
        overall_sentiment = (total_positive - total_negative) / total_sentiment
    else:
        overall_sentiment = 0
    
    # Create summary
    results['summary'] = {
        'top_mentions': dict(sorted_mentions[:10]),
        'sentiment_score': overall_sentiment,
        'sentiment_counts': {
            'positive': total_positive,
            'negative': total_negative,
            'neutral': total_neutral
        }
    }
    
    return results


if __name__ == "__main__":
    # Test functionality
    intelligence = run_intelligence_gathering()
    print(f"Gathered intelligence from {len(intelligence['news'])} news sources, {len(intelligence['research'])} research sources, and {len(intelligence['social'])} social sources")
    print(f"Overall sentiment: {intelligence['summary']['sentiment_score']:.2f}")
    print("Top mentioned cryptocurrencies:")
    for crypto, count in list(intelligence['summary']['top_mentions'].items())[:5]:
        print(f"  - {crypto}: {count} mentions")